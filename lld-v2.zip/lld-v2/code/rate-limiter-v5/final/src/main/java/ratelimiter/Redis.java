package ratelimiter;

import java.util.*;

// The one call this needs from a Redis client library such as Jedis or Lettuce.
interface Redis {
    List<Long> eval(String script, List<String> keys, List<String> args);
}
