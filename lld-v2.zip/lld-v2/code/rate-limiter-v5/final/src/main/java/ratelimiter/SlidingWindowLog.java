package ratelimiter;

import java.util.*;

// Exact: never more than `limit` in ANY stretch of one window. Keeps a timestamp per unit taken.
class SlidingWindowLog implements Bucket {
    private final int limit;
    private final long windowMillis;
    private final ArrayDeque<Long> times = new ArrayDeque<>();   // oldest first

    SlidingWindowLog(Limit limit, long nowMillis) {
        this.limit = limit.permits();
        this.windowMillis = limit.windowMillis();
    }

    @Override
    public synchronized Decision tryTake(int cost, long nowMillis) {
        if (cost > limit) return Decision.deny(Decision.NEVER);
        while (!times.isEmpty() && times.peekFirst() <= nowMillis - windowMillis) {
            times.pollFirst();                                   // forget what left the window
        }
        if (times.size() + cost <= limit) {
            for (int i = 0; i < cost; i++) times.addLast(nowMillis);
            return Decision.allow(limit - times.size());
        }
        // a place for `cost` opens when enough of the oldest entries have left the window
        long oldestThatMustLeave = times.stream().skip(times.size() + cost - limit - 1).findFirst().orElse(nowMillis);
        return Decision.deny(oldestThatMustLeave + windowMillis - nowMillis);
    }

    @Override
    public synchronized void refund(int cost, long nowMillis) {
        for (int i = 0; i < cost && !times.isEmpty(); i++) times.pollLast();
    }

    @Override
    public synchronized boolean isIdle(long nowMillis) {
        return times.isEmpty() || times.peekLast() <= nowMillis - windowMillis;
    }
}
