package ratelimiter;

import java.util.*;

// Every server builds buckets the same way, so they all share one budget per rule and key.
class RedisBucketStore implements BucketStore {
    private final Redis redis;
    private final Set<String> failClosedRules;
    private final Breaker breaker = new Breaker(3, 5_000);

    RedisBucketStore(Redis redis, Set<String> failClosedRules) {
        this.redis = redis;
        this.failClosedRules = failClosedRules;
    }

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        // {key} is a hash tag: all of one client's keys land on the same Redis Cluster slot
        String redisKey = "rate:{" + key + "}:" + rule.id();
        Bucket remote = new RedisTokenBucket(redis, redisKey, rule.limit());
        return new FallbackBucket(remote, !failClosedRules.contains(rule.id()), breaker);
    }
}
