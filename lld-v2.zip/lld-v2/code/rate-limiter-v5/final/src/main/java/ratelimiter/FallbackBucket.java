package ratelimiter;

// Decorator: when Redis fails or the breaker is open, answer from the rule's policy instead of
// failing the request. Fail open for a public API; fail closed for logins.
class FallbackBucket implements Bucket {
    private final Bucket remote;
    private final boolean failOpen;
    private final Breaker breaker;

    FallbackBucket(Bucket remote, boolean failOpen, Breaker breaker) {
        this.remote = remote;
        this.failOpen = failOpen;
        this.breaker = breaker;
    }

    @Override
    public Decision tryTake(int cost, long nowMillis) {
        if (breaker.isOpen(nowMillis)) return fallback();
        try {
            Decision d = remote.tryTake(cost, nowMillis);
            breaker.success();
            return d;
        } catch (RuntimeException redisDown) {
            breaker.failure(nowMillis);
            return fallback();
        }
    }

    private Decision fallback() { return failOpen ? Decision.allow(Long.MAX_VALUE) : Decision.deny(1_000); }

    @Override
    public void refund(int cost, long nowMillis) {
        try { remote.refund(cost, nowMillis); } catch (RuntimeException ignored) { /* expires anyway */ }
    }

    @Override
    public boolean isIdle(long nowMillis) { return false; }
}
