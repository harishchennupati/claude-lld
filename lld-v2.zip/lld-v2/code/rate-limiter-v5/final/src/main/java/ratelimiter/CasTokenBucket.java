package ratelimiter;

import java.util.concurrent.atomic.*;

// Lock-free: both numbers live in one immutable State, swapped with compareAndSet. A thread that
// loses the swap reads the new State and tries again; nobody waits on a lock.
class CasTokenBucket implements Bucket {
    private record State(double tokens, long lastRefillMillis) { }
    private final int capacity;
    private final long windowMillis;
    private final AtomicReference<State> state;

    CasTokenBucket(Limit limit, long nowMillis) {
        this.capacity = limit.permits();
        this.windowMillis = limit.windowMillis();
        this.state = new AtomicReference<>(new State(capacity, nowMillis));
    }

    @Override
    public Decision tryTake(int cost, long nowMillis) {
        if (cost > capacity) return Decision.deny(Decision.NEVER);
        while (true) {
            State s = state.get();
            long elapsed = Math.max(0, nowMillis - s.lastRefillMillis());
            double tokens = Math.min(capacity, s.tokens() + (double) elapsed * capacity / windowMillis);
            if (tokens < cost) return Decision.deny((long) Math.ceil((cost - tokens) * windowMillis / capacity));
            State next = new State(tokens - cost, Math.max(nowMillis, s.lastRefillMillis()));
            if (state.compareAndSet(s, next)) return Decision.allow((long) next.tokens());   // lost: loop
        }
    }

    @Override
    public void refund(int cost, long nowMillis) {
        state.updateAndGet(s -> new State(Math.min(capacity, s.tokens() + cost), s.lastRefillMillis()));
    }

    @Override
    public boolean isIdle(long nowMillis) { return nowMillis - state.get().lastRefillMillis() >= windowMillis; }
}
