package ratelimiter;

import java.util.concurrent.atomic.*;

// Decorator: enforces the live rules, and also asks a candidate limiter with new rules, counting
// what it would have refused. Try a stricter rule on real traffic without refusing anyone.
class ShadowLimiter implements RateLimiter {
    private final RateLimiter live;
    private final RateLimiter candidate;
    private final LongAdder wouldRefuse = new LongAdder();

    ShadowLimiter(RateLimiter live, RateLimiter candidate) {
        this.live = live;
        this.candidate = candidate;
    }

    @Override
    public Decision check(Request request) {
        Decision d = live.check(request);
        if (d.allowed() && !candidate.check(request).allowed()) wouldRefuse.increment();   // and log it
        return d;
    }

    long wouldHaveRefused() { return wouldRefuse.sum(); }
}
