package ratelimiter;

// For callers that would rather wait than be refused, such as a nightly batch job.
final class Waiting {
    // Waits up to maxWaitMillis for the request to pass. False at once if the wait would be longer.
    static boolean acquire(RateLimiter limiter, Request request, long maxWaitMillis) throws InterruptedException {
        long deadline = System.nanoTime() + maxWaitMillis * 1_000_000;
        while (true) {
            Decision d = limiter.check(request);
            if (d.allowed()) return true;
            long leftMillis = (deadline - System.nanoTime()) / 1_000_000;
            if (d.retryAfterMillis() == Decision.NEVER || d.retryAfterMillis() > leftMillis) return false;
            Thread.sleep(d.retryAfterMillis());
        }
    }
}
