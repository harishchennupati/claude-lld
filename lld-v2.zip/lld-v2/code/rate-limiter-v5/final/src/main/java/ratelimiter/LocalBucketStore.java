package ratelimiter;

import java.util.*;
import java.util.concurrent.*;

class LocalBucketStore implements BucketStore {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        // one bucket per rule and key, made once, even when two threads meet a new key together
        return buckets.computeIfAbsent(rule.id() + "|" + rule.limit() + "|" + key,   // new limit, new bucket
                k -> rule.algorithm().newBucket(rule.limit(), nowMillis));
    }

    // Forgets buckets idle for a whole window. Runs on a timer, never on the request path.
    int evictIdle(long nowMillis) {
        int removed = 0;
        for (Map.Entry<String, Bucket> e : buckets.entrySet()) {
            // remove(key, value) removes only if the map still holds this same bucket
            if (e.getValue().isIdle(nowMillis) && buckets.remove(e.getKey(), e.getValue())) removed++;
        }
        return removed;
    }

    int size() { return buckets.size(); }
}
