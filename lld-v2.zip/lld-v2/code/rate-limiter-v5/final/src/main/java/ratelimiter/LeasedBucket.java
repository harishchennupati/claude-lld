package ratelimiter;

// Round trips and hot keys: each server takes tokens from Redis in batches and spends them
// locally. Never over the limit, since tokens are taken before they are spent.
class LeasedBucket implements Bucket {
    private final Bucket remote;
    private final int batch;
    private int leased;                 // tokens this server holds and may spend without asking
    private long quietUntil;            // Redis said "not before this": don't ask again until then

    LeasedBucket(Bucket remote, int batch) {
        this.remote = remote;
        this.batch = batch;
    }

    @Override
    public synchronized Decision tryTake(int cost, long nowMillis) {
        if (leased < cost) {
            if (nowMillis < quietUntil) return Decision.deny(quietUntil - nowMillis);
            int need = Math.max(batch, cost - leased);
            Decision d = remote.tryTake(need, nowMillis);
            if (d.allowed()) {
                leased += need;
            } else {
                d = remote.tryTake(cost - leased, nowMillis);       // no whole batch left: take what is missing
                if (!d.allowed()) {
                    quietUntil = nowMillis + Math.max(1, d.retryAfterMillis());
                    return d;
                }
                leased = cost;
            }
        }
        leased -= cost;
        return Decision.allow(leased);
    }

    @Override
    public synchronized void refund(int cost, long nowMillis) { leased += cost; }

    @Override
    public boolean isIdle(long nowMillis) { return false; }
}
