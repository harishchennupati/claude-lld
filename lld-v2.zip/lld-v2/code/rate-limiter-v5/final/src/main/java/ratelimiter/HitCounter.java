package ratelimiter;

// LeetCode 362: hits in the last 300 seconds. One slot per second, reused every 300 seconds.
class HitCounter {
    private final int[] second = new int[300];
    private final int[] count = new int[300];

    synchronized void hit(int now) {
        int i = now % 300;
        if (second[i] != now) {         // the slot still holds an old second: reuse it
            second[i] = now;
            count[i] = 0;
        }
        count[i]++;
    }

    synchronized int getHits(int now) {
        int total = 0;
        for (int i = 0; i < 300; i++) if (now - second[i] < 300) total += count[i];
        return total;
    }
}
