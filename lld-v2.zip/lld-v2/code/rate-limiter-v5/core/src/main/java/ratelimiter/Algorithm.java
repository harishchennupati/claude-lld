package ratelimiter;

// How a rule counts: an algorithm makes the Bucket that counts for one key. TokenBucket::new is one.
interface Algorithm {
    Bucket newBucket(Limit limit, long nowMillis);
}
