package ratelimiter;

// Where each key's bucket lives: in this process here, in Redis when there are many servers.
interface BucketStore {
    Bucket bucket(Rule rule, String key, long nowMillis);
}
