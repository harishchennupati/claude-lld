package ratelimiter;

// Holds up to `capacity` tokens and earns `capacity` back per window, a little every millisecond.
class TokenBucket implements Bucket {
    private final int capacity;
    private final long windowMillis;
    private double tokens;              // tokens left
    private long lastRefillMillis;      // when `tokens` was last brought up to date

    TokenBucket(Limit limit, long nowMillis) {
        this.capacity = limit.permits();
        this.windowMillis = limit.windowMillis();
        this.tokens = capacity;         // a new key starts with a full bucket
        this.lastRefillMillis = nowMillis;
    }

    @Override
    public synchronized Decision tryTake(int cost, long nowMillis) {
        if (cost > capacity) return Decision.deny(Decision.NEVER);   // waiting would never help
        refill(nowMillis);
        if (tokens >= cost) {
            tokens -= cost;
            return Decision.allow((long) tokens);
        }
        return Decision.deny((long) Math.ceil((cost - tokens) * windowMillis / capacity));
    }

    @Override
    public synchronized void refund(int cost, long nowMillis) {
        tokens = Math.min(capacity, tokens + cost);   // never above a full bucket
    }

    private void refill(long nowMillis) {
        long elapsed = nowMillis - lastRefillMillis;
        if (elapsed <= 0) return;       // same millisecond, or an older reading: earn nothing
        tokens = Math.min(capacity, tokens + (double) elapsed * capacity / windowMillis);
        lastRefillMillis = nowMillis;
    }
}
