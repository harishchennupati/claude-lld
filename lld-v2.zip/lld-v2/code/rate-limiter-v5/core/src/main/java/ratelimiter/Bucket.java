package ratelimiter;

// One key's budget. Each algorithm is a class that implements it.
interface Bucket {
    Decision tryTake(int cost, long nowMillis);    // take `cost` now, or say how long until it fits
    void refund(int cost, long nowMillis);         // give back what tryTake took
}
