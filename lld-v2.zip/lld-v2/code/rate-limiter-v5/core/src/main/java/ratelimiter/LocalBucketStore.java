package ratelimiter;

import java.util.concurrent.*;

class LocalBucketStore implements BucketStore {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        // one bucket per rule and key, made once, even when two threads meet a new key together
        return buckets.computeIfAbsent(rule.id() + "|" + key,
                k -> rule.algorithm().newBucket(rule.limit(), nowMillis));
    }
}
