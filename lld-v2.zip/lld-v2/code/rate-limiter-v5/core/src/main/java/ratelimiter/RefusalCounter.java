package ratelimiter;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

// A listener that counts refusals per rule, for a dashboard.
class RefusalCounter implements DecisionListener {
    private final ConcurrentHashMap<String, LongAdder> byRule = new ConcurrentHashMap<>();

    @Override
    public void onDecision(Request request, Decision d) {
        if (!d.allowed()) byRule.computeIfAbsent(d.ruleId(), k -> new LongAdder()).increment();
    }

    long refusedBy(String ruleId) {
        LongAdder n = byRule.get(ruleId);
        return n == null ? 0 : n.sum();
    }
}
