package ratelimiter;

// Anyone who wants to hear about decisions: metrics, an audit log. Told after the decision.
interface DecisionListener {
    void onDecision(Request request, Decision decision);
}
