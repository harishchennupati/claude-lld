package ratelimiter;

import java.util.*;

// The edge: turns a Decision into an HTTP status and the standard rate-limit headers.
class ApiFilter {
    private final RateLimiter limiter;
    ApiFilter(RateLimiter limiter) { this.limiter = limiter; }

    Response handle(Request request) {
        Decision d = limiter.check(request);
        Map<String, String> h = new TreeMap<>();
        if (d.allowed()) {
            if (d.remaining() != Long.MAX_VALUE) h.put("X-RateLimit-Remaining", String.valueOf(d.remaining()));
            return new Response(200, h);
        }
        h.put("X-RateLimit-Rule", d.ruleId());
        if (d.retryAfterMillis() != Decision.NEVER) {
            h.put("Retry-After", String.valueOf((d.retryAfterMillis() + 999) / 1000));   // whole seconds, up
        }
        return new Response(429, h);
    }
}
