package ratelimiter;

// Where "now" comes from. Handed in, so a test moves time by hand instead of sleeping.
interface Clock {
    long millis();
}
