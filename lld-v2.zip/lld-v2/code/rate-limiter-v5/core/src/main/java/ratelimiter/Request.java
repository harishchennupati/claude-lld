package ratelimiter;

// One request, as the limiter sees it: who sent it, to which endpoint, and what it costs.
record Request(String clientId, String endpoint, int cost) {
    Request {
        if (cost <= 0) throw new IllegalArgumentException("cost must be > 0");
    }
    static Request of(String clientId, String endpoint) { return new Request(clientId, endpoint, 1); }
}
