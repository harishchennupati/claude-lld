package ratelimiter;

enum Plan { FREE, PRO }
