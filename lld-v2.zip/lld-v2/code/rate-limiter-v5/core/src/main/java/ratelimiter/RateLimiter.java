package ratelimiter;

// What the API calls before any work is done for a request.
interface RateLimiter {
    Decision check(Request request);
}
