package ratelimiter;

// The answer. Allowed: how much is left. Refused: when to retry, and which rule said no.
record Decision(boolean allowed, long remaining, long retryAfterMillis, String ruleId) {
    static final long NEVER = -1;             // costs more than the limit: it can never pass
    static Decision allow(long remaining) { return new Decision(true, remaining, 0, ""); }
    static Decision deny(long waitMillis) { return new Decision(false, 0, waitMillis, ""); }
    Decision by(String ruleId)            { return new Decision(allowed, remaining, retryAfterMillis, ruleId); }

    @Override public String toString() {
        if (allowed) return remaining == Long.MAX_VALUE ? "allowed" : "allowed, " + remaining + " left";
        return "refused by " + ruleId + (retryAfterMillis == NEVER ? ", can never fit" : ", retry in " + retryAfterMillis + " ms");
    }
}
