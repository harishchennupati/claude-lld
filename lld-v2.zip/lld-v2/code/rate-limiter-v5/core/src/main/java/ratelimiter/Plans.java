package ratelimiter;

import java.util.*;
import java.util.concurrent.*;

// Which plan each client is on. A client nobody has set up is on FREE.
class Plans {
    private final Map<String, Plan> byClient = new ConcurrentHashMap<>();
    Plan of(String clientId)             { return byClient.getOrDefault(clientId, Plan.FREE); }
    void set(String clientId, Plan plan) { byClient.put(clientId, plan); }
}
