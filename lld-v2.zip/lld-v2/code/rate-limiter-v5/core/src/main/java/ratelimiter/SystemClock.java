package ratelimiter;

class SystemClock implements Clock {
    public long millis() { return System.nanoTime() / 1_000_000; }   // never jumps back
}
