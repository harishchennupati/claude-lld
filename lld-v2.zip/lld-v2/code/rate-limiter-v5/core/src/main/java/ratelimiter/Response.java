package ratelimiter;

import java.util.*;

// What the HTTP client gets back.
record Response(int status, Map<String, String> headers) { }
