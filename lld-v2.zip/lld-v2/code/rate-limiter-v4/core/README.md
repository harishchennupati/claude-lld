# rate-limiter · core

Generated from `rate-limiter/wb/Main.java`, snapshot `core`: the same code the workbench page shows, compiled and run.

- **IntelliJ:** File > Open > this folder (it reads `pom.xml`), then run `ratelimiter.Main`.
- **Terminal:** `./run.sh`, or `mvn -q compile exec:java`.
- One top-level type per file, in package `ratelimiter`. `Main` holds the demo and the checks; a broken
  promise throws `AssertionError`.

Files: Rule.java, Decision.java, Clock.java, SystemClock.java, ManualClock.java, Bucket.java, BucketFactory.java, TokenBucket.java, RateLimiter.java, RuleBook.java, LocalRateLimiter.java, Main.java
