#!/bin/sh
# compile and run; needs Java 17+
cd "$(dirname "$0")"
rm -rf out && mkdir out
javac -d out $(find src -name "*.java") && java -cp out ratelimiter.Main
