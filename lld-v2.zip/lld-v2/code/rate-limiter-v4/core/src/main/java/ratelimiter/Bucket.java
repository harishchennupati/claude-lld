package ratelimiter;

// One client's budget. Each algorithm is a class that implements this.
interface Bucket {
    Decision tryTake(long nowMillis);
}
