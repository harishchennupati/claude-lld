package ratelimiter;

class SystemClock implements Clock {
    // nanoTime, not currentTimeMillis: it never jumps back when the machine's clock is fixed
    public long millis() { return System.nanoTime() / 1_000_000; }
}
