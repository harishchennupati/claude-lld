package ratelimiter;

// Makes the bucket for a client seen for the first time. TokenBucket::new is one.
interface BucketFactory {
    Bucket create(Rule rule, long nowMillis);
}
