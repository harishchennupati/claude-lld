package ratelimiter;

// Holds up to `capacity` tokens and earns `capacity` tokens back per window, a little every
// millisecond. A request spends one token. No timer: each call first adds what time earned.
class TokenBucket implements Bucket {
    private final int capacity;
    private final long windowMillis;
    private double tokens;              // tokens left
    private long lastRefillMillis;      // when `tokens` was last brought up to date

    TokenBucket(Rule rule, long nowMillis) {
        this.capacity = rule.limit();
        this.windowMillis = rule.windowMillis();
        this.tokens = capacity;         // a new client starts with a full bucket
        this.lastRefillMillis = nowMillis;
    }

    @Override
    public synchronized Decision tryTake(long nowMillis) {
        refill(nowMillis);
        if (tokens >= 1) {
            tokens -= 1;
            return Decision.allow();
        }
        // not enough: say how long until one whole token has been earned
        long wait = (long) Math.ceil((1 - tokens) * windowMillis / capacity);
        return Decision.deny(wait);
    }

    private void refill(long nowMillis) {
        long elapsed = nowMillis - lastRefillMillis;
        if (elapsed <= 0) return;       // same millisecond, or an older reading: earn nothing
        tokens = Math.min(capacity, tokens + (double) elapsed * capacity / windowMillis);
        lastRefillMillis = nowMillis;
    }
}
