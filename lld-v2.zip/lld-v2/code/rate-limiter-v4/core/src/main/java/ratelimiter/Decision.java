package ratelimiter;

// The answer to one request. On a refusal: when to try again (HTTP's Retry-After).
record Decision(boolean allowed, long retryAfterMillis) {
    static Decision allow()           { return new Decision(true, 0); }
    static Decision deny(long waitMs) { return new Decision(false, waitMs); }

    @Override public String toString() {
        return allowed ? "allowed" : "refused, retry in " + retryAfterMillis + " ms";
    }
}
