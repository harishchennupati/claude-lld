package ratelimiter;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class Main {
    public static void main(String[] args) throws Exception {
        ManualClock clock = new ManualClock(0);
        RuleBook rules = new RuleBook(Rule.perMinute(100));   // everyone: 100 a minute
        rules.set("acme", Rule.perSecond(5));                 // acme: 5 a second
        RateLimiter limiter = new LocalRateLimiter(rules, TokenBucket::new, clock);

        // t = 0: a burst of 7. The bucket holds 5, so 5 pass and 2 are told to wait.
        for (int i = 1; i <= 7; i++) {
            System.out.println("t=0     #" + i + " " + limiter.allow("acme"));
        }
        clock.advance(200);                                   // 200 ms earns 1 token
        System.out.println("t=200   #8 " + limiter.allow("acme"));
        System.out.println("t=200   #9 " + limiter.allow("acme"));

        clock.advance(5_000);                                 // 5 quiet seconds...
        int passed = 0;
        for (int i = 0; i < 10; i++) if (limiter.allow("acme").allowed()) passed++;
        System.out.println("t=5200  10 more: " + passed + " allowed");
        check(passed == 5, "a bucket never holds more than its capacity");

        race();
    }

    // 100 threads send 1,000 requests each, spread over 100 new clients, on a frozen clock.
    // Every client may pass 500, so exactly 100 x 500 = 50,000 may pass in total.
    static void race() throws Exception {
        ManualClock clock = new ManualClock(0);               // frozen: nothing refills
        RateLimiter limiter = new LocalRateLimiter(
                new RuleBook(Rule.perMinute(500)), TokenBucket::new, clock);
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        AtomicInteger passed = new AtomicInteger();
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();                                   // all 100 start together
                for (int i = 0; i < 1_000; i++) {
                    if (limiter.allow("client-" + i % 100).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("race    100 threads, 100,000 requests: " + passed.get() + " allowed");
        check(passed.get() == 50_000, "never more than the limit, whatever the thread count");
    }

    static void check(boolean ok, String rule) {
        if (!ok) throw new AssertionError("broken: " + rule);
    }
}
