package ratelimiter;

import java.util.concurrent.*;

// One process, in memory: a bucket per client, made on the client's first request.
class LocalRateLimiter implements RateLimiter {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();
    private final RuleBook rules;
    private final BucketFactory newBucket;
    private final Clock clock;

    LocalRateLimiter(RuleBook rules, BucketFactory newBucket, Clock clock) {
        this.rules = rules;
        this.newBucket = newBucket;
        this.clock = clock;
    }

    @Override
    public Decision allow(String clientId) {
        long now = clock.millis();
        // exactly one bucket per client, even when two threads see a new client at once
        Bucket bucket = buckets.computeIfAbsent(clientId,
                id -> newBucket.create(rules.ruleFor(id), now));
        return bucket.tryTake(now);     // locks this client's bucket only
    }
}
