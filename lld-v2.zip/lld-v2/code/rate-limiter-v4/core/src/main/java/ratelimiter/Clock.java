package ratelimiter;

// Where "now" comes from. It is handed in, so a test moves time by hand instead of sleeping.
interface Clock {
    long millis();
}
