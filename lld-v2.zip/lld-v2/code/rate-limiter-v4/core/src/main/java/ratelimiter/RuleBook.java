package ratelimiter;

import java.util.*;
import java.util.concurrent.*;

// Which rule each client is on: one default, and overrides for some clients.
class RuleBook {
    private final Rule defaultRule;
    private final Map<String, Rule> overrides = new ConcurrentHashMap<>();

    RuleBook(Rule defaultRule)           { this.defaultRule = defaultRule; }
    void set(String clientId, Rule rule) { overrides.put(clientId, rule); }
    Rule ruleFor(String clientId)        { return overrides.getOrDefault(clientId, defaultRule); }
}
