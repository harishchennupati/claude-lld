package ratelimiter;

// A limit: at most `limit` requests per window. 100 a minute is Rule(100, 60_000).
record Rule(int limit, long windowMillis) {
    Rule {
        if (limit <= 0 || windowMillis <= 0) throw new IllegalArgumentException("must be > 0");
    }
    static Rule perSecond(int n) { return new Rule(n, 1_000); }
    static Rule perMinute(int n) { return new Rule(n, 60_000); }
}
