package ratelimiter;

// What the API calls before it does any work for a request.
interface RateLimiter {
    Decision allow(String clientId);
}
