package ratelimiter;

class ManualClock implements Clock {
    private volatile long now;
    ManualClock(long startMillis) { now = startMillis; }
    public long millis()          { return now; }
    void advance(long ms)         { now += ms; }      // only the test's own thread calls this
}
