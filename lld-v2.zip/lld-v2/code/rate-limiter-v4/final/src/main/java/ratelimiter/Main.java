package ratelimiter;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class Main {
    public static void main(String[] args) throws Exception {
        ManualClock clock = new ManualClock(0);
        RuleBook rules = new RuleBook(Rule.perMinute(100));   // everyone: 100 a minute
        rules.set("acme", Rule.perSecond(5));                 // acme: 5 a second
        RateLimiter limiter = new LocalRateLimiter(rules, TokenBucket::new, clock);

        // t = 0: a burst of 7. The bucket holds 5, so 5 pass and 2 are told to wait.
        for (int i = 1; i <= 7; i++) {
            System.out.println("t=0     #" + i + " " + limiter.allow("acme"));
        }
        clock.advance(200);                                   // 200 ms earns 1 token
        System.out.println("t=200   #8 " + limiter.allow("acme"));
        System.out.println("t=200   #9 " + limiter.allow("acme"));

        clock.advance(5_000);                                 // 5 quiet seconds...
        int passed = 0;
        for (int i = 0; i < 10; i++) if (limiter.allow("acme").allowed()) passed++;
        System.out.println("t=5200  10 more: " + passed + " allowed");
        check(passed == 5, "a bucket never holds more than its capacity");

        race();
        fu1SlidingWindow();
        fu2ChangePlan();
        fu3BothLimits();
        fu4Waiting();
        fu5EvictIdle();
        fu6Redis();
        extraAnswers();
    }

    // 100 threads send 1,000 requests each, spread over 100 new clients, on a frozen clock.
    // Every client may pass 500, so exactly 100 x 500 = 50,000 may pass in total.
    static void race() throws Exception {
        ManualClock clock = new ManualClock(0);               // frozen: nothing refills
        RateLimiter limiter = new LocalRateLimiter(
                new RuleBook(Rule.perMinute(500)), TokenBucket::new, clock);
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        AtomicInteger passed = new AtomicInteger();
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();                                   // all 100 start together
                for (int i = 0; i < 1_000; i++) {
                    if (limiter.allow("client-" + i % 100).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("race    100 threads, 100,000 requests: " + passed.get() + " allowed");
        check(passed.get() == 50_000, "never more than the limit, whatever the thread count");
    }

    // 5 a minute. A burst of 5 at t=0, then one request a second: how many pass in minute one?
    static void fu1SlidingWindow() {
        for (String name : List.of("TokenBucket", "SlidingWindowLog")) {
            ManualClock clock = new ManualClock(0);
            RuleBook rules = new RuleBook(Rule.perMinute(5));
            BucketFactory algorithm = name.equals("TokenBucket") ? TokenBucket::new
                                                                  : SlidingWindowLog::new;
            RateLimiter limiter = new LocalRateLimiter(rules, algorithm, clock);
            int passed = 0;
            for (int i = 0; i < 5; i++) if (limiter.allow("login:asha").allowed()) passed++;
            for (int s = 1; s < 60; s++) {
                clock.advance(1_000);
                if (limiter.allow("login:asha").allowed()) passed++;
            }
            System.out.println("fu1  " + name + ": " + passed + " passed in the first minute");
            check(passed == (name.equals("TokenBucket") ? 9 : 5), "fu1 " + name);
        }
    }

    static void fu2ChangePlan() {
        ManualClock clock = new ManualClock(0);
        RuleBook rules = new RuleBook(Rule.perMinute(100));
        rules.set("acme", Rule.perSecond(5));
        LocalRateLimiter limiter = new LocalRateLimiter(rules, TokenBucket::new, clock);
        for (int i = 0; i < 5; i++) limiter.allow("acme");            // acme spends its 5

        rules.set("acme", Rule.perSecond(50));                        // the bug: only the book
        System.out.println("fu2  book changed only:  " + limiter.allow("acme"));
        check(!limiter.allow("acme").allowed(), "fu2 old bucket still in use");

        limiter.changeRule("acme", Rule.perSecond(50));               // the fix
        int passed = 0;
        for (int i = 0; i < 60; i++) if (limiter.allow("acme").allowed()) passed++;
        System.out.println("fu2  after changeRule:   " + passed + " of 60 at once");
        check(passed == 50, "fu2 new plan applies on the next request");
    }

    // Each client: 10 a second. The whole API: 15 a second, shared by everyone.
    static void fu3BothLimits() {
        ManualClock clock = new ManualClock(0);
        Bucket wholeApi = new TokenBucket(Rule.perSecond(15), clock.millis());   // made once
        BucketFactory both = (rule, now) -> new BothBuckets(new TokenBucket(rule, now), wholeApi);
        RateLimiter limiter = new LocalRateLimiter(new RuleBook(Rule.perSecond(10)), both, clock);
        int a = 0, b = 0;
        for (int i = 0; i < 10; i++) if (limiter.allow("A").allowed()) a++;
        for (int i = 0; i < 10; i++) if (limiter.allow("B").allowed()) b++;
        System.out.println("fu3  t=0    A: " + a + " of 10, B: " + b + " of 10 (shared ran out)");
        check(a == 10 && b == 5, "fu3 shared limit");

        clock.advance(400);             // shared earns 6, B's own earns 4 on top of the 5 kept
        int b2 = 0;
        for (int i = 0; i < 10; i++) if (limiter.allow("B").allowed()) b2++;
        System.out.println("fu3  t=400  B: " + b2 + " of 10 (4 without the refund)");
        check(b2 == 6, "fu3 refunds kept B's own tokens");
    }

    static void fu4Waiting() throws InterruptedException {
        RuleBook rules = new RuleBook(Rule.perSecond(5));
        RateLimiter limiter = new LocalRateLimiter(rules, TokenBucket::new, new SystemClock());
        long start = System.nanoTime();
        List<Long> waited = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            check(Waiting.acquire(limiter, "batch-job", 1_000), "fu4 acquire within 1 s");
            long ms = (System.nanoTime() - start) / 1_000_000;
            waited.add(Math.round(ms / 100.0) * 100);
        }
        System.out.println("fu4  8 permits, got at about (ms): " + waited);
        boolean quick = Waiting.acquire(limiter, "batch-job", 50);
        System.out.println("fu4  next one with 50 ms to spare: " + quick);
        check(!quick && waited.get(7) >= 500, "fu4 waits, and gives up early");
    }

    static void fu5EvictIdle() {
        ManualClock clock = new ManualClock(0);
        LocalRateLimiter limiter = new LocalRateLimiter(
                new RuleBook(Rule.perMinute(100)), TokenBucket::new, clock);
        for (int i = 0; i < 100_000; i++) limiter.allow("key-" + i);
        clock.advance(30_000);
        limiter.allow("key-7");                                       // one client stays busy
        int early = limiter.evictIdle();
        clock.advance(30_000);
        int late = limiter.evictIdle();
        System.out.println("fu5  100,000 clients: evicted " + early + " at 30 s, "
                + late + " at 60 s, " + limiter.size() + " left");
        check(early == 0 && late == 99_999 && limiter.size() == 1, "fu5 eviction");
    }

    // No Redis here: a stand-in runs the same token bucket per key, one call at a time, the
    // way Redis runs one script at a time. It checks the Java side; the Lua was run separately.
    static void fu6Redis() {
        Map<String, TokenBucket> store = new HashMap<>();
        long t0 = System.nanoTime();
        Redis standIn = (script, keys, args) -> {
            synchronized (store) {
                long now = (System.nanoTime() - t0) / 1_000_000;
                Rule rule = new Rule(Integer.parseInt(args.get(0)), Long.parseLong(args.get(1)));
                Decision d = store.computeIfAbsent(keys.get(0), k -> new TokenBucket(rule, now))
                                  .tryTake(now);
                return List.of(d.allowed() ? 1L : 0L, d.retryAfterMillis());
            }
        };
        RuleBook rules = new RuleBook(Rule.perMinute(100));
        // three servers, one Redis: together they may pass 100, not 300
        List<RateLimiter> servers = List.of(new RedisRateLimiter(standIn, rules, true),
                new RedisRateLimiter(standIn, rules, true), new RedisRateLimiter(standIn, rules, true));
        int passed = 0;
        for (int i = 0; i < 300; i++) if (servers.get(i % 3).allow("acme").allowed()) passed++;
        System.out.println("fu6  3 servers, 300 requests: " + passed + " allowed");
        check(passed == 100, "fu6 one budget across servers");

        Redis down = (script, keys, args) -> { throw new IllegalStateException("timeout"); };
        Decision open = new RedisRateLimiter(down, rules, true).allow("acme");
        Decision closed = new RedisRateLimiter(down, rules, false).allow("acme");
        System.out.println("fu6  Redis down: fail open -> " + open + "; fail closed -> " + closed);
        check(open.allowed() && !closed.allowed(), "fu6 fail open / closed");
    }

    static void extraAnswers() throws Exception {
        // the lock-free bucket must pass the same race as TokenBucket
        ManualClock clock = new ManualClock(0);
        RateLimiter cas = new LocalRateLimiter(
                new RuleBook(Rule.perMinute(500)), CasTokenBucket::new, clock);
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        AtomicInteger passed = new AtomicInteger();
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();
                for (int i = 0; i < 1_000; i++) {
                    if (cas.allow("client-" + i % 100).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("extra CasTokenBucket race: " + passed.get() + " allowed");
        check(passed.get() == 50_000, "lock-free bucket keeps the limit");

        HitCounter hits = new HitCounter();
        hits.hit(1); hits.hit(2); hits.hit(3); hits.hit(300);
        int at300 = hits.getHits(300), at301 = hits.getHits(301), at302 = hits.getHits(302);
        System.out.println("extra HitCounter: " + at300 + " at 300 s, " + at301 + " at 301 s, "
                + at302 + " at 302 s");
        check(at300 == 4 && at301 == 3 && at302 == 2, "hit counter window");

        ManualClock c2 = new ManualClock(0);
        RuleBook rules = new RuleBook(Rule.perSecond(5));
        ShadowLimiter shadow = new ShadowLimiter(new LocalRateLimiter(rules, TokenBucket::new, c2));
        int let = 0;
        for (int i = 0; i < 8; i++) if (shadow.allow("acme").allowed()) let++;
        System.out.println("extra ShadowLimiter: let " + let + " of 8 through, would have refused "
                + shadow.wouldHaveRefused());
        check(let == 8 && shadow.wouldHaveRefused() == 3, "shadow mode");
    }

    static void check(boolean ok, String rule) {
        if (!ok) throw new AssertionError("broken: " + rule);
    }
}
