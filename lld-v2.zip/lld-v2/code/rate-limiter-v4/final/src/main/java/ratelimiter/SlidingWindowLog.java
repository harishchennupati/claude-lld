package ratelimiter;

import java.util.*;

// Exact: never more than `limit` requests in ANY stretch of one window.
// It keeps the time of every request it let through, oldest first.
class SlidingWindowLog implements Bucket {
    private final int limit;
    private final long windowMillis;
    private final ArrayDeque<Long> times = new ArrayDeque<>();

    SlidingWindowLog(Rule rule, long nowMillis) {
        this.limit = rule.limit();
        this.windowMillis = rule.windowMillis();
    }

    @Override
    public synchronized Decision tryTake(long nowMillis) {
        // forget the requests that have left the window
        while (!times.isEmpty() && times.peekFirst() <= nowMillis - windowMillis) {
            times.pollFirst();
        }
        if (times.size() < limit) {
            times.addLast(nowMillis);
            return Decision.allow();
        }
        // full: a place opens when the oldest request leaves the window
        return Decision.deny(times.peekFirst() + windowMillis - nowMillis);
    }

    @Override
    public synchronized void refund(long nowMillis) {
        times.pollLast();                               // un-count the newest request
    }

    @Override
    public synchronized boolean isIdle(long nowMillis) {
        return times.isEmpty() || times.peekLast() <= nowMillis - windowMillis;
    }
}
