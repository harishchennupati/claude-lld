package ratelimiter;

import java.util.*;

// Many servers, one budget per client. The bucket lives in Redis, and one Lua script refills
// and takes in one step. Redis runs one script at a time, so two servers never interleave.
class RedisRateLimiter implements RateLimiter {
    static final String TOKEN_BUCKET = """
        local capacity, window = tonumber(ARGV[1]), tonumber(ARGV[2])
        local t = redis.call('TIME')                  -- Redis's clock: every server agrees
        local now = t[1] * 1000 + math.floor(t[2] / 1000)
        local b = redis.call('HMGET', KEYS[1], 'tokens', 'last')
        local tokens = tonumber(b[1]) or capacity      -- a new client starts full
        local last = tonumber(b[2]) or now
        if now > last then
          tokens = math.min(capacity, tokens + (now - last) * capacity / window)
          last = now
        end
        local allowed, wait = 0, 0
        if tokens >= 1 then
          tokens, allowed = tokens - 1, 1
        else
          wait = math.ceil((1 - tokens) * window / capacity)
        end
        redis.call('HSET', KEYS[1], 'tokens', tostring(tokens), 'last', last)
        redis.call('PEXPIRE', KEYS[1], window)        -- unused for a window: Redis forgets it
        return {allowed, wait}
        """;

    private final Redis redis;
    private final RuleBook rules;
    private final boolean failOpen;     // Redis unreachable: let requests through, or refuse?

    RedisRateLimiter(Redis redis, RuleBook rules, boolean failOpen) {
        this.redis = redis;
        this.rules = rules;
        this.failOpen = failOpen;
    }

    @Override
    public Decision allow(String clientId) {
        Rule r = rules.ruleFor(clientId);
        try {
            List<Long> res = redis.eval(TOKEN_BUCKET, List.of("rate:" + clientId),
                    List.of(String.valueOf(r.limit()), String.valueOf(r.windowMillis())));
            return res.get(0) == 1 ? Decision.allow() : Decision.deny(res.get(1));
        } catch (RuntimeException redisDown) {
            return failOpen ? Decision.allow() : Decision.deny(1_000);
        }
    }
}
