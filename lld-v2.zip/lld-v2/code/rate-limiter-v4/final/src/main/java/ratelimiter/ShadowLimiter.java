package ratelimiter;

import java.util.concurrent.atomic.*;

// Decorator: asks the real limiter, counts what it would have refused, and lets everything
// through. Run it for a week before switching a new limit on.
class ShadowLimiter implements RateLimiter {
    private final RateLimiter real;
    private final LongAdder wouldRefuse = new LongAdder();

    ShadowLimiter(RateLimiter real) { this.real = real; }

    @Override
    public Decision allow(String clientId) {
        if (!real.allow(clientId).allowed()) wouldRefuse.increment();   // and log the client
        return Decision.allow();
    }

    long wouldHaveRefused() { return wouldRefuse.sum(); }
}
