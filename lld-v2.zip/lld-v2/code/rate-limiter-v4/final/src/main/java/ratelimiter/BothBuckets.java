package ratelimiter;

// A request must pass the client's own bucket AND the one bucket all clients share.
class BothBuckets implements Bucket {
    private final Bucket own;
    private final Bucket shared;

    BothBuckets(Bucket own, Bucket shared) {
        this.own = own;
        this.shared = shared;
    }

    @Override
    public Decision tryTake(long nowMillis) {
        Decision mine = own.tryTake(nowMillis);
        if (!mine.allowed()) return mine;               // stopped by its own limit: shared untouched
        Decision all = shared.tryTake(nowMillis);
        if (!all.allowed()) own.refund(nowMillis);      // stopped by the shared one: give it back
        return all;
    }

    @Override
    public void refund(long nowMillis) {
        own.refund(nowMillis);
        shared.refund(nowMillis);
    }

    @Override
    public boolean isIdle(long nowMillis) {
        return own.isIdle(nowMillis);                   // forget the client, never the shared one
    }
}
