package ratelimiter;

// One client's budget. Each algorithm is a class that implements this.
interface Bucket {
    Decision tryTake(long nowMillis);
    void refund(long nowMillis);            // give back one token taken by tryTake
    boolean isIdle(long nowMillis);         // true when forgetting it loses nothing
}
