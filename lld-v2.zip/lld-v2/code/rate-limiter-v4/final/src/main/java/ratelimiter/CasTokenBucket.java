package ratelimiter;

import java.util.concurrent.atomic.*;

// Lock-free: both numbers live in one immutable State, swapped with compareAndSet. A thread
// that loses the swap reads the new State and tries again; nobody ever waits on a lock.
class CasTokenBucket implements Bucket {
    private record State(double tokens, long lastRefillMillis) { }
    private final int capacity;
    private final long windowMillis;
    private final AtomicReference<State> state;

    CasTokenBucket(Rule rule, long nowMillis) {
        this.capacity = rule.limit();
        this.windowMillis = rule.windowMillis();
        this.state = new AtomicReference<>(new State(capacity, nowMillis));
    }

    @Override
    public Decision tryTake(long nowMillis) {
        while (true) {
            State s = state.get();
            long elapsed = Math.max(0, nowMillis - s.lastRefillMillis());
            double tokens = Math.min(capacity, s.tokens() + (double) elapsed * capacity / windowMillis);
            if (tokens < 1) return Decision.deny((long) Math.ceil((1 - tokens) * windowMillis / capacity));
            State next = new State(tokens - 1, Math.max(nowMillis, s.lastRefillMillis()));
            if (state.compareAndSet(s, next)) return Decision.allow();   // lost the swap: loop
        }
    }

    @Override
    public void refund(long nowMillis) {
        state.updateAndGet(s -> new State(Math.min(capacity, s.tokens() + 1), s.lastRefillMillis()));
    }

    @Override
    public boolean isIdle(long nowMillis) {
        return nowMillis - state.get().lastRefillMillis() >= windowMillis;
    }
}
