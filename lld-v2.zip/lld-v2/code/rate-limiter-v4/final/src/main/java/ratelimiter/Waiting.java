package ratelimiter;

// For callers that would rather wait than be refused, such as a nightly batch job.
final class Waiting {
    // Waits up to maxWaitMillis for a permit. Returns false at once if the wait would be longer.
    static boolean acquire(RateLimiter limiter, String clientId, long maxWaitMillis)
            throws InterruptedException {
        long deadline = System.nanoTime() + maxWaitMillis * 1_000_000;
        while (true) {
            Decision d = limiter.allow(clientId);
            if (d.allowed()) return true;
            long leftMillis = (deadline - System.nanoTime()) / 1_000_000;
            if (d.retryAfterMillis() > leftMillis) return false;  // give up now, not at the deadline
            Thread.sleep(d.retryAfterMillis());
        }
    }
}
