package ratelimiter;

import java.util.*;
import java.util.concurrent.*;

// One process, in memory: a bucket per client, made on the client's first request.
class LocalRateLimiter implements RateLimiter {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();
    private final RuleBook rules;
    private final BucketFactory newBucket;
    private final Clock clock;

    LocalRateLimiter(RuleBook rules, BucketFactory newBucket, Clock clock) {
        this.rules = rules;
        this.newBucket = newBucket;
        this.clock = clock;
    }

    @Override
    public Decision allow(String clientId) {
        long now = clock.millis();
        // exactly one bucket per client, even when two threads see a new client at once
        Bucket bucket = buckets.computeIfAbsent(clientId,
                id -> newBucket.create(rules.ruleFor(id), now));
        return bucket.tryTake(now);     // locks this client's bucket only
    }

    // A new plan takes effect on the client's next request. The order of the two lines matters.
    void changeRule(String clientId, Rule rule) {
        rules.set(clientId, rule);      // 1. new buckets for this client get the new rule
        buckets.remove(clientId);       // 2. drop the old bucket; the next request makes a new one
    }

    // Forgets clients idle for a whole window. Runs on a timer, never on the request path:
    //   Executors.newSingleThreadScheduledExecutor()
    //            .scheduleAtFixedRate(limiter::evictIdle, 1, 1, TimeUnit.MINUTES);
    int evictIdle() {
        long now = clock.millis();
        int removed = 0;
        for (Map.Entry<String, Bucket> e : buckets.entrySet()) {
            // remove(key, value) removes only if the map still holds this same bucket
            if (e.getValue().isIdle(now) && buckets.remove(e.getKey(), e.getValue())) removed++;
        }
        return removed;
    }

    int size() { return buckets.size(); }
}
