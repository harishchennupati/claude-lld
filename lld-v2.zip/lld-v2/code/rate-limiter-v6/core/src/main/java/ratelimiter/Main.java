package ratelimiter;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class Main {
    public static void main(String[] args) throws Exception {
        ManualClock clock = new ManualClock(0);
        Plans plans = new Plans();
        plans.set("globex", Plan.PRO);                                  // acme stays on FREE
        RuleBook rules = acmeRules(plans);
        RateLimiterService limiter = new RateLimiterService(rules, new LocalBucketStore(), clock);
        RefusalCounter refusals = new RefusalCounter();
        limiter.addListener(refusals);
        ApiFilter api = new ApiFilter(limiter);

        // acme, on FREE (5 a second), sends 7 at once: 5 pass, then its client rule says no
        for (int i = 1; i <= 7; i++) {
            System.out.println("t=0     acme   /items   #" + i + "  " + limiter.check(Request.of("acme", "/items")));
        }
        // globex, on PRO, searches 3 times: the search rule stops the 3rd, and the token the
        // pro-client rule took for it goes back, so its next request shows 47 left, not 46
        for (int i = 1; i <= 3; i++) {
            System.out.println("t=0     globex /search  #" + i + "  " + limiter.check(Request.of("globex", "/search")));
        }
        Decision next = limiter.check(Request.of("globex", "/items"));
        System.out.println("t=0     globex /items       " + next);
        check(next.remaining() == 47, "a refused request is charged by no rule");

        // at the edge, a refusal becomes 429 with Retry-After in whole seconds
        System.out.println("t=0     HTTP   acme /items  " + api.handle(Request.of("acme", "/items")));

        // a second later: a request costing 3 fits; one costing 6 can never fit a limit of 5
        clock.advance(1_000);
        System.out.println("t=1000  acme   cost 3       " + limiter.check(new Request("acme", "/export", 3)));
        System.out.println("t=1000  acme   cost 6       " + limiter.check(new Request("acme", "/export", 6)));
        System.out.println("refusals by rule: free-client " + refusals.refusedBy("free-client")
                + ", search " + refusals.refusedBy("search") + ", global " + refusals.refusedBy("global"));

        race(TokenBucket::new);
    }

    // The example's four rules, as config: the narrowest first, the global cap last.
    static RuleBook acmeRules(Plans plans) {
        return new RuleBook(List.of(
                new Rule("free-client", r -> plans.of(r.clientId()) == Plan.FREE, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new),
                new Rule("pro-client", r -> plans.of(r.clientId()) == Plan.PRO, Scope.CLIENT, Limit.perSecond(50), TokenBucket::new),
                new Rule("search", r -> r.endpoint().equals("/search"), Scope.CLIENT_ENDPOINT, Limit.perSecond(2), TokenBucket::new),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perSecond(60), TokenBucket::new)));
    }

    // 100 threads, 100 clients, 1,000 requests per thread, on a frozen clock. Each client may pass
    // 500 a day, but the global cap is 30,000: exactly 30,000 pass, and none charges a refused one.
    static void race(Algorithm algorithm) throws Exception {
        ManualClock clock = new ManualClock(0);
        RateLimiterService limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("client", r -> true, Scope.CLIENT, new Limit(500, 86_400_000), algorithm),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perMinute(30_000), algorithm))),
                new LocalBucketStore(), clock);
        AtomicInteger passed = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();                                          // all 100 start together
                for (int i = 0; i < 1_000; i++) {
                    if (limiter.check(Request.of("client-" + i % 100, "/items")).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("race    100 threads, 100,000 requests: " + passed.get() + " allowed");
        check(passed.get() == 30_000, "never more than any rule allows, whatever the thread count");

        // a minute later the global cap is full again; each client can spend exactly what it
        // did not use, so the refused requests must all have been refunded: 100 x 500 - 30,000
        clock.advance(60_000);
        int more = 0;
        for (int c = 0; c < 100; c++) {
            for (int i = 0; i < 600; i++) if (limiter.check(Request.of("client-" + c, "/items")).allowed()) more++;
        }
        System.out.println("after   a minute, each client's unused budget: " + more + " allowed");
        check(more == 20_000, "a refused request is charged by no rule");
    }

    static void check(boolean ok, String promise) {
        if (!ok) throw new AssertionError("broken: " + promise);
    }
}
