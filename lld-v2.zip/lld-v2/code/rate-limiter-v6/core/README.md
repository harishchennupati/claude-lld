# Rate limiter · core

Generated from `rate-limiter-v6/wb/Main.java`, snapshot `core`: the same code the workbench page shows, compiled and run.

- **IntelliJ:** File > Open > this folder (it reads `pom.xml`), then run `ratelimiter.Main`.
- **Terminal:** `./run.sh`, or `mvn -q compile exec:java`.
- One top-level type per file, in package `ratelimiter`. `Main` holds the demo and the checks; a broken
  promise throws `AssertionError`.

Files: Request.java, Limit.java, Decision.java, Plan.java, Plans.java, Scope.java, Clock.java, SystemClock.java, ManualClock.java, Bucket.java, Algorithm.java, TokenBucket.java, Rule.java, RuleBook.java, BucketStore.java, LocalBucketStore.java, RateLimiter.java, DecisionListener.java, RefusalCounter.java, RateLimiterService.java, Response.java, ApiFilter.java, Main.java
