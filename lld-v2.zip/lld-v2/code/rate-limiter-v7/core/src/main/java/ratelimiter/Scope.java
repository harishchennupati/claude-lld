package ratelimiter;

// Whose budget a rule counts against. Each value turns a request into the key of a budget.
enum Scope {
    CLIENT          { String key(Request r) { return r.clientId(); } },
    CLIENT_ENDPOINT { String key(Request r) { return r.clientId() + " " + r.endpoint(); } },
    GLOBAL          { String key(Request r) { return "*"; } };

    abstract String key(Request r);
}
