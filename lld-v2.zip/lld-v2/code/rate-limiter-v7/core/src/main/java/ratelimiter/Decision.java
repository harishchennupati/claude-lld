package ratelimiter;

// The answer to a check. If allowed: the budget left. If refused: how long to wait, and which rule refused.
record Decision(boolean allowed, long remaining, long retryAfterMillis, String ruleId) {
    static final long NEVER = -1;             // for a request that costs more than a whole bucket
    static Decision allow(long remaining) { return new Decision(true, remaining, 0, ""); }
    static Decision deny(long waitMillis) { return new Decision(false, 0, waitMillis, ""); }
    Decision by(String ruleId)            { return new Decision(allowed, remaining, retryAfterMillis, ruleId); }

    @Override public String toString() {
        if (allowed) return remaining == Long.MAX_VALUE ? "allowed" : "allowed, " + remaining + " left";
        return "refused by " + ruleId + (retryAfterMillis == NEVER ? ", can never fit" : ", retry in " + retryAfterMillis + " ms");
    }
}
