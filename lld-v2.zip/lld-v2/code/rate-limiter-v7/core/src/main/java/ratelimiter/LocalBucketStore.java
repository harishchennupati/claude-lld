package ratelimiter;

import java.util.concurrent.*;

class LocalBucketStore implements BucketStore {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        // one bucket per rule and key, created once, even when two threads see a new key at the same time
        return buckets.computeIfAbsent(rule.id() + "|" + key,
                k -> rule.algorithm().newBucket(rule.limit(), nowMillis));
    }
}
