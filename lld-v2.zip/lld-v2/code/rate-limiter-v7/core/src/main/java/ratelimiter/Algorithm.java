package ratelimiter;

// Creates the bucket for a rule's limit. TokenBucket::new is one.
interface Algorithm {
    Bucket newBucket(Limit limit, long nowMillis);
}
