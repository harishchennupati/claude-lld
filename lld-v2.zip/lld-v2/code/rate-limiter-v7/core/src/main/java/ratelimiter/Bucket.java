package ratelimiter;

// The budget for one rule and one key. Each counting method is a class that implements it.
interface Bucket {
    Decision tryTake(int cost, long nowMillis);    // take `cost` units now, or say how long until they are there
    void refund(int cost, long nowMillis);         // give back units that tryTake took
}
