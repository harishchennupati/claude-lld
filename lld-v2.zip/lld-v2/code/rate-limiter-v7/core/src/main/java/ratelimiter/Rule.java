package ratelimiter;

import java.util.function.*;

// A rule: which requests it covers, whose budget it counts against, how many units, and how it counts.
record Rule(String id, Predicate<Request> appliesTo, Scope scope, Limit limit, Algorithm algorithm) { }
