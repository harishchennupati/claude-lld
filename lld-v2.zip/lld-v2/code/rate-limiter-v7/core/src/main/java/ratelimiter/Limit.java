package ratelimiter;

// A limit: at most `permits` units in each window. 100 a minute is Limit.perMinute(100).
record Limit(int permits, long windowMillis) {
    Limit {
        if (permits <= 0 || windowMillis <= 0) throw new IllegalArgumentException("must be > 0");
    }
    static Limit perSecond(int n) { return new Limit(n, 1_000); }
    static Limit perMinute(int n) { return new Limit(n, 60_000); }
}
