package ratelimiter;

// Anyone who wants to hear about decisions, such as metrics or an audit log. Told after each decision.
interface DecisionListener {
    void onDecision(Request request, Decision decision);
}
