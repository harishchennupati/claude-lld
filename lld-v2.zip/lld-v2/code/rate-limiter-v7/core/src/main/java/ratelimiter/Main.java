package ratelimiter;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class Main {
    public static void main(String[] args) throws Exception {
        ManualClock clock = new ManualClock(0);
        Plans plans = new Plans();
        plans.set("travel-app", Plan.PRO);                              // weather-widget stays on FREE
        RuleBook rules = exampleRules(plans);
        RateLimiterService limiter = new RateLimiterService(rules, new LocalBucketStore(), clock);
        RefusalCounter refusals = new RefusalCounter();
        limiter.addListener(refusals);
        ApiFilter api = new ApiFilter(limiter);

        // weather-widget, on FREE (5 a second), sends 7 at once: 5 pass, then free-plan refuses
        for (int i = 1; i <= 7; i++) {
            show(0, "weather-widget", "/forecast #" + i, limiter.check(Request.of("weather-widget", "/forecast")));
        }
        // travel-app, on PRO, searches 3 times: the search rule refuses the 3rd, and the token that
        // pro-plan took for it is given back, so its next request shows 47 left, not 46
        for (int i = 1; i <= 3; i++) {
            show(0, "travel-app", "/search #" + i, limiter.check(Request.of("travel-app", "/search")));
        }
        Decision next = limiter.check(Request.of("travel-app", "/forecast"));
        show(0, "travel-app", "/forecast", next);
        check(next.remaining() == 47, "a refused request uses no budget");

        // through the filter, a refusal becomes HTTP 429, with Retry-After in whole seconds
        show(0, "weather-widget", "HTTP /forecast", api.handle(Request.of("weather-widget", "/forecast")));

        // a second later: a request costing 3 fits; one costing 6 can never fit a limit of 5
        clock.advance(1_000);
        show(1_000, "weather-widget", "/export cost 3", limiter.check(new Request("weather-widget", "/export", 3)));
        show(1_000, "weather-widget", "/export cost 6", limiter.check(new Request("weather-widget", "/export", 6)));
        System.out.println("refusals by rule: free-plan " + refusals.refusedBy("free-plan")
                + ", search " + refusals.refusedBy("search") + ", global " + refusals.refusedBy("global"));

        race(TokenBucket::new);
    }

    // The example's four rules, as configuration: the narrowest first, the global limit last.
    static RuleBook exampleRules(Plans plans) {
        return new RuleBook(List.of(
                new Rule("free-plan", r -> plans.of(r.clientId()) == Plan.FREE, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new),
                new Rule("pro-plan", r -> plans.of(r.clientId()) == Plan.PRO, Scope.CLIENT, Limit.perSecond(50), TokenBucket::new),
                new Rule("search", r -> r.endpoint().equals("/search"), Scope.CLIENT_ENDPOINT, Limit.perSecond(2), TokenBucket::new),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perSecond(100), TokenBucket::new)));
    }

    // One line of the demo: when, who, what, and the answer.
    static void show(long atMillis, String client, String call, Object answer) {
        System.out.printf("%5d ms  %-15s %-16s %s%n", atMillis, client, call, answer);
    }

    // 100 threads, 100 clients, 1,000 requests per thread, on a clock that stands still. Each client
    // may make 500 a day, but the global limit is 30,000: exactly 30,000 must pass.
    static void race(Algorithm algorithm) throws Exception {
        ManualClock clock = new ManualClock(0);
        RateLimiterService limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("client", r -> true, Scope.CLIENT, new Limit(500, 86_400_000), algorithm),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perMinute(30_000), algorithm))),
                new LocalBucketStore(), clock);
        AtomicInteger passed = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();                                          // all 100 start together
                for (int i = 0; i < 1_000; i++) {
                    if (limiter.check(Request.of("client-" + i % 100, "/forecast")).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("race    100 threads, 100,000 requests: " + passed.get() + " allowed");
        check(passed.get() == 30_000, "no limit is exceeded, however many threads");

        // a minute later the global limit is full again. Each client can spend exactly what it did not
        // use, which is right only if every refused request was refunded: 100 x 500 - 30,000
        clock.advance(60_000);
        int more = 0;
        for (int c = 0; c < 100; c++) {
            for (int i = 0; i < 600; i++) if (limiter.check(Request.of("client-" + c, "/forecast")).allowed()) more++;
        }
        System.out.println("after   a minute, each client's unused budget: " + more + " allowed");
        check(more == 20_000, "a refused request uses no budget");
    }

    static void check(boolean ok, String promise) {
        if (!ok) throw new AssertionError("broken: " + promise);
    }
}
