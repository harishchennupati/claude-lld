package ratelimiter;

// Where the current time comes from. It is passed in, so a test can move time instead of sleeping.
interface Clock {
    long millis();
}
