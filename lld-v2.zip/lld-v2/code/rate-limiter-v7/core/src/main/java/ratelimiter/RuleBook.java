package ratelimiter;

import java.util.*;

// All the rules, in the order they are checked: the narrowest first, the global limit last.
class RuleBook {
    private final List<Rule> rules;
    RuleBook(List<Rule> rules)     { this.rules = List.copyOf(rules); }
    List<Rule> rulesFor(Request r) { return rules.stream().filter(x -> x.appliesTo().test(r)).toList(); }
}
