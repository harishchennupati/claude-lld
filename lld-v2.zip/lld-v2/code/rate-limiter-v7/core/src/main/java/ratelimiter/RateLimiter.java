package ratelimiter;

// The one question the API asks before it does any work for a request.
interface RateLimiter {
    Decision check(Request request);
}
