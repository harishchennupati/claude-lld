# Rate limiter · after every follow-up

Generated from `rate-limiter-v7/wb/Main.java`, snapshot `extra`: the same code the workbench page shows, compiled and run.

- **IntelliJ:** File > Open > this folder (it reads `pom.xml`), then run `ratelimiter.Main`.
- **Terminal:** `./run.sh`, or `mvn -q compile exec:java`.
- One top-level type per file, in package `ratelimiter`. `Main` holds the demo and the checks; a broken
  promise throws `AssertionError`.

Files: Request.java, Limit.java, Decision.java, Plan.java, Plans.java, Scope.java, Clock.java, SystemClock.java, ManualClock.java, Bucket.java, Algorithm.java, TokenBucket.java, SlidingWindowLog.java, Rule.java, RuleBook.java, BucketStore.java, LocalBucketStore.java, RateLimiter.java, DecisionListener.java, RefusalCounter.java, RateLimiterService.java, Response.java, ApiFilter.java, Waiting.java, ShadowLimiter.java, Redis.java, RedisTokenBucket.java, Breaker.java, FallbackBucket.java, RedisBucketStore.java, LeasedBucket.java, LeasingStore.java, CasTokenBucket.java, HitCounter.java, Main.java
