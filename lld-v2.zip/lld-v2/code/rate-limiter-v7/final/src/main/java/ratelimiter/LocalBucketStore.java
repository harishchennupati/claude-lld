package ratelimiter;

import java.util.*;
import java.util.concurrent.*;

class LocalBucketStore implements BucketStore {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        // one bucket per rule and key, created once, even when two threads see a new key at the same time
        return buckets.computeIfAbsent(rule.id() + "|" + rule.limit() + "|" + key,   // a new limit gets a new bucket
                k -> rule.algorithm().newBucket(rule.limit(), nowMillis));
    }

    // Removes buckets that have been idle for a whole window. A timer calls it, never a request.
    int evictIdle(long nowMillis) {
        int removed = 0;
        for (Map.Entry<String, Bucket> e : buckets.entrySet()) {
            // remove(key, value) removes the entry only if the map still holds this same bucket
            if (e.getValue().isIdle(nowMillis) && buckets.remove(e.getKey(), e.getValue())) removed++;
        }
        return removed;
    }

    int size() { return buckets.size(); }
}
