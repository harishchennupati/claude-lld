package ratelimiter;

import java.util.*;
import java.util.concurrent.*;

// Runs one check: every rule that covers the request must allow it, or no rule's budget is used.
class RateLimiterService implements RateLimiter {
    private volatile RuleBook rules;          // replaced whole when the operations team changes a rule
    private final BucketStore store;
    private final Clock clock;
    private final List<DecisionListener> listeners = new CopyOnWriteArrayList<>();

    RateLimiterService(RuleBook rules, BucketStore store, Clock clock) {
        this.rules = rules;
        this.store = store;
        this.clock = clock;
    }

    void addListener(DecisionListener listener) { listeners.add(listener); }

    void replaceRules(RuleBook newRules) { rules = newRules; }    // the next request sees the new book

    @Override
    public Decision check(Request request) {
        long now = clock.millis();
        Decision result = Decision.allow(Long.MAX_VALUE);
        List<Bucket> charged = new ArrayList<>();
        for (Rule rule : rules.rulesFor(request)) {
            Bucket bucket = store.bucket(rule, rule.scope().key(request), now);
            Decision d = bucket.tryTake(request.cost(), now);
            if (!d.allowed()) {
                for (Bucket b : charged) b.refund(request.cost(), now);   // give back what the earlier rules took
                result = d.by(rule.id());
                break;
            }
            charged.add(bucket);
            result = Decision.allow(Math.min(result.remaining(), d.remaining()));
        }
        for (DecisionListener l : listeners) {
            try { l.onDecision(request, result); }
            catch (RuntimeException e) { /* a broken listener must never break the limiter */ }
        }
        return result;
    }
}
