package ratelimiter;

import java.util.concurrent.atomic.*;

// A decorator: it enforces the live rules, and also asks a candidate limiter built with new rules,
// counting what the candidate would have refused. It tries a stricter rule without refusing anyone.
class ShadowLimiter implements RateLimiter {
    private final RateLimiter live;
    private final RateLimiter candidate;
    private final LongAdder wouldRefuse = new LongAdder();

    ShadowLimiter(RateLimiter live, RateLimiter candidate) {
        this.live = live;
        this.candidate = candidate;
    }

    @Override
    public Decision check(Request request) {
        Decision d = live.check(request);
        if (d.allowed() && !candidate.check(request).allowed()) wouldRefuse.increment();   // and log it
        return d;
    }

    long wouldHaveRefused() { return wouldRefuse.sum(); }
}
