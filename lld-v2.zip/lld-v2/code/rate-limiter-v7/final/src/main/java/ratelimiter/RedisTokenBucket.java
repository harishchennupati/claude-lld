package ratelimiter;

import java.util.*;

// A proxy: it looks like a Bucket, but its numbers live in Redis, and each call runs a script there.
// Redis runs one script at a time, so the script does for all servers what synchronized does here.
class RedisTokenBucket implements Bucket {
    static final String TAKE = """
        local capacity, window, cost = tonumber(ARGV[1]), tonumber(ARGV[2]), tonumber(ARGV[3])
        local t = redis.call('TIME')                   -- Redis's clock: every server agrees
        local now = t[1] * 1000 + math.floor(t[2] / 1000)
        local b = redis.call('HMGET', KEYS[1], 'tokens', 'last')
        local tokens = tonumber(b[1]) or capacity       -- a new key starts full
        local last = tonumber(b[2]) or now
        if now > last then
          tokens = math.min(capacity, tokens + (now - last) * capacity / window)
          last = now
        end
        local allowed, wait = 0, 0
        if tokens >= cost then
          tokens, allowed = tokens - cost, 1
        else
          wait = math.ceil((cost - tokens) * window / capacity)
        end
        redis.call('HSET', KEYS[1], 'tokens', tostring(tokens), 'last', last)
        redis.call('PEXPIRE', KEYS[1], window)         -- unused for a window: Redis forgets it
        return {allowed, math.floor(tokens), wait}
        """;
    static final String REFUND = """
        local capacity, cost = tonumber(ARGV[1]), tonumber(ARGV[2])
        local tokens = tonumber(redis.call('HGET', KEYS[1], 'tokens'))
        if tokens then redis.call('HSET', KEYS[1], 'tokens', tostring(math.min(capacity, tokens + cost))) end
        return {1}
        """;

    private final Redis redis;
    private final String key;
    private final Limit limit;

    RedisTokenBucket(Redis redis, String key, Limit limit) {
        this.redis = redis;
        this.key = key;
        this.limit = limit;
    }

    @Override
    public Decision tryTake(int cost, long nowMillis) {             // uses Redis's clock, not nowMillis
        if (cost > limit.permits()) return Decision.deny(Decision.NEVER);
        List<Long> r = redis.eval(TAKE, List.of(key),
                List.of(String.valueOf(limit.permits()), String.valueOf(limit.windowMillis()), String.valueOf(cost)));
        return r.get(0) == 1 ? Decision.allow(r.get(1)) : Decision.deny(r.get(2));
    }

    @Override
    public void refund(int cost, long nowMillis) {
        redis.eval(REFUND, List.of(key), List.of(String.valueOf(limit.permits()), String.valueOf(cost)));
    }

    @Override
    public boolean isIdle(long nowMillis) { return false; }         // Redis deletes idle keys itself
}
