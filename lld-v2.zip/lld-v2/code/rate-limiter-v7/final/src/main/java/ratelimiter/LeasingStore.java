package ratelimiter;

import java.util.concurrent.*;

// A decorator over any store: one LeasedBucket per rule and key on this server.
class LeasingStore implements BucketStore {
    private final BucketStore remote;
    private final int batch;
    private final ConcurrentHashMap<String, Bucket> local = new ConcurrentHashMap<>();

    LeasingStore(BucketStore remote, int batch) {
        this.remote = remote;
        this.batch = batch;
    }

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        return local.computeIfAbsent(rule.id() + "|" + key,
                k -> new LeasedBucket(remote.bucket(rule, key, nowMillis), batch));
    }
}
