package ratelimiter;

// Opens after `threshold` failures in a row, and stays open for `cooldownMillis`. While it is open,
// nobody waits on a Redis that keeps failing.
class Breaker {
    private final int threshold;
    private final long cooldownMillis;
    private int failures;
    private long openUntil;

    Breaker(int threshold, long cooldownMillis) {
        this.threshold = threshold;
        this.cooldownMillis = cooldownMillis;
    }

    synchronized boolean isOpen(long nowMillis) { return nowMillis < openUntil; }
    synchronized void success()                  { failures = 0; }
    synchronized void failure(long nowMillis) {
        if (++failures >= threshold) {
            openUntil = nowMillis + cooldownMillis;
            failures = 0;
        }
    }
}
