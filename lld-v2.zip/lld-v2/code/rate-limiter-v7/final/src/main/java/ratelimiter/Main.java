package ratelimiter;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;

public class Main {
    public static void main(String[] args) throws Exception {
        ManualClock clock = new ManualClock(0);
        Plans plans = new Plans();
        plans.set("travel-app", Plan.PRO);                              // weather-widget stays on FREE
        RuleBook rules = exampleRules(plans);
        RateLimiterService limiter = new RateLimiterService(rules, new LocalBucketStore(), clock);
        RefusalCounter refusals = new RefusalCounter();
        limiter.addListener(refusals);
        ApiFilter api = new ApiFilter(limiter);

        // weather-widget, on FREE (5 a second), sends 7 at once: 5 pass, then free-plan refuses
        for (int i = 1; i <= 7; i++) {
            show(0, "weather-widget", "/forecast #" + i, limiter.check(Request.of("weather-widget", "/forecast")));
        }
        // travel-app, on PRO, searches 3 times: the search rule refuses the 3rd, and the token that
        // pro-plan took for it is given back, so its next request shows 47 left, not 46
        for (int i = 1; i <= 3; i++) {
            show(0, "travel-app", "/search #" + i, limiter.check(Request.of("travel-app", "/search")));
        }
        Decision next = limiter.check(Request.of("travel-app", "/forecast"));
        show(0, "travel-app", "/forecast", next);
        check(next.remaining() == 47, "a refused request uses no budget");

        // through the filter, a refusal becomes HTTP 429, with Retry-After in whole seconds
        show(0, "weather-widget", "HTTP /forecast", api.handle(Request.of("weather-widget", "/forecast")));

        // a second later: a request costing 3 fits; one costing 6 can never fit a limit of 5
        clock.advance(1_000);
        show(1_000, "weather-widget", "/export cost 3", limiter.check(new Request("weather-widget", "/export", 3)));
        show(1_000, "weather-widget", "/export cost 6", limiter.check(new Request("weather-widget", "/export", 6)));
        System.out.println("refusals by rule: free-plan " + refusals.refusedBy("free-plan")
                + ", search " + refusals.refusedBy("search") + ", global " + refusals.refusedBy("global"));

        race(TokenBucket::new);
        e1ExactLogins();
        e2ChangeRule();
        e3Waiting();
        e4Shadow();
        e5EvictIdle();
        s1ManyServers();
        s2RedisDown();
        s3Leasing();
        extraAnswers();
    }

    // The example's four rules, as configuration: the narrowest first, the global limit last.
    static RuleBook exampleRules(Plans plans) {
        return new RuleBook(List.of(
                new Rule("free-plan", r -> plans.of(r.clientId()) == Plan.FREE, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new),
                new Rule("pro-plan", r -> plans.of(r.clientId()) == Plan.PRO, Scope.CLIENT, Limit.perSecond(50), TokenBucket::new),
                new Rule("search", r -> r.endpoint().equals("/search"), Scope.CLIENT_ENDPOINT, Limit.perSecond(2), TokenBucket::new),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perSecond(100), TokenBucket::new)));
    }

    // One line of the demo: when, who, what, and the answer.
    static void show(long atMillis, String client, String call, Object answer) {
        System.out.printf("%5d ms  %-15s %-16s %s%n", atMillis, client, call, answer);
    }

    // 100 threads, 100 clients, 1,000 requests per thread, on a clock that stands still. Each client
    // may make 500 a day, but the global limit is 30,000: exactly 30,000 must pass.
    static void race(Algorithm algorithm) throws Exception {
        ManualClock clock = new ManualClock(0);
        RateLimiterService limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("client", r -> true, Scope.CLIENT, new Limit(500, 86_400_000), algorithm),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perMinute(30_000), algorithm))),
                new LocalBucketStore(), clock);
        AtomicInteger passed = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();                                          // all 100 start together
                for (int i = 0; i < 1_000; i++) {
                    if (limiter.check(Request.of("client-" + i % 100, "/forecast")).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("race    100 threads, 100,000 requests: " + passed.get() + " allowed");
        check(passed.get() == 30_000, "no limit is exceeded, however many threads");

        // a minute later the global limit is full again. Each client can spend exactly what it did not
        // use, which is right only if every refused request was refunded: 100 x 500 - 30,000
        clock.advance(60_000);
        int more = 0;
        for (int c = 0; c < 100; c++) {
            for (int i = 0; i < 600; i++) if (limiter.check(Request.of("client-" + c, "/forecast")).allowed()) more++;
        }
        System.out.println("after   a minute, each client's unused budget: " + more + " allowed");
        check(more == 20_000, "a refused request uses no budget");
    }

    static void e1ExactLogins() {
        for (String name : List.of("TokenBucket", "SlidingWindowLog")) {
            ManualClock clock = new ManualClock(0);
            Algorithm algorithm = name.equals("TokenBucket") ? TokenBucket::new : SlidingWindowLog::new;
            Rule login = new Rule("login", r -> r.endpoint().equals("/login"), Scope.CLIENT_ENDPOINT, Limit.perMinute(5), algorithm);
            RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(login)), new LocalBucketStore(), clock);
            int passed = 0;
            for (int i = 0; i < 5; i++) if (limiter.check(Request.of("ravi", "/login")).allowed()) passed++;
            for (int s = 1; s < 60; s++) {
                clock.advance(1_000);
                if (limiter.check(Request.of("ravi", "/login")).allowed()) passed++;
            }
            System.out.println("e1  " + name + ": " + passed + " logins passed in the first minute");
            check(passed == (name.equals("TokenBucket") ? 9 : 5), "e1 " + name);
        }
    }

    static void e2ChangeRule() {
        ManualClock clock = new ManualClock(0);
        Rule free5 = new Rule("free-plan", r -> true, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new);
        RateLimiterService limiter = new RateLimiterService(new RuleBook(List.of(free5)), new LocalBucketStore(), clock);
        for (int i = 0; i < 5; i++) limiter.check(Request.of("weather-widget", "/forecast"));
        System.out.println("e2  before the change: " + limiter.check(Request.of("weather-widget", "/forecast")));
        Rule free10 = new Rule("free-plan", r -> true, Scope.CLIENT, Limit.perSecond(10), TokenBucket::new);
        limiter.replaceRules(new RuleBook(List.of(free10)));     // the operations team raises FREE to 10 a second
        int passed = 0;
        for (int i = 0; i < 12; i++) if (limiter.check(Request.of("weather-widget", "/forecast")).allowed()) passed++;
        System.out.println("e2  after the change:  " + passed + " of 12 at once");
        check(passed == 10, "e2 a new limit takes effect on the next request");
    }

    static void e3Waiting() throws InterruptedException {
        RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("batch", r -> true, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new))),
                new LocalBucketStore(), new SystemClock());
        long start = System.nanoTime();
        List<Long> at = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            check(Waiting.acquire(limiter, Request.of("batch-job", "/forecast"), 1_000), "e3 acquire within 1 s");
            at.add(Math.round((System.nanoTime() - start) / 1e6 / 100.0) * 100);
        }
        System.out.println("e3  8 requests, passed at about (ms): " + at);
        boolean quick = Waiting.acquire(limiter, Request.of("batch-job", "/forecast"), 50);
        System.out.println("e3  the next one, with only 50 ms to wait: " + quick);
        check(!quick && at.get(7) >= 500, "e3 waits its turn, and gives up early");
    }

    static void e4Shadow() {
        ManualClock clock = new ManualClock(0);
        RateLimiter live = new RateLimiterService(new RuleBook(List.of(
                new Rule("free-plan", r -> true, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new))),
                new LocalBucketStore(), clock);
        RateLimiter stricter = new RateLimiterService(new RuleBook(List.of(
                new Rule("free-plan", r -> true, Scope.CLIENT, Limit.perSecond(3), TokenBucket::new))),
                new LocalBucketStore(), clock);
        ShadowLimiter shadow = new ShadowLimiter(live, stricter);   // the API is given this instead
        int passed = 0;
        for (int i = 0; i < 5; i++) if (shadow.check(Request.of("weather-widget", "/forecast")).allowed()) passed++;
        System.out.println("e4  live let " + passed + " of 5 through; the stricter rule would have refused "
                + shadow.wouldHaveRefused());
        check(passed == 5 && shadow.wouldHaveRefused() == 2, "e4 shadow mode");
    }

    static void e5EvictIdle() {
        ManualClock clock = new ManualClock(0);
        LocalBucketStore store = new LocalBucketStore();
        RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("client", r -> true, Scope.CLIENT, Limit.perMinute(100), TokenBucket::new))), store, clock);
        for (int i = 0; i < 100_000; i++) limiter.check(Request.of("key-" + i, "/forecast"));
        clock.advance(30_000);
        limiter.check(Request.of("key-7", "/forecast"));                   // one client stays busy
        int early = store.evictIdle(clock.millis());
        clock.advance(30_000);
        int late = store.evictIdle(clock.millis());
        System.out.println("e5  100,000 clients: evicted " + early + " at 30 s, " + late + " at 60 s, " + store.size() + " left");
        check(early == 0 && late == 99_999 && store.size() == 1, "e5 eviction");
    }

    // No Redis on this machine: a stand-in runs the same arithmetic as the Lua scripts, one call at
    // a time as Redis does, on its own clock (Redis's TIME). It checks the Java side; the Lua was
    // run separately under Lua 5.1, the version inside Redis.
    static final class RedisStandIn implements Redis {
        final Map<String, double[]> hashes = new HashMap<>();           // key -> {tokens, last}
        final ManualClock time = new ManualClock(0);
        final AtomicInteger calls = new AtomicInteger();
        volatile boolean down;

        @Override
        public synchronized List<Long> eval(String script, List<String> keys, List<String> args) {
            calls.incrementAndGet();
            if (down) throw new IllegalStateException("redis timeout");
            double capacity = Double.parseDouble(args.get(0));
            if (script.equals(RedisTokenBucket.REFUND)) {
                double[] h = hashes.get(keys.get(0));
                if (h != null) h[0] = Math.min(capacity, h[0] + Double.parseDouble(args.get(1)));
                return List.of(1L);
            }
            double window = Double.parseDouble(args.get(1)), cost = Double.parseDouble(args.get(2));
            long now = time.millis();
            double[] h = hashes.computeIfAbsent(keys.get(0), k -> new double[] {capacity, now});
            if (now > h[1]) {
                h[0] = Math.min(capacity, h[0] + (now - h[1]) * capacity / window);
                h[1] = now;
            }
            if (h[0] >= cost) {
                h[0] -= cost;
                return List.of(1L, (long) Math.floor(h[0]), 0L);
            }
            return List.of(0L, (long) Math.floor(h[0]), (long) Math.ceil((cost - h[0]) * window / capacity));
        }
    }

    static List<RateLimiter> servers(int n, Function<Integer, BucketStore> store, List<Rule> rules) {
        List<RateLimiter> out = new ArrayList<>();
        for (int i = 0; i < n; i++) out.add(new RateLimiterService(new RuleBook(rules), store.apply(i), new ManualClock(0)));
        return out;
    }

    static void s1ManyServers() {
        RedisStandIn redis = new RedisStandIn();
        List<Rule> rules = List.of(
                new Rule("client", r -> true, Scope.CLIENT, Limit.perMinute(100), TokenBucket::new),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perMinute(150), TokenBucket::new));
        List<RateLimiter> three = servers(3, i -> new RedisBucketStore(redis, Set.of()), rules);
        int widget = 0, travel = 0;
        for (int i = 0; i < 400; i++) {
            String client = i % 2 == 0 ? "weather-widget" : "travel-app";
            boolean ok = three.get(i % 3).check(Request.of(client, "/forecast")).allowed();
            if (ok && client.equals("weather-widget")) widget++;
            if (ok && client.equals("travel-app")) travel++;
        }
        System.out.println("s1  3 servers, 400 requests: weather-widget " + widget + ", travel-app " + travel + ", together " + (widget + travel));
        check(widget + travel == 150 && widget <= 100 && travel <= 100, "s1 one budget per rule across servers");
    }

    static void s2RedisDown() {
        RedisStandIn redis = new RedisStandIn();
        redis.down = true;
        ManualClock clock = new ManualClock(0);
        BucketStore store = new RedisBucketStore(redis, Set.of("login"));   // logins fail closed
        RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("login", r -> r.endpoint().equals("/login"), Scope.CLIENT, Limit.perMinute(5), TokenBucket::new),
                new Rule("api", r -> !r.endpoint().equals("/login"), Scope.CLIENT, Limit.perMinute(100), TokenBucket::new))),
                store, clock);
        System.out.println("s2  Redis down, /login: " + limiter.check(Request.of("weather-widget", "/login")));
        int passed = 0;
        for (int i = 0; i < 5; i++) if (limiter.check(Request.of("weather-widget", "/forecast")).allowed()) passed++;
        System.out.println("s2  Redis down, /forecast: " + passed + " of 5 allowed; Redis was called " + redis.calls.get() + " times");
        int before = redis.calls.get();
        clock.advance(5_000);                                               // the breaker's cooldown ends
        limiter.check(Request.of("weather-widget", "/forecast"));
        System.out.println("s2  after the cooldown, Redis is tried again: " + (redis.calls.get() - before) + " call");
        check(passed == 5 && before == 3 && redis.calls.get() == 4, "s2 fail open or closed, and the breaker");
    }

    static void s3Leasing() {
        RedisStandIn redis = new RedisStandIn();
        List<Rule> rules = List.of(new Rule("client", r -> true, Scope.CLIENT, Limit.perMinute(100), TokenBucket::new));
        List<RateLimiter> three = servers(3, i -> new LeasingStore(new RedisBucketStore(redis, Set.of()), 10), rules);
        int passed = 0;
        for (int i = 0; i < 300; i++) if (three.get(i % 3).check(Request.of("weather-widget", "/forecast")).allowed()) passed++;
        System.out.println("s3  3 servers leasing 10 at a time: " + passed + " allowed, " + redis.calls.get()
                + " Redis calls instead of 300");
        check(passed == 100 && redis.calls.get() == 16, "s3 never over the limit, far fewer round trips");
    }

    static void extraAnswers() throws Exception {
        race(CasTokenBucket::new);                                          // the lock-free bucket, same race
        HitCounter hits = new HitCounter();
        hits.hit(1);
        hits.hit(2);
        hits.hit(3);
        hits.hit(300);
        System.out.println("extra HitCounter: " + hits.getHits(300) + " at 300 s, " + hits.getHits(301)
                + " at 301 s, " + hits.getHits(302) + " at 302 s");
        check(hits.getHits(300) == 4 && hits.getHits(301) == 3 && hits.getHits(302) == 2, "hit counter");
    }

    static void check(boolean ok, String promise) {
        if (!ok) throw new AssertionError("broken: " + promise);
    }
}
