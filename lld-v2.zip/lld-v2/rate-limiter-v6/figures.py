"""v6 figures: v5's figures, plus the full class diagram with the one call through it."""
import sys, os, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'tools'))
from lldkit import Svg, C  # type: ignore  # noqa: E402

_spec = importlib.util.spec_from_file_location('figures_v5', os.path.join(HERE, '..', 'rate-limiter-v5', 'figures.py'))
assert _spec is not None and _spec.loader is not None
v5 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v5)
fig_mini, fig_acme, fig_edge, fig_race_n, fig_fu1_n = v5.fig_mini, v5.fig_acme, v5.fig_edge, v5.fig_race_n, v5.fig_fu1_n
fig_d_all, fig_s_problem, fig_s_redis, fig_s_lease, fig_s_breaker = v5.fig_d_all, v5.fig_s_problem, v5.fig_s_redis, v5.fig_s_lease, v5.fig_s_breaker


def ub(s, x, y, w, name, fields=(), methods=(), kind='class'):
    """A UML box. kind: class | interface | record | enum. Returns its height."""
    head = 24 if kind == 'class' else 34
    lh = 15
    h = head + (len(fields) * lh + 10 if fields else 0) + (len(methods) * lh + 10 if methods else 0) + 2
    stroke = {'interface': C['blue'], 'record': C['teal'], 'enum': C['teal']}.get(kind, C['line'])
    s.rect(x, y, w, h, fill=C['sur'], stroke=stroke, dash='5 3' if kind == 'interface' else None, sw=1.5)
    if kind == 'class':
        s.text(x + w / 2, y + 17, name, size=12.5, weight='600', anchor='middle')
    else:
        s.text(x + w / 2, y + 13, '«' + kind + '»', size=9.5, fill=C['mut'], anchor='middle')
        s.text(x + w / 2, y + 28, name, size=12.5, weight='600', anchor='middle')
    cy = y + head
    for rows, fill in ((fields, C['mut']), (methods, C['txt'])):
        if rows:
            s.line([(x, cy), (x + w, cy)], stroke=C['line'], sw=1)
            for i, r in enumerate(rows):
                s.text(x + 9, cy + 14 + i * lh, r, size=10.5, fill=fill)
            cy += len(rows) * lh + 10
    return h


def badge(s, x, y, n):
    s.circle(x, y, 8, C['acc'])
    s.text(x, y + 3.5, str(n), size=10, fill=C['bg'], anchor='middle', weight='700')


def fig_classes6():
    s = Svg(1000, 800)
    G, P = dict(stroke=C['green'], dash='5 3', end='arr-green'), dict(stroke=C['acc'], dash='2 3', end='arr-acc')
    # ---- top: the edge, and the one interface the API sees
    ub(s, 16, 14, 220, 'Response', ['status: int', 'headers: Map<String, String>'], kind='record')
    ub(s, 390, 14, 240, 'ApiFilter', ['limiter: RateLimiter'], ['handle(Request): Response'])
    ub(s, 390, 118, 240, 'RateLimiter', methods=['check(Request): Decision'], kind='interface')
    s.rect(660, 14, 324, 176, fill=C['sur'], stroke=C['teal'], sw=1.5)
    s.text(822, 30, '«record» values, passed everywhere', size=9.5, fill=C['mut'], anchor='middle')
    vals = [('Request(clientId, endpoint, int cost)', C['txt']), ('  of(clientId, endpoint): cost 1', C['mut']),
            ('Limit(int permits, long windowMillis)', C['txt']), ('  perSecond(n) · perMinute(n)', C['mut']),
            ('Decision(boolean allowed, long remaining,', C['txt']), ('         long retryAfterMillis, String ruleId)', C['txt']),
            ('  allow(left) · deny(wait) · by(ruleId)', C['mut']), ('  NEVER = -1: it can never fit', C['mut'])]
    for i, (t, f) in enumerate(vals):
        s.text(672, 52 + i * 17, t, size=10.5, fill=f)
    # ---- middle: the orchestrator, with listeners on its left and time on its right
    ub(s, 16, 214, 240, 'DecisionListener', methods=['onDecision(Request, Decision)'], kind='interface')
    ub(s, 355, 214, 310, 'RateLimiterService', ['rules: RuleBook', 'store: BucketStore', 'clock: Clock',
                                                 'listeners: List<DecisionListener>'],
       ['check(Request): Decision', 'addListener(DecisionListener)'])
    ub(s, 764, 214, 220, 'Clock', methods=['millis(): long'], kind='interface')
    ub(s, 16, 304, 240, 'RefusalCounter', ['byRule: Map<String, LongAdder>'], ['onDecision(request, d)', 'refusedBy(ruleId): long'])
    ub(s, 764, 304, 106, 'SystemClock', methods=['millis()'])
    ub(s, 878, 304, 106, 'ManualClock', ['now: long'], ['advance(ms)'])
    # ---- bottom left: the rules, as data
    ub(s, 16, 440, 200, 'RuleBook', ['rules: List<Rule>, in order'], ['rulesFor(Request): List<Rule>'])
    ub(s, 250, 440, 220, 'Rule', ['id: String', 'appliesTo: Predicate<Request>', 'scope: Scope', 'limit: Limit',
                                  'algorithm: Algorithm'], kind='record')
    ub(s, 16, 560, 200, 'Plans', ['byClient: Map<String, Plan>'], ['of(clientId): Plan', 'set(clientId, plan)'])
    ub(s, 16, 680, 200, 'Plan', ['FREE · PRO'], kind='enum')
    ub(s, 250, 590, 220, 'Scope', ['CLIENT          → "acme"', 'CLIENT_ENDPOINT → "acme /search"', 'GLOBAL          → "*"'],
       ['key(Request): String'], kind='enum')
    # ---- bottom right: counting, and where the buckets live
    ub(s, 500, 470, 220, 'Bucket', methods=['tryTake(cost, now): Decision', 'refund(cost, now)'], kind='interface')
    ub(s, 500, 580, 220, 'TokenBucket', ['capacity: int', 'windowMillis: long', 'tokens: double', 'lastRefillMillis: long'],
       ['synchronized tryTake(cost, now)', 'synchronized refund(cost, now)', 'refill(now)'])
    ub(s, 764, 440, 220, 'BucketStore', methods=['bucket(Rule, key, now): Bucket'], kind='interface')
    ub(s, 764, 528, 220, 'LocalBucketStore', ['buckets: ConcurrentHashMap', '  key: "ruleId|scope key"'],
       ['bucket(rule, key, now)'])
    ub(s, 764, 650, 220, 'Algorithm', methods=['newBucket(Limit, now): Bucket'], kind='interface')

    def lab(x, y, t, fill=None, anchor='middle'):
        s.text(x, y, t, size=9.5, fill=fill or C['dim'], anchor=anchor)
    # ---- arrows
    s.line([(510, 90), (510, 116)], end='arr'); lab(516, 107, 'calls', anchor='start')
    s.line([(390, 52), (238, 52)], end='arr'); lab(314, 46, 'returns')
    s.line([(510, 214), (510, 181)], end='tri')
    s.line([(355, 244), (258, 244)], end='arr'); lab(306, 238, 'tells, after')
    s.line([(136, 304), (136, 277)], end='tri')
    s.line([(665, 244), (762, 244)], **G); lab(713, 238, 'handed in', C['green'])
    s.line([(817, 304), (817, 277)], end='tri'); s.line([(931, 304), (931, 277)], end='tri')
    s.line([(400, 350), (400, 412), (116, 412), (116, 438)], **G); lab(258, 406, 'handed in', C['green'])
    s.line([(640, 350), (640, 412), (874, 412), (874, 438)], **G); lab(757, 406, 'handed in', C['green'])
    s.line([(580, 350), (580, 468)], end='arr'); lab(586, 450, 'tryTake · refund', anchor='start')
    s.line([(216, 478), (248, 478)], end='arr')
    s.line([(360, 561), (360, 588)], end='arr')
    s.line([(250, 548), (233, 548), (233, 600), (218, 600)], dash='2 3', end='arr')
    s.line([(116, 651), (116, 678)], end='arr')
    s.line([(874, 528), (874, 503)], end='tri')
    s.line([(764, 538), (722, 538)], start='dia', end='arr')
    s.line([(874, 619), (874, 648)], end='arr'); lab(880, 638, 'asks it', anchor='start')
    s.line([(764, 680), (722, 680)], **P); lab(743, 673, 'makes', C['acc'])
    s.line([(610, 580), (610, 548)], end='tri')
    # ---- one check, in order
    for x, y, n in [(496, 104, 1), (713, 257, 2), (258, 425, 3), (374, 575, 4), (757, 425, 5), (566, 440, 6),
                    (306, 257, 7), (314, 66, 8)]:
        badge(s, x, y, n)
    # ---- legend
    y = 762
    s.line([(16, y), (46, y)], end='tri'); lab(52, y + 4, 'implements', C['mut'], 'start')
    s.line([(140, y), (170, y)], start='dia', end='arr'); lab(176, y + 4, 'owns: one per rule and key', C['mut'], 'start')
    s.line([(350, y), (380, y)], **G); lab(386, y + 4, 'handed in through the constructor', C['mut'], 'start')
    s.line([(580, y), (610, y)], **P); lab(616, y + 4, 'makes', C['mut'], 'start')
    s.line([(666, y), (696, y)], end='arr'); lab(702, y + 4, 'calls, holds or returns', C['mut'], 'start')
    s.line([(846, y), (876, y)], dash='2 3', end='arr'); lab(882, y + 4, 'may ask', C['mut'], 'start')
    lab(16, y + 26, 'blue dashed: interface · teal: record or enum · grey: class', C['mut'], 'start')
    badge(s, 398, y + 22, 1); lab(410, y + 26, 'to', C['mut'], 'start'); badge(s, 432, y + 22, 8)
    lab(446, y + 26, 'one check, in order: the list under the diagram', C['mut'], 'start')
    # keep the spaces that indent and align the text (SVG collapses them otherwise)
    return s.render('The rate limiter: every class of the core, with its fields and methods').replace('<text ', '<text xml:space="preserve" ')
