STEPS = [
dict(id='problem', stage='Brief', wide=True, title='The problem, in plain words',
think="""
<p class="ask">“Design a rate limiter for our public API. Every request carries the caller's API key. Free clients get a small limit and paid clients a bigger one. Search is expensive, so it has its own tighter limit. And the whole API must never take more than the servers can handle. Some calls cost more than one unit. Many threads, and later many servers. Working code.”</p>
<p><b>What it is.</b> Before the API does any work, it asks the limiter one question: <code>check(request)</code>. The answer is <span class="ok">allowed</span> with how much budget is left, or <span class="no">refused</span> with when to retry and which rule said no. The API turns a refusal into HTTP 429 with a <code>Retry-After</code> header. Several rules can apply to one request, and it passes only if every one of them allows it.</p>
<p><b>What they grade.</b> The rules are data, not <code>if</code>s. The counting algorithm sits behind an interface. A refused request is charged by no rule. The lock is in the right place, and a test proves it. And each follow-up lands as a new class, not a rewrite, including the jump to many servers.</p>
<p><b>Ask these first. If they say "you decide", assume the answer shown.</b></p>
<table>
<tr><th>ask</th><th>assume</th></tr>
<tr><td>One server, or many sharing the limits?</td><td>one process now; many later</td></tr>
<tr><td>Limit by what: API key, IP, endpoint?</td><td>API key; also per endpoint; also a global cap</td></tr>
<tr><td>Same limit for everyone?</td><td>FREE and PRO plans</td></tr>
<tr><td>Can one call cost more than one?</td><td>yes: an export costs 3</td></tr>
<tr><td>Is a refused request counted?</td><td>no, by no rule</td></tr>
<tr><td>Bursts, or evenly spaced?</td><td>bursts up to the limit</td></tr>
<tr><td>Refused: fail, or wait?</td><td>fail fast, and say when to retry</td></tr>
</table>
<p><b>The requirements, numbered.</b> Every class in the design points back to one of these.</p>
<table class="reqs">
<tr><th></th><th>requirement</th></tr>
<tr><td><b>R1</b></td><td><code>check(request)</code> answers allowed, with what's left, or refused, with when to retry and which rule said no.</td></tr>
<tr><td><b>R2</b></td><td>Rules are config: which requests (a plan, an endpoint, all), whose budget (a client, a client on one endpoint, everyone), how many per window, and how they are counted.</td></tr>
<tr><td><b>R3</b></td><td>All or nothing: a request passes only if every rule that covers it allows it, and a refused request is charged by none.</td></tr>
<tr><td><b>R4</b></td><td>Bursts up to the limit, then the average rate. One call may cost more than 1.</td></tr>
<tr><td><b>R5</b></td><td>Many threads: never over any limit, and one client never waits for another.</td></tr>
<tr><td><b>R6</b></td><td>O(1) per rule, and memory only for keys in use.</td></tr>
<tr><td><b>R7</b></td><td>New algorithms, stores (for many servers) and listeners (for dashboards) plug in without editing the core.</td></tr>
<tr><td><b>R8</b></td><td>Tests control time, and never sleep.</td></tr>
<tr><td><b>R9</b></td><td>At the edge, a refusal is HTTP 429 with <code>Retry-After</code>.</td></tr>
</table>
<p><b>The example on every step.</b> acme is FREE: 5 a second. globex is PRO: 50 a second. Search: 2 a second per client. Global: 60 a second in total.</p>
{{svg:acme}}
""",
say="One question, check(request), answered by rules that are data, all or nothing, never over the limit on many threads, with time injected. One process first, many servers later."),

dict(id='algorithm', stage='Brief', wide=True, title='Pick the counting algorithm first: a per-minute counter lets through twice the limit',
think="""
<p><b>The first idea</b> is a counter per client that resets every minute. At 12:00:59.9 acme sends 100 and all pass. The counter resets, and at 12:01:00.1 acme sends 100 more, and all pass. That is 200 in 0.2 seconds.</p>
{{svg:edge}}
<table>
<tr><th>algorithm</th><th>keeps per key</th><th>goes wrong</th><th>use it when</th></tr>
<tr><td>fixed window</td><td>a count, and its minute</td><td>2× the limit at the edge</td><td>edges don't matter: a daily quota</td></tr>
<tr><td>sliding window log</td><td>a timestamp per unit</td><td>memory grows with the limit</td><td>small exact limits: logins</td></tr>
<tr><td>sliding window counter</td><td>this and last window's count</td><td>an estimate</td><td>O(1), and close is enough</td></tr>
<tr><td><b>token bucket</b></td><td>tokens, and when last counted</td><td>a quiet key may burst its capacity</td><td><b>an API: O(1), bursts, costs, a one-line retry time</b></td></tr>
</table>
<p><b>How a token bucket works, in one picture.</b> Each key has a bucket that holds at most <i>capacity</i> tokens and refills at <i>capacity</i> per window, a little every millisecond. A request takes <i>cost</i> tokens, or is refused with the time until they are there. acme's bucket holds 5 and earns one every 200 ms, so a quiet acme can burst 5 at once (R4), then gets one every 200 ms: never more than 5 in any second on average.</p>
<p>I pick the token bucket as the default, but the design will not depend on it: the algorithm is a seam, and each rule names its own. Follow-up 1 adds the exact log for logins.</p>
""",
say="A fixed window lets twice the limit through at the edge; the token bucket is my default because it allows bursts, takes a cost and gives a retry time in O(1), and each rule can pick another."),

dict(id='design', stage='Brief', wide=True, title='The design, up front: every class, one check through them, and where each came from',
think="""
<p>This is where the build is going: every class of the core, with the fields and methods you will type. Read it once now. The Build steps then add one layer at a time, and the small diagram on the right fills in as they go.</p>
{{svg:classes6}}
<p><b>One check, in order.</b> The numbers match the purple badges on the diagram.</p>
<ol class="flow">
<li><code>ApiFilter.handle</code> calls <code>check(request)</code> on the <code>RateLimiter</code> interface. It never sees the class behind it.</li>
<li><code>RateLimiterService</code> reads the <code>Clock</code> once, so every rule in this request uses the same instant.</li>
<li>The <code>RuleBook</code> returns the rules that cover the request, narrow first and the global cap last.</li>
<li>For each rule, its <code>Scope</code> turns the request into a key: <code>"acme"</code>, <code>"acme /search"</code> or <code>"*"</code>.</li>
<li>The <code>BucketStore</code> finds the bucket for that rule and key, or asks the rule's <code>Algorithm</code> to make one.</li>
<li>The <code>Bucket</code> locks itself, refills from the time elapsed, and takes the cost or says when. On the first refusal the service refunds every bucket it already charged.</li>
<li>Each <code>DecisionListener</code> hears the <code>Decision</code>, after it is made and outside every lock.</li>
<li>The filter answers 200 with what's left, or 429 with <code>Retry-After</code>.</li>
</ol>
<p><b>Where each class came from.</b> Each requirement forces one decision, and the decision names the classes. Every Build step starts from its row here.</p>
<table>
<tr><th>req</th><th>it forces</th><th>so the design has</th></tr>
<tr><td>R1</td><td>an answer richer than true or false</td><td><code>Decision</code>: allowed, remaining, retry time, rule; and <code>RateLimiter.check</code></td></tr>
<tr><td>R2</td><td>rules as rows of data, not <code>if</code>s</td><td><code>Rule</code> with a predicate, <code>RuleBook</code>, <code>Scope</code> that computes the key, <code>Plans</code></td></tr>
<tr><td>R3</td><td>a way to undo a partial charge</td><td><code>Bucket.refund</code>, and a service that checks in order and refunds</td></tr>
<tr><td>R4</td><td>a counter that allows bursts and takes a cost</td><td><code>TokenBucket</code>: tokens, and the time they were last topped up</td></tr>
<tr><td>R5</td><td>a lock per key, and exactly one bucket per new key</td><td><code>synchronized</code> in the bucket; <code>computeIfAbsent</code> in the store</td></tr>
<tr><td>R6</td><td>a hash lookup, and a refill computed from elapsed time</td><td><code>LocalBucketStore</code>'s map; <code>TokenBucket.refill</code>, with no timer thread</td></tr>
<tr><td>R7</td><td>interfaces exactly where change will come</td><td><code>Algorithm</code>, <code>BucketStore</code>, <code>DecisionListener</code>, <code>RateLimiter</code></td></tr>
<tr><td>R8</td><td>time handed in, never read inside</td><td><code>Clock</code>, <code>SystemClock</code>, <code>ManualClock</code></td></tr>
<tr><td>R9</td><td>HTTP kept out of the limiter</td><td><code>ApiFilter</code>, <code>Response</code></td></tr>
</table>
<p><b>What stays out, and why.</b> No <code>Client</code> or <code>Endpoint</code> class: each would hold one string and no rule. No timer thread: buckets refill when asked. No Singleton: one limiter per process is wiring in <code>main</code>, and tests need fresh ones. No interface for <code>RuleBook</code> or <code>Plans</code>: nobody will swap them, and an interface with one implementation is ceremony.</p>
<p><b>The build order</b> is bottom-up, so every step compiles on its own: the values, the clock, the buckets, the rules, the store, the service, the edge, and then <code>Main</code> to prove it.</p>
""",
say="Edge, orchestrator, rules as data, buckets behind an interface, and a store that is its own seam, with time and listeners handed in. Each class answers one requirement."),
]
