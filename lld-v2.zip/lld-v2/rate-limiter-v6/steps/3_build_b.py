T_RULES = 'Request,Limit,Decision,Clock,SystemClock,ManualClock,Bucket,Algorithm,TokenBucket,Plan,Plans,Scope,Rule,RuleBook'
T_STORE = T_RULES + ',BucketStore,LocalBucketStore'
T_SERVICE = T_STORE + ',RateLimiter,DecisionListener,RefusalCounter,RateLimiterService'
T_EDGE = T_SERVICE + ',Response,ApiFilter'

STEPS = [
dict(id='b-store', stage='Build', title='BucketStore: where each key\'s budget lives',
think="""
<p class="why"><b>Why it exists.</b> R6 needs an O(1) lookup from a rule and key to its bucket. R7 says a store for many servers must plug in later, and where buckets live is exactly what changes then.</p>
<ul class="dec">
<li><b>An interface with one method</b>: find or make the bucket for this rule and key. The jump to many servers will be one new implementation.</li>
<li><b>The rule's id is part of the key</b>, so acme's per-client bucket and acme's search bucket are different buckets.</li>
<li><b>One step to find or make</b>, with <code>computeIfAbsent</code>, so a new key gets exactly one bucket, however many threads meet it at once (R5).</li>
</ul>
<div class="trap first"><code>get</code>, then <code>put</code> if it was missing. Two threads see no bucket for a new key, both make a full one, and the key gets 10 tokens for a limit of 5. The race in step 11 catches this every time.</div>
""",
code=[('core', 'BucketStore,LocalBucketStore', 'BucketStore, LocalBucketStore')],
walk=[
('Bucket bucket(Rule rule, String key, long nowMillis);', 'The rule says how to make a bucket (its limit and algorithm), the key says whose, and <code>now</code> is when a new bucket starts counting.'),
('ConcurrentHashMap<String, Bucket> buckets', 'Many threads read and add at once. A plain <code>HashMap</code> can lose entries, or loop forever, when two threads resize it together.'),
('return buckets.computeIfAbsent(rule.id() + "|" + key,', 'The key is the rule and the scope\'s key: <code>"free-client|acme"</code>, <code>"search|acme /search"</code>. <code>computeIfAbsent</code> finds it, or runs the function once and stores the result, in one atomic step.'),
('k -> rule.algorithm().newBucket(rule.limit(), nowMillis));', 'Only for a new key: the rule\'s algorithm makes the bucket. The store never names <code>TokenBucket</code>.'),
],
say="A store finds or makes the bucket for a rule and key; in memory it is a ConcurrentHashMap with computeIfAbsent, so a new key gets exactly one bucket.",
hot='BucketStore,LocalBucketStore', file=('core', T_STORE), practice=('BucketStore and LocalBucketStore', 3)),

dict(id='b-service', stage='Build', title='RateLimiterService: every rule, or none',
think="""
<p class="why"><b>Why it exists.</b> R3: a request must pass every rule that covers it, and a refused one is charged by none. That touches rules, keys, buckets and time at once, so it needs one class that coordinates them: the <b>orchestrator</b>. It holds no counts and no lock of its own.</p>
<ul class="dec">
<li><b>The API depends on <code>RateLimiter</code></b>, a one-method interface, so a decorator or a waiting wrapper can stand in later (R7).</li>
<li><b>Everything is handed in</b> through the constructor: rules, store and clock. That is dependency injection, and it is how a test passes a <code>ManualClock</code>.</li>
<li><b>Take as you go, refund on the first refusal.</b> The service checks the rules in order and takes from each bucket. When one refuses, it gives back what the earlier ones took.</li>
<li><b>Listeners are told after the decision</b>, outside every lock, and a failing listener is caught. A broken dashboard must never break the API. That is the <b>Observer</b> pattern.</li>
</ul>
<div class="trap first">check every rule first, then take from every bucket. Between the check and the take, other threads spend the tokens you saw, and the request goes over the limit. Taking is the check.</div>
""",
code=[('core', 'RateLimiter,DecisionListener,RefusalCounter,RateLimiterService', 'RateLimiter, DecisionListener, RefusalCounter, RateLimiterService')],
walk=[
('Decision check(Request request);', 'The only thing the API knows about. Everything behind it can change.'),
('void onDecision(Request request, Decision decision);', 'Anyone who wants to hear about decisions: metrics, an audit log. The limiter never knows who they are.'),
('byRule.computeIfAbsent(d.ruleId(), k -> new LongAdder()).increment();', 'A dashboard listener. <code>LongAdder</code> keeps separate counts per CPU, so thousands of threads can count refusals without fighting over one number.'),
('private final RuleBook rules;', 'Rules, store and clock: all handed in, all final.'),
('new CopyOnWriteArrayList<>()', 'Listeners are added rarely and read on every request. This list copies itself on each add, so reading needs no lock.'),
('long now = clock.millis();', 'Read the clock once: every rule in this request sees the same instant.'),
('Decision result = Decision.allow(Long.MAX_VALUE);', 'The starting answer: allowed, with unlimited left. If no rule covers the request, this is the answer. Each allowing rule then lowers "what\'s left".'),
('List<Bucket> charged = new ArrayList<>();', 'The buckets taken from so far, so they can be refunded.'),
('for (Rule rule : rules.rulesFor(request)) {', 'Narrow rules first, the global cap last, in the rule book\'s order.'),
('Bucket bucket = store.bucket(rule, rule.scope().key(request), now);', 'The scope makes the key (<code>"acme"</code>), and the store finds or makes that key\'s bucket for this rule.'),
('Decision d = bucket.tryTake(request.cost(), now);', 'Take the cost. The bucket\'s lock is held only inside this call, never while the service takes another bucket, so two rules can never deadlock.'),
('for (Bucket b : charged) b.refund(request.cost(), now);', 'A refusal. Every bucket already charged gets its tokens back, so the refused request costs nothing (R3).'),
('result = d.by(rule.id());', 'Name the rule that refused, for the 429 and the dashboard, and stop checking.'),
('charged.add(bucket);', 'This rule allowed it: remember the bucket, in case a later rule refuses.'),
('result = Decision.allow(Math.min(result.remaining(), d.remaining()));', '"What\'s left" is the smallest across the rules. acme may have 4 left on its own rule and 2 on search, so it really has 2.'),
('try { l.onDecision(request, result); }', 'Each listener is told in its own <code>try</code>: one that throws doesn\'t stop the others, or the answer.'),
],
say="The service checks every applicable rule in order, refunds on the first refusal, and tells listeners after; it coordinates and holds no lock of its own.",
hot='RateLimiter,DecisionListener,RefusalCounter,RateLimiterService',
pattern=[('Observer', 'DecisionListener: the limiter tells, and doesn\'t know who listens'), ('Dependency injection', 'the service is handed rules, store and clock')],
file=('core', T_SERVICE), practice=('RateLimiterService.check, with the refund', 8)),

dict(id='b-edge', stage='Build', title='ApiFilter: the edge, where a Decision becomes HTTP',
think="""
<p class="why"><b>Why it exists.</b> R9: a refusal is HTTP 429 with <code>Retry-After</code>. That is the only place HTTP appears, so the same limiter could sit behind gRPC or a queue consumer unchanged.</p>
<ul class="dec">
<li><b>The filter holds a <code>RateLimiter</code></b>, the interface, so it works with any limiter, including the decorators added later.</li>
<li><b>Standard headers</b>: <code>X-RateLimit-Remaining</code> on success; <code>Retry-After</code> in whole seconds, rounded up, on a refusal; and which rule refused.</li>
<li><b>No <code>Retry-After</code> when the request can never fit</b>, so a client doesn't retry it forever.</li>
</ul>
""",
code=[('core', 'Response,ApiFilter', 'Response, ApiFilter')],
walk=[
('record Response(int status, Map<String, String> headers) { }', 'What the HTTP client gets back: a status and headers.'),
('Decision d = limiter.check(request);', 'One call. The filter decides nothing about limits.'),
('new TreeMap<>()', 'A sorted map only so the demo prints the headers in the same order every run.'),
('if (d.remaining() != Long.MAX_VALUE)', 'No count when no rule applied: there is nothing true to report.'),
('h.put("X-RateLimit-Rule", d.ruleId());', 'Which rule refused, so the client knows what to back off from.'),
('if (d.retryAfterMillis() != Decision.NEVER) {', 'A request that can never fit gets a 429 with no <code>Retry-After</code>.'),
('(d.retryAfterMillis() + 999) / 1000', 'Milliseconds to whole seconds, rounded up: 120 ms becomes 1. Rounding down would say 0, and the client would retry too early.'),
],
say="HTTP lives only at the edge: 200 with what's left, or 429 with Retry-After in seconds, rounded up.",
hot='ApiFilter', pattern=[('Adapter, at the edge', 'ApiFilter turns a Decision into HTTP')], file=('core', T_EDGE), practice=('ApiFilter', 3)),

dict(id='b-main', stage='Build', title='Main: the story, and a race that must let exactly 30,000 through',
think="""
<p class="why"><b>Why it exists.</b> A design is only as good as its proof. <code>main</code> wires the classes the way production would, tells acme's story, and then races 100 threads against the limits, with checks that throw if any promise breaks.</p>
<p>Then I break the code on purpose, to show that the race would catch it. Without <code>synchronized</code>: {{mutant:nolock}}. With a <code>get</code> then a <code>put</code>: {{mutant:getput}}. Without the refund: {{mutant:norefund}}.</p>
""",
code=[('core', 'Main', 'Main')], out=('core', None),
walk=[
('ManualClock clock = new ManualClock(0);', 'Time starts at 0 and moves only when the test says so.'),
('plans.set("globex", Plan.PRO);', 'globex pays. acme is never set, so it is on FREE.'),
('RuleBook rules = acmeRules(plans);', 'The four rules from step 7.'),
('new RateLimiterService(rules, new LocalBucketStore(), clock);', 'Wiring: every dependency is passed in here, the only place that names the concrete classes.'),
('limiter.addListener(refusals);', 'The dashboard listener, registered like any other.'),
('for (int i = 1; i <= 7; i++) {', 'acme, on FREE, sends 7 at once: 5 pass, then its own rule refuses the rest.'),
('check(next.remaining() == 47', 'globex searched 3 times; the search rule refused the 3rd, and its PRO token was refunded. So 50 − 2 searches − this call = 47, not 46.'),
('clock.advance(1_000);', 'One second passes in no time: acme\'s bucket is full again.'),
('race(TokenBucket::new);', 'The race, given the algorithm to test. The lock-free bucket runs the same race later.'),
('new Rule("client", r -> true, Scope.CLIENT, new Limit(500, 86_400_000), algorithm),', 'Each of 100 clients may pass 500 a day: 50,000 in all. But the global cap below allows only 30,000 a minute, so the global rule refuses the rest.'),
('CountDownLatch go = new CountDownLatch(1);', 'A starting gun: all 100 threads wait on it and then start at once, to make the collisions as likely as possible.'),
('check(passed.get() == 30_000', 'Exactly 30,000, on every run. More would mean two threads spent one token.'),
('clock.advance(60_000);', 'A minute later the global cap is full again, and each client can spend only what it has left of its 500.'),
('check(more == 20_000', '50,000 − 30,000 = 20,000 is right only if every request the global rule refused was refunded to its client\'s bucket.'),
('static void check(boolean ok, String promise) {', 'A check that throws, not an <code>assert</code>, which Java skips unless you run with <code>-ea</code>.'),
],
say="And I prove it: the story, then a 100-thread race that must let exactly 30,000 through, then exactly the 20,000 left unused.",
hot='', file=('core', None), practice=('Main: the story and the race', 10)),
]
