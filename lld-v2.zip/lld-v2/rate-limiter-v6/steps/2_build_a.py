T_VALUES = 'Request,Limit,Decision'
T_CLOCK = T_VALUES + ',Clock,SystemClock,ManualClock'
T_BUCKET = T_CLOCK + ',Bucket,Algorithm,TokenBucket'
T_RULES = T_BUCKET + ',Plan,Plans,Scope,Rule,RuleBook'

STEPS = [
dict(id='b-values', stage='Build', title='Request, Limit, Decision: the three values every class passes around',
think="""
<p class="why"><b>Why they exist.</b> R1 needs an answer richer than true or false. R4 puts a cost on each request. R2 needs "5 a second" to be one value, not two loose numbers.</p>
<ul class="dec">
<li><b>Records</b>: set once and never changed, so any thread can share one without a lock, and <code>equals</code> comes free.</li>
<li><b>Each checks itself when it is made</b>, so a cost of 0 fails at the line that made it, not as a division by zero three classes later.</li>
<li><b>The Decision carries the retry time and the rule</b>, because the edge needs <code>Retry-After</code> and the dashboard needs to know which rule said no.</li>
</ul>
<div class="trap first"><code>boolean allow(clientId)</code>. It can't say when to retry or which rule refused, so each of those becomes a second method, and every caller changes.</div>
""",
code=[('core', 'Request,Limit,Decision', 'Request, Limit, Decision')],
walk=[
('record Request(String clientId, String endpoint, int cost)', 'A <b>record</b> generates the final fields, the constructor, the accessors, <code>equals</code> and <code>hashCode</code>. You type one line.'),
('if (cost <= 0)', 'A <b>compact constructor</b> runs on every <code>new</code>, before the fields are set. A bad cost fails right here.'),
('static Request of(', 'Most calls cost 1, so a factory keeps call sites short: <code>Request.of("acme", "/items")</code>.'),
('static Limit perSecond(int n)', 'Factories that read like the spec: <code>Limit.perSecond(5)</code>, not <code>new Limit(5, 1000)</code>.'),
('record Decision(boolean allowed', 'Four fields for three readers: the API reads <code>allowed</code>, the client reads <code>remaining</code> and the retry time, and the dashboard reads <code>ruleId</code>.'),
('static final long NEVER = -1;', 'For a request that costs more than a whole bucket. Waiting can never help, so the edge must not say "retry in X".'),
('Decision by(String ruleId)', 'A bucket doesn\'t know which rule owns it. The service stamps the rule on afterwards, and gets a new Decision back, since a record never changes.'),
('if (allowed) return remaining == Long.MAX_VALUE', '<code>toString</code> is only for the demo\'s printout. <code>Long.MAX_VALUE</code> left means no rule applied, so there is no count to show.'),
],
say="Three immutable records. The Decision carries what's left, the retry time and the rule, because the edge and the dashboard both need them.",
hot='Request,Limit,Decision', file=('core', T_VALUES), practice=('Request, Limit, Decision', 4)),

dict(id='b-clock', stage='Build', title='Clock: time is handed in, never read inside',
think="""
<p class="why"><b>Why it exists.</b> R8: tests control time. And every bucket works from elapsed time (R4), so every bucket needs "now".</p>
<ul class="dec">
<li><b>An interface, handed in</b> through the service's constructor: production passes <code>SystemClock</code>, tests pass <code>ManualClock</code>.</li>
<li><b>Read once per check</b> by the service and passed down, so all the rules in one request see the same instant.</li>
<li><b><code>nanoTime</code>, not the wall clock</b>: the wall clock can jump back when the machine corrects it.</li>
</ul>
<div class="trap first"><code>System.currentTimeMillis()</code> inside the bucket. Every test must sleep 200 ms to see one token come back, so tests are slow and flaky. And a wall-clock jump backwards freezes refills.</div>
""",
code=[('core', 'Clock,SystemClock,ManualClock', 'Clock, SystemClock, ManualClock')],
walk=[
('interface Clock {', 'One method. The service depends on this, never on <code>System</code>.'),
('System.nanoTime() / 1_000_000', 'Only moves forward. Its zero is arbitrary, which is fine: a bucket only ever subtracts two readings.'),
('private volatile long now;', '<code>volatile</code>: the test thread moves time while pool threads read it. Without it, a reader thread may keep seeing the old time.'),
('void advance(long ms)', '<code>now += ms</code> is a read and a write, not atomic. That is safe only because the test\'s own thread is the only writer, which the comment says.'),
],
say="Time is an interface: nanoTime in production, a manual clock in tests, read once per check and passed down.",
hot='Clock', file=('core', T_CLOCK), practice=('Clock, SystemClock, ManualClock', 3)),

dict(id='b-bucket', stage='Build', title='Bucket and TokenBucket: how one key counts',
think="""
<p class="why"><b>Why it exists.</b> R4 (bursts, then the average, at a cost), R5 (never over, on many threads), R6 (O(1), no timer) and R3 (a refund) all land in this one class.</p>
<ul class="dec">
<li><b><code>Bucket</code> is an interface</b>, so the service never knows the algorithm. That is the <b>Strategy</b> pattern.</li>
<li><b>It has two methods, not one</b>: <code>refund</code> exists because rules are all or nothing (R3).</li>
<li><b><code>Algorithm</code> is a factory interface.</b> A rule names <code>TokenBucket::new</code>, and the store makes one bucket per key without naming a class.</li>
<li><b>Refill on demand.</b> When a request arrives, add the tokens earned since the last one. No timer thread.</li>
<li><b>One lock per bucket</b>, so refill, check and take are one step for this key, and other keys never wait.</li>
</ul>
<div class="trap first">a timer thread that tops up every bucket each second. It touches millions of idle buckets for nothing, fights every request for their locks, and refills in jumps. Two numbers per key and a subtraction do the same work, only when asked.</div>
""",
code=[('core', 'Bucket,Algorithm,TokenBucket', 'Bucket, Algorithm, TokenBucket')],
walk=[
('Decision tryTake(int cost, long nowMillis);', 'Take <code>cost</code> now, or say how long until it fits. "Now" comes in from the clock; the bucket never reads one.'),
('void refund(int cost, long nowMillis);', 'Give back what <code>tryTake</code> took, when a later rule refuses the same request.'),
('Bucket newBucket(Limit limit, long nowMillis);', 'The factory. <code>TokenBucket::new</code> matches it, because TokenBucket\'s constructor takes a <code>Limit</code> and a <code>long</code>.'),
('private double tokens;', 'A <code>double</code>, because refill earns fractions: 5 a second is 0.005 a millisecond. With an <code>int</code>, a client calling every 100 ms earns 0.5, rounded to 0, forever.'),
('this.tokens = capacity;', 'A new key starts full, so a client that just arrived may burst its whole limit (R4).'),
('public synchronized Decision tryTake(', 'The lock is this bucket. Two threads on the same key take turns; threads on other keys never wait (R5).'),
('if (cost > capacity) return Decision.deny(Decision.NEVER);', 'Checked first: a cost of 6 can never fit a capacity of 5, and any wait we computed would be a lie.'),
('return Decision.allow((long) tokens);', 'What\'s left, rounded down: 2.7 tokens is 2 whole requests.'),
('return Decision.deny((long) Math.ceil(', 'The wait is the tokens missing × the milliseconds per token. With 0.4 tokens and a cost of 1: 0.6 × 1000 ÷ 5 = 120 ms. It is rounded up, so a client that waits exactly this long finds the token there.'),
('tokens = Math.min(capacity, tokens + cost);', 'Capped: if time refilled the bucket in the meantime, a refund must not push it past full.'),
('if (elapsed <= 0) return;', 'The same millisecond, or an older reading from a thread that got the lock late: earn nothing, and never move <code>lastRefillMillis</code> backwards.'),
('tokens = Math.min(capacity, tokens + (double) elapsed', 'Earned = elapsed × capacity ÷ window: 200 ms × 5 ÷ 1000 = 1 token. Capped, so 5 quiet seconds leave 5 tokens, not 25. The cast comes first, so the division is not rounded to a whole number.'),
],
say="A bucket per rule and key; it refills from elapsed time when asked, then takes the cost or says when; synchronized per bucket; the algorithm is a factory, TokenBucket::new.",
hot='Bucket,Algorithm,TokenBucket', pattern=[('Strategy', 'Bucket: one interface, any counting algorithm'), ('Factory', 'Algorithm: TokenBucket::new makes a bucket')],
file=('core', T_BUCKET), practice=('Bucket, Algorithm and TokenBucket', 8)),

dict(id='b-rules', stage='Build', title='Rule, Scope, RuleBook, Plans: the rules are data',
think="""
<p class="why"><b>Why they exist.</b> R2: rules come from config. Each says which requests it covers, whose budget it counts, how many, and how it counts.</p>
<ul class="dec">
<li><b>A <code>Rule</code> is a record</b>: one row of config. A new limit is a new row, not a new class or another <code>if</code>.</li>
<li><b>"Which requests" is a <code>Predicate&lt;Request&gt;</code></b>, so "FREE clients", "only /search" and "everyone" are one lambda each.</li>
<li><b><code>Scope</code> is an enum whose constants compute the key.</b> The set is small and fixed, and "per IP" would be one more constant.</li>
<li><b>Order is part of the data.</b> Narrow rules first and the global cap last, so a noisy client is stopped by its own rule before it touches the one lock every client shares.</li>
</ul>
<div class="trap first"><code>if (plan == FREE) … else if (endpoint.equals("/search")) …</code> inside the limiter. Every new limit is a code change and a deploy, and nobody can see the rules in one place.</div>
""",
code=[('core', 'Plan,Plans,Scope,Rule,RuleBook', 'Plan, Plans, Scope, Rule, RuleBook'), ('core', 'Main.acmeRules', 'the example\'s rules, as config (in Main)')],
walk=[
('enum Plan { FREE, PRO }', 'A fixed set of plans: an enum.'),
('private final Map<String, Plan> byClient', 'A concurrent map, because a client can upgrade while its requests are being checked.'),
('getOrDefault(clientId, Plan.FREE)', 'A client nobody has set up is on FREE, so nothing else needs a null check.'),
('return r.clientId(); }', 'Each constant has its own body, which is Strategy as an enum. CLIENT puts all of acme\'s calls in one budget, under the key <code>"acme"</code>.'),
('return r.clientId() + " " + r.endpoint();', 'CLIENT_ENDPOINT gives acme\'s searches a budget of their own: <code>"acme /search"</code>.'),
('return "*";', 'GLOBAL: one key for everyone, so one bucket counts the whole API.'),
('record Rule(String id', 'One row of config. The <code>id</code> names the rule in a 429 and on the dashboard, and keeps two rules\' buckets apart in the store.'),
('List.copyOf(rules)', 'An unmodifiable copy, in the given order: nobody can change the rules underneath the limiter.'),
('filter(x -> x.appliesTo().test(r))', 'The rules that cover this request, in order. O(rules) is fine for tens; with hundreds, index them by endpoint.'),
('new Rule("free-client"', 'A plan rule: its predicate asks <code>Plans</code>. acme is FREE, so this row is its 5 a second, per client.'),
('new Rule("search"', 'An endpoint rule, per client and endpoint: 2 searches a second each.'),
('new Rule("global"', 'Last: everyone, one key, 60 a second. Narrow first, so a noisy client never reaches this shared lock.'),
],
say="Rules are data: which requests, whose budget, how many and how counted, checked narrow first; a scope turns a request into a key.",
hot='Plans,Scope,Rule,RuleBook', pattern=[('Strategy, as an enum', 'Scope: each constant computes its own key')],
file=('core', T_RULES), practice=('Plans, Scope, Rule, RuleBook', 6)),
]
