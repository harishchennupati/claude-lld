STEPS = [
dict(id='e1', stage='Extend', title='Follow-up 1 · "Logins: at most 5 in any minute, exactly"',
think="""
<p class="ask">“Our login endpoint allows 5 attempts a minute per user, and security says never more than 5 in any 60 seconds. Does your limiter do that?”</p>
<p class="lands">Lands on <b>Bucket</b>: one new class, plus one rule that uses it. Nothing else changes.</p>
<p>No. A token bucket of 5 a minute earns a token every 12 seconds, so a user who spends 5 at once gets one more at 12, 24, 36 and 48 seconds: 9 in the first minute. The exact answer keeps a timestamp for each unit taken and counts those in the last window: a <b>sliding window log</b>. It is a new <code>Bucket</code>, and the login rule names it: <code>SlidingWindowLog::new</code>. The API rules keep the token bucket.</p>
{{svg:fu1_n}}
""",
code=[('e1', 'diff', '')], out=('e1', 'e1'),
walk=[
('private final ArrayDeque<Long> times = new ArrayDeque<>();', 'One timestamp per unit taken, oldest first. An <code>ArrayDeque</code> adds and removes at both ends in O(1).'),
('while (!times.isEmpty() && times.peekFirst() <= nowMillis - windowMillis) {', 'Forget every entry that has left the window: at 60 s, anything taken at 0 s or earlier.'),
('if (times.size() + cost <= limit) {', 'Is there room for <code>cost</code> more in the last window?'),
('for (int i = 0; i < cost; i++) times.addLast(nowMillis);', 'Yes: record one timestamp per unit.'),
('long oldestThatMustLeave', 'No: a place opens when enough of the oldest entries leave. With 5 logins at 0 s and a cost of 1, the entry at 0 s must leave, so the wait is 0 + 60 s − now.'),
('for (int i = 0; i < cost && !times.isEmpty(); i++) times.pollLast();', 'A refund removes the newest entries, which are the ones this request just added.'),
('Algorithm algorithm = name.equals("TokenBucket") ? TokenBucket::new : SlidingWindowLog::new;', 'In the demo, the only difference between the two runs is which algorithm the rule names.'),
],
say="Counting is a strategy per rule, so the exact log is one new Bucket, and only the login rule uses it.",
after="""<div class="hole">Memory grows with the limit: a timestamp per unit, about 2.7 KB a key at 100 a minute. That is fine for 5 logins a minute, and wrong for an API rule at 1,000 a minute.</div>""",
new='SlidingWindowLog', hot='Bucket,Algorithm', file=('e1', None), practice=('SlidingWindowLog', 8)),

dict(id='e2', stage='Extend', title='Follow-up 2 · "Ops raise FREE from 5 to 10 a second, live"',
think="""
<p class="ask">“We're raising the FREE plan to 10 a second. Ops change the rule in the admin screen, with no restart. When do FREE clients get 10?”</p>
<p class="lands">Lands on <b>RateLimiterService</b> (swap the rule book) and <b>LocalBucketStore</b> (the limit becomes part of the key).</p>
<p>Two changes. The service's rule book becomes <code>volatile</code>, with a <code>replaceRules</code> method, so the whole book is swapped in one write. And a bucket built for the old limit must not be reused, so the store's key now includes the limit. A new limit then means a new bucket on the next request. The old buckets go idle, and follow-up 5 sweeps them.</p>
<p>A plan change needs neither. A client moving from FREE to PRO matches the PRO rule on its very next request, because rules are matched per request.</p>
""",
code=[('e2', 'diff', '')], out=('e2', 'e2'),
walk=[
('rule.id() + "|" + rule.limit() + "|" + key', 'The limit is part of the key now: <code>free-client|Limit[permits=10, windowMillis=1000]|acme</code>. A record\'s <code>toString</code> spells out its fields, so a new limit finds no bucket and makes a fresh one.'),
('private volatile RuleBook rules;', '<code>volatile</code>: after ops swap the book, every thread\'s next read sees the new one.'),
('void replaceRules(RuleBook newRules)', 'One write swaps the whole book, so a request sees the old rules or the new, never half of each. A request already inside <code>check</code> keeps the book it started with.'),
('limiter.replaceRules(new RuleBook(List.of(free10)));', 'In the demo: 10 of the next 12 pass at once, not 5.'),
],
say="Swap the whole rule book in one volatile write, and key buckets by their limit, so a new limit gets a new bucket on the next request.",
after="""<div class="hole">The new bucket starts full, so a client can send a full new burst at the moment of the change. For a raise, that's fine. For a cut, carry over the share already used.</div>""",
hot='RateLimiterService,LocalBucketStore,RuleBook', file=('e2', None), practice=('replaceRules, and the limit in the key', 5)),

dict(id='e3', stage='Extend', title='Follow-up 3 · "The batch job would rather wait than be refused"',
think="""
<p class="ask">“A nightly job calls us 10,000 times. When it hits a limit it should wait its turn, not fail. Where would you not offer this?”</p>
<p class="lands">Lands on <b>RateLimiter</b>: a new class that uses it. Nothing else changes.</p>
<p>Every refusal already says when to retry, so waiting is a loop: check; if refused, sleep for the retry time; check again, with a deadline. It uses only the interface, so it waits on every rule the service applies, and on the Redis store later. I would not offer it on a public API's request path, where each waiter holds a server thread. Cap the wait, and cap the number of waiters with a <code>Semaphore</code>.</p>
""",
code=[('e3', 'diff', '')], out=('e3', 'e3'),
walk=[
('long deadline = System.nanoTime() + maxWaitMillis * 1_000_000;', 'The latest moment we may still return true.'),
('if (d.allowed()) return true;', 'Passed: the limiter has already taken the tokens.'),
('if (d.retryAfterMillis() == Decision.NEVER || d.retryAfterMillis() > leftMillis) return false;', 'Give up at once if it can never fit, or if the wait would pass the deadline. There is no point sleeping only to fail.'),
('Thread.sleep(d.retryAfterMillis());', 'Sleep exactly as long as the limiter said, then ask again: another caller may have taken the token in the meantime.'),
],
say="Waiting is a loop around check() that sleeps for the retry time, with a deadline, for background callers only.",
after="""<div class="hole">Waiters are not served in order: two that wake together race for one token. If order matters, use a queue per client, which is the leaky bucket.</div>""",
new='Waiting', hot='RateLimiter', file=('e3', None), practice=('Waiting.acquire', 5)),

dict(id='e4', stage='Extend', title='Follow-up 4 · "Try a stricter rule without hurting anyone"',
think="""
<p class="ask">“We want to cut FREE to 3 a second, but first we want to know who it would hurt. Don't refuse anyone yet.”</p>
<p class="lands">Lands on <b>RateLimiter</b>: a decorator. The API is handed it instead, and nothing else changes.</p>
<p><code>ShadowLimiter</code> wraps the live limiter and a candidate built with the new rules. It enforces the live answer, asks the candidate too, and counts what the candidate would have refused, to log per client. After a week of evidence, ops swap the rules for real with follow-up 2. This is the <b>Decorator</b> pattern: it adds behaviour around an existing piece without editing it.</p>
""",
code=[('e4', 'diff', '')], out=('e4', 'e4'),
walk=[
('class ShadowLimiter implements RateLimiter {', 'A <code>RateLimiter</code> that holds two <code>RateLimiter</code>s. The API is handed this one and can\'t tell the difference.'),
('Decision d = live.check(request);', 'The live rules decide, exactly as before.'),
('if (d.allowed() && !candidate.check(request).allowed()) wouldRefuse.increment();', 'Ask the candidate only when live allowed the request. Those are the ones that count: allowed today, refused under the new rule.'),
('return d;', 'Always the live answer: nobody is refused by the experiment.'),
],
say="Shadow mode is a decorator: enforce the live rules, ask the candidate rules, and count what they would have refused.",
after="""<div class="hole">The candidate keeps its own buckets, so it doubles the limiter's memory while it runs, and its counts are exact only for single-rule candidates. It's a week's experiment, not a permanent layer.</div>""",
new='ShadowLimiter', hot='RateLimiter', pattern=[('Decorator', 'ShadowLimiter wraps any RateLimiter')], file=('e4', None), practice=('ShadowLimiter', 5)),

dict(id='e5', stage='Extend', title='Follow-up 5 · "Ten million API keys, most used once"',
think="""
<p class="ask">“We have ten million API keys, and most call once a day. How much memory does the limiter use? Fix it.”</p>
<p class="lands">Lands on <b>Bucket</b> (add <code>isIdle</code>: an interface change, so say so) and <b>LocalBucketStore</b> (add <code>evictIdle</code>).</p>
<p>The store's map never shrinks: about 140 bytes a key, measured, so about 1.4 GB for ten million. The key fact is that <b>a token bucket unused for a whole window is full again</b>, exactly like a new one, so forgetting it loses nothing. Each bucket answers <code>isIdle(now)</code>, and a timer calls <code>evictIdle</code> once a minute, off the request path.</p>
""",
code=[('e5', 'diff', '')], out=('e5', 'e5'),
walk=[
('boolean isIdle(long nowMillis);', 'A new method on the interface, so every <code>Bucket</code> must answer it. This is the one interface change in the follow-ups: say it out loud.'),
('return nowMillis - lastRefillMillis >= windowMillis;', 'Unused for a whole window, a token bucket is full again, just like a new one.'),
('return times.isEmpty() || times.peekLast() <= nowMillis - windowMillis;', 'A log is idle when even its newest entry has left the window.'),
('for (Map.Entry<String, Bucket> e : buckets.entrySet()) {', 'A <code>ConcurrentHashMap</code> can be walked while other threads add to it: no exception, and no lock.'),
('buckets.remove(e.getKey(), e.getValue())', '<code>remove(key, value)</code> removes only if the map still holds this same bucket, so a bucket another thread just put there survives.'),
],
say="An idle bucket is full, so forgetting it loses nothing; a timer sweeps buckets idle for a window, with remove(key, value).",
after="""<div class="hole">A request that fetched a bucket just before the sweep removed it spends from the removed one, so that key can get one extra request. The exact fix: mark the bucket retired inside its lock, and look it up again.</div>""",
hot='Bucket,TokenBucket,SlidingWindowLog,LocalBucketStore', sub={'Bucket': 'tryTake · refund · isIdle'},
file=('e5', None), practice=('isIdle, and evictIdle', 6)),
]
