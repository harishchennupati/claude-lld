STEPS = [
dict(id='practice', stage='Practice', wide=True, title='Practise it, from a blank file and in your IDE',
think="""
<p><b>Open the real project in your IDE.</b> Each is one class per file, in package <code>ratelimiter</code>, with a <code>pom.xml</code>. In IntelliJ: <i>File → Open</i>, pick the folder, and run <code>Main</code>. From a terminal: <code>./run.sh</code>. Set breakpoints in <code>RateLimiterService.check</code> and <code>TokenBucket.tryTake</code>, then step through acme's story.</p>
<ul>
<li><b>The core</b>, what you type in the interview: <code>~/Downloads/lld-v2/code/rate-limiter-v6/core</code> (23 files)</li>
<li><b>After every follow-up and scale-out step:</b> <code>~/Downloads/lld-v2/code/rate-limiter-v6/final</code> (35 files)</li>
</ul>
<p><b>Then drill, from an empty folder.</b> In <b>Practice</b> mode (top right) every step hides its code until you reveal it, has a timer, and takes a got-it or missed mark. Before typing a class, say its row from step 3: the requirement, and what it forced.</p>
<ol>
<li><b>The skeleton</b> <span class="timer" data-min="12"><span class="tv">12:00</span><button type="button">start</button></span><br>Every type, field and signature from the class diagram in step 3, with bodies that throw. It must compile. This is the design, and most of the grade.</li>
<li><b>The logic</b> <span class="timer" data-min="12"><span class="tv">12:00</span><button type="button">start</button></span><br><code>TokenBucket.tryTake</code>, <code>refund</code>, <code>refill</code>, <code>LocalBucketStore.bucket</code>, and <code>RateLimiterService.check</code> with the refund.</li>
<li><b>The whole core</b> <span class="timer" data-min="60"><span class="tv">60:00</span><button type="button">start</button></span><br>From blank to a <code>main</code> that prints acme's story, 30000 and 20000. Then diff it against the core project, and write down three things you missed.</li>
<li><b>Follow-ups and scale-out</b>, 10 minutes each, each on top of the last. Say the box it lands on, and the kind of change, before you type.</li>
</ol>
<p class="marks"><label><input type="checkbox" data-k="rate-limiter.read"> read</label><label><input type="checkbox" data-k="rate-limiter.coded"> coded from a blank file</label></p>
<div class="misc"><textarea data-k="rate-limiter.miss" placeholder="Miss log: three specific things the reference did that you did not. Saved in this browser."></textarea></div>
<details class="demo"><summary>The whole core as one file</summary>
{{whole:core|Main.java · the core}}
</details>
""",
say="Skeleton, logic, whole core, then follow-ups and scale-out: say the requirement and the box before you type."),
]
