# LLD blueprint

The current format is **v7** (Part A000; it builds on v6 and the v4 step-by-step format), and `rate-limiter-v7-steps.html` is its reference.
Part A below is the v4 format. Part B is the v3 reading format, kept for reference; its rules on
thinking, English and code (B.2–B.4, B.7) still apply to v4.

## Part A000 · v7: the current format (reference: `rate-limiter-v7-steps.html`)

v7 keeps v6's stages and code, and fixes how it reads. The rules below apply to every new LLD page.

**English**
- Write complete, plain sentences. Explain each term the first time it appears (for example: "`LongAdder`, a
  counter that many threads can increase at once"). Use one idea per paragraph and no clipped fragments.
- Use no reference codes (R1, R2 …): say the need in words where it matters. Use no "say" boxes and no
  walkthrough lists.
- Use two callout labels only: `<div class="trap mistake">` (common mistake) and `<div class="hole limit">`
  (limitation).

**Example names**
- Use realistic names that explain themselves, introduced with their role: `weather-widget`, a small widget
  on the Free plan; `travel-app`, a busy travel app on the Pro plan. Never use placeholder names like acme
  or globex.

**Brief (3 wide steps)**
- The problem: the interviewer's prompt, what we are building, a questions-to-ask table (question, what we
  assume, what it changes), what it must do, how well it must do it, and the example.
- How to count, or the problem's core algorithm.
- The design, written the way a designer thinks: start from the one call, ask what is needed next, and let
  each answer become a class, in short bold-led paragraphs. Then the full class diagram, then a **UML
  sequence diagram** of one request (`sequence()` in `rate-limiter-v7/figures.py`: lifelines, activations,
  and loop and break fragments), then what we leave out.

**Build steps**
- What the class is for and why it is needed, in prose. For tricky logic, a numbered "what it does" list
  and a small worked example (a table of times and numbers), then the code. Optionally, one common mistake.
- `{{code:snap:Type.member|label}}` places a code block inside the prose; it is used for the example's
  rules config.

**Figures**
- Draw each figure at the width of its column (about 720 px in a normal step, 1000 in a wide step), so its
  text is not scaled down.

## Part A00 · v6: what changed from v5 (the current reference is `rate-limiter-v6-steps.html`)

- **No Derive stage.** The derivation lives in two places, each where it is used: once as a table on the
  design step (requirement → what it forces → the classes), and per class at the top of its Build step.
- **Brief (3, wide):** the problem with **numbered requirements (R1…)**; the algorithm; the design up front
  as a **full UML class diagram** (fields and methods, `fig_classes6`) with purple badges tracing one call,
  a numbered list for that call, the requirement table, and what stays out.
- **Build step shape:** *Why it exists* (the R-numbers it serves) → *decisions* (3–5 bullets: the choice and
  its reason) → *the first idea, and why it breaks* (`<div class="trap first">`) → the code with numbered
  callouts → *Walk through it* (one or two sentences per callout, with the example's numbers) → say.
- **Walkthroughs:** a step's `walk=[(text, html), …]` puts callout n on the first code line, at or after the
  previous callout, that contains `text`. The search runs through the step's code blocks in order,
  including follow-up diff blocks and the Main demo. A missing text stops the build. Hovering an item lights
  its line; hovering a numbered line pops up its explanation. Practice mode hides walks with the code.
- Defend, Extend and Scale keep v5's content, and each code block gets a walkthrough too.

## Part A0 · v5: what changed from v4 (the current reference is `rate-limiter-v5-steps.html`)

- **Stages:** Brief (2) → **Derive** (6: nouns, verbs, seams, the problem's key rule, shared state and
  lookups, the design up front) → Build (8, typing order) → Defend (concurrency with measured numbers,
  principles and patterns mapped to classes, the pokes) → Extend (5) → **Scale** (4: the problem and its
  options, the shared store, failure with a breaker, hot keys and leasing) → Practice.
- **A richer, still justified design:** each seam answers "what will they change?" (which, whose, how,
  where, who hears, when). Every class must earn its place, and the page also says what is left out.
- **IDE projects:** run `python3 tools/export.py <problem-dir> <snapshot> code/<name>/<core|final>`.
  It writes one type per file in a package, with `pom.xml`, `run.sh` and a README, then compiles and runs
  it. Both the core and the final code are exported.
- **Snapshots are named per problem** (`SNAPS` in `wb/config.py`), and `//@ from a until b` marks a line
  that a later snapshot replaces.

## Part A · v4: the step-by-step workbench

**The idea:** one small step at a time, in the order you would think and type in the interview. Each
step has a short first-person *think* (3–8 sentences), only that step's code, one line to *say*, and at
most one extra box (*the trap* or *the one hole*). The class diagram on the right fills in step by
step. Aim for about 3,500–4,500 words of prose for a whole problem.

**The steps (about 20):**

| stage | steps | what each holds |
|---|---|---|
| Brief (wide, no right panel) | 1 the problem in plain words | what it is; what they grade; the questions with their assumed answers (a 3-column table); functional and non-functional in two lines; the worked example (figure); "what is really being tested" in three things |
| | 2 the core decision | the first idea failing with numbers (figure); the options as a one-line-each table; the pick |
| | 3 from the requirements to the classes | 4–6 questions as a table: I ask / here / so I get. One *trap*: the tempting wrong structure. The nouns that stay out. |
| | 4 the whole design up front | the class diagram; three layers; one call through the boxes; where state lives; why this shape |
| Build (the diagram lights up) | 5–11, one class or pair per step, in typing order | *think*: why this class exists and the one decision in it. The code: only this step's types. *say*. The last Build step is `main`: the example, the race, and the broken copies' results. |
| Defend | the concurrency step, then "the pokes" | the gaps, the lock, measured numbers, the upgrade (with code); then a table of two-breath answers, SOLID in one breath each, and extra code answers |
| Extend | one step per follow-up (5–7), each on the last | *the ask* (a quote); *lands on* (box + kind of change); *think*; the new code only, auto-generated as "new class X" and "in Y: add" blocks, with the demo folded; the output; *say*; *the one hole*. The diagram marks new boxes green and lights the changed ones. |
| Practice (wide) | 1 step | the drills (skeleton, logic, whole core, follow-ups) with timers, a miss log, read/coded marks, and the whole files in folds |

**Files:**
- `<name>/steps/1_brief.py` … `5_practice.py`: each holds `STEPS = [dict(...)]`. The keys are
  documented at the top of `tools/steps.py`.
- `tools/steps_shell/*.html`: the app shell.
- `figures.py`: needs `fig_mini()`, the growing diagram. Each box is a `<g class="nd" data-n="Type">`,
  each arrow a `<g class="ed" data-a data-b>`, and each sub-label a `<text class="sub" data-n>`. A step
  can change a sub-label, e.g. `sub={'Bucket': 'tryTake · refund'}`.

**Build:** run `python3 tools/steps.py <name>`. It writes `<name>-steps.html`, compiles and runs every
snapshot, and runs every broken copy. "What's new" in a follow-up comes straight from the `//@ from`
markers, so it is exact.

**Check with screenshots:** `node tools/shoot-at.mjs file://$PWD/<name>-steps.html /tmp/s 1512 945 "#stepid,#stepid"`.
An entry starting with `!` runs JS instead, e.g. switching to Practice mode or the file tab.

## Part B · v3: the reading workbench (kept for reference)

`rate-limiter.html` is the v3 reference page.

## 0. What the page is, and how it is read

- **A reading workbench.** It is read top to bottom like the HLD pages, with the same clear English and
  enough depth, but no more. From the design part on, the code sits pinned on the right and follows the
  text.
- **Design first, logic second.** LLD rounds grade problem analysis, class design, code quality and
  extensibility. Logic matters only in the 2–3 methods that carry the problem, plus a trace that proves
  them. Every section is tagged so the reader always knows which mode they are in:
  `ASK` (the spec), `DESIGN` (structure), `LOGIC` (method bodies), `EXTEND` (follow-ups) and
  `INTERVIEW` (the pushes and their answers).
- **The code panel (dock)** shows the one file, `Main.java`, in three views:
  - *design*: every method body folded, so the file reads as the skeleton;
  - *code*: the part being discussed opens, and the rest stays folded;
  - *full*: everything.
  In follow-ups it shows that step's new lines in green, and its header lists the new or changed classes
  and how many lines each gained.
- **Budget per page:** about 8,000–10,000 words outside folds, 60–90 minutes of reading. The core code is
  120–200 lines; the follow-up code is 150–300 lines.

## 1. The shape of every page

| part | sections | what goes in |
|---|---|---|
| hero | problem box | The prompt, quoted. **What this really is**: the orchestrator, the seams and where the logic lives, in 4–6 sentences. **In scope / out of scope until asked.** **What they grade on this problem**: 4–5 items. Then a three-box "how to read" strip. |
| 1 · ASK | 01 The conversation | 6–8 exchanges as You / Interviewer. Under each is one line, **Decides:**, naming the class or line it forces. Then the questions that waste time. |
| | 02 The spec on the board | Numbered requirements (≤ 6) and out of scope, as you would write them on a board. **One named example** with small numbers (Acme, 5 a second): a figure, and a table that the program's output matches exactly. The hour as a table, and "Say this before you design". |
| 2 · DESIGN | 03 The nouns | A table of noun → becomes → why. Filter: a noun becomes a class only if it holds changing state or enforces a rule. Name the tempting non-classes (e.g. `Request`) and why they aren't classes. |
| | 04 The seams | What will change → an interface the orchestrator is handed (a figure). **Where each rule lives**: rule, class, because ("tell, don't ask"). **Who depends on whom.** **The one decision that makes or breaks the design** as BAD / GOOD / GREAT. |
| | 05 The whole design in one picture | A class diagram. **One call through the boxes**, as numbered steps with real method names. **What we leave out, on purpose.** |
| | 06 Class by class (docked, design view) | For each class in typing order: a state table (from the spec → field) and a behaviour table (need → method), plus the one "X, not Y" that matters for it. The dock highlights that class. |
| | 07 The skeleton (docked, design view) | "Type this first": the typing order, and the sentence to say. |
| 3 · LOGIC | 08 The core algorithm (full width) | The first idea failing, with numbers and a figure, then the options as BAD / GOOD / GREAT, **the one hole**, and "If the interviewer pushes". |
| | 09–11 The methods that matter (docked, code view) | Each gets a **contract**, **the normal path** (numbered), **the arithmetic** with the example's numbers, **edge cases** (a table: case → the line that handles it), a **trace** that matches the output, **say**, and pushes. If there is shared state, add a **concurrency** section: the invariant, the gaps (a figure), the fix as BAD / GOOD / GREAT, and measured numbers. |
| | 12 Prove it (docked) | The real output, **What each check proves**, and **Break it on purpose**: broken copies, compiled and run, with every run's result. Then the whole core in a fold. |
| 4 · EXTEND | 13 The ladder | A figure, and a table: the ask, lands on, kind of change, and which level is asked it. |
| | 14–19 One section per follow-up (docked, diff view) | **The ask** (a quote), **lands on** + the kind of change, the thinking (BAD / GOOD / GREAT when there are real options), bullets that reference the new lines, the output lines, **the one hole**, **say**. The whole final file in a fold at the end. |
| 5 · INTERVIEW | 20 What each level must show | Junior, mid and senior, specific to this problem. |
| | 21 Every push, with its answer | Grouped as design, concurrency, algorithms and variants, testing and operations. Where the answer is code, show compiled code. |
| | 22 Patterns, SOLID, cost | Where each pattern actually is, and "not used" with the reason. SOLID in one line per letter. Big-O with measured numbers. |
| | 23 Remember and practise | A map of 8–10 lines, each starting with a coloured word. Then the drills: design (skeleton, 10 minutes), logic (core methods, 10 minutes), the whole core (45 minutes), each follow-up (10 minutes). Read / coded checkboxes and a miss log. |

## 2. How to think: rules that keep a page from becoming a template

1. **Every row must come from this problem.** If a sentence could be pasted into another LLD by
   changing the names, delete it.
2. **Design is decided from the spec, line by line.** A field exists because a spec line needs it. A
   method exists because someone outside needs to ask it. Tables make that visible.
3. **Rules live with the state they read and write.** The orchestrator coordinates; entities decide
   from their own state. Workflow rules go in the orchestrator; data rules go in the entity.
4. **An interface is added only for something that will change.** Name the change, then name the seam.
   Never add methods to an interface "for later". When a follow-up adds one, say so.
5. **Logic only where the problem lives.** Everything else is one-liners. For each logic method:
   contract → normal path → edge cases → trace, and the trace matches the real output.
6. **Every mechanism gets an honest "one hole"**: what it still gets wrong, how rarely, and the exact fix.
7. **Follow-ups build on each other** (rules change → load grows → beyond one machine, or the domain's
   natural order). Each one lands on a box that already exists, and the dock proves it with the diff.
8. **No internal references like "move 3".** Refer by section number and name, with a link.
9. **Take follow-ups and pushes from real reports** (`research/<name>.md` in the old workbench folder),
   and name the company when it helps.

## 3. English (the HLD rules)

- Short sentences: aim for ≤ 25 words, never over 35.
- Define every term at first use, in plain words.
- A section title is a sentence that states the point.
- Use numbers, not adjectives. Show the sum. Measure what you quote, and name the machine.
- In "X, not Y", give the cost of each side.
- Avoid "simply", "just", "obviously", "powerful", "robust", "seamless".

## 4. The code: one master file, many snapshots

- `<name>/wb/Main.java` is the **master**. Lines outside markers are the core. A block
  ```
  //@ from fu3a            (optional flags: proof | design | name=cas)
  ...
  //@ end
  ```
  is visible from that snapshot onward. The snapshots, in order: `core, fu1, fu2, fu3a, fu3b, fu4, fu5,
  fu6, extra`. Rename or add them in `SNAPS` in `tools/lld.py` if a problem needs a different ladder.
- **Proof vs design.** `proof` marks demo and check code; the dock dims it and never counts it as the
  change. A `design` block inside a proof block marks lines a candidate would really type, such as the
  wiring line of a follow-up. `name=x` marks a block the page shows by name (`{{named:extra:x}}`), such
  as the extra answers of section 21.
- **Every snapshot compiles** with `-Xlint:all -Werror` **and runs**. Its `main` calls `check(...)` for
  every promise. The page shows real output only.
- **Formatting the outline parser relies on:**
  - 4-space indent;
  - top-level types at column 0, closing `}` alone at column 0;
  - members at indent 4, a method's closing `}` alone at indent 4;
  - one-line methods allowed;
  - comments directly above a type or member belong to it.
- **Broken copies** go in `<name>/wb/config.py`:
  `MUTANTS = {'nolock': ('core', [(find, replace)], runs)}`.
  Each is compiled and run `runs` times; the page shows every run (`{{mutant:nolock}}`). A race test
  must fail on every run of every broken copy, or it is not a test yet.
- **Measure what you quote:** bytes per entity, nanoseconds per call, throughput on one lock against
  many. Keep the throwaway benchmark out of the master.
- Anything that cannot run on the machine (such as Redis) is checked another way (the Lua was run under
  Lua 5.1 against a stand-in), and the page says how.

## 5. The page source

- `<name>/page/NN-*.html` are the parts, joined in name order. Write them in small batches; one huge
  file fails to write.
- Placeholders:
  - `{{svg:x}}` inserts a figure;
  - `{{snippet:snap:Type.member,Type|label}}` inserts code, used inside `<div class="narrow">`, the
    fallback for screens under 1180 px;
  - `{{named:extra:x|label}}` inserts a named block;
  - `{{whole:snap|label}}` inserts the whole file;
  - `{{out:snap}}` or `{{out:snap:prefix}}` inserts the output, or only its lines that start with prefix;
  - `{{mutant:name}}` inserts every run of a broken copy.
- **A docked zone** is `<div class="dz"><div class="narr"> …sections… </div><aside class="dock"></aside></div>`.
  Each section in it looks like
  `<section class="ds" id=… data-snap="core" data-mode="design|code|full" data-focus="Type,Type.method,Type.fields|auto">`.
  - `auto` is for follow-ups: it opens only the members holding new design lines.
  - Full-width parts (big figures, tables) go between zones, inside `<div class="col">`.
- **Line references:** put `data-find="exact text"` (and optionally `data-n="3"`) on a `<code>`,
  `<span>` or `<li>` inside a docked section. The build turns it into line numbers in that section's
  snapshot, and hovering it lights those lines in the dock. A reference that matches nothing stops the
  build.
- Figures are `fig_<x>()` in `<name>/figures.py`, built with `tools/lldkit.py` (`Svg`, `uml`, palette `C`).
  Full-width figures are 960 wide. Figures inside a docked section are 600 wide (`*_n`).

## 6. Build and check

```
python3 tools/lld.py <name>          # compile + run every snapshot and broken copy, write <name>.html
node tools/shoot-at.mjs file://$PWD/<name>.html /tmp/s 1512 945 s-take,s-fu3   # screenshots as a reader scrolls
```

Before calling a page done:
- [ ] Every snapshot compiles and runs; every broken copy fails every run.
- [ ] No page exceptions (shoot-at prints them); each docked section shows the right view and highlight.
- [ ] Each follow-up's dock header names exactly the classes it touches.
- [ ] Every number is measured or computed on the page; the example's table matches the output.
- [ ] No sentence over 35 words; no "move N"; every link resolves.
- [ ] Every figure checked in a screenshot: no overlap, nothing cut off.
- [ ] The narrow layout (1100 px) reads correctly with the inline snippets.

## 7. Finding the design and the ladder for a new problem

1. **The outside view:** 1–3 calls and their answers. More than that means the scope is too big; move
   the rest to the ladder.
2. **The nouns filter**, then **the seams**: which 2–4 things will the interviewer change? Each becomes
   an interface.
3. **The one decision that makes or breaks the design** (BAD / GOOD / GREAT): usually where the changing
   state lives.
4. **The logic:** which 2–3 methods carry the problem? Everything else is a one-liner.
5. **The invariant** that must hold under concurrency, if any: that is the race test.
6. **The ladder:** 5–7 real follow-ups from research, each landing on an existing box, each on the last.

| problem | seams | the make-or-break decision | the logic | ladder |
|---|---|---|---|---|
| Parking lot | spot choice, pricing, payment | a free list per spot size vs scanning spots | `park`, `unpark` (pay, then free) | surge pricing → payment fails → lost ticket → truck needs two spots → display board → many lots |
| LRU cache | eviction policy, clock (TTL) | hash map + doubly linked list vs a scan for the oldest | `get`, `put`, evict | TTL → LFU → size in bytes → striped locks → write-through → many nodes |
| Elevator | dispatch strategy, time (`step()`) | a request with its direction vs bare floor numbers | `step()` (SCAN), `requestElevator` | express cars → cancel a request → concurrent hall calls → peak modes |
| BookMyShow | pricing, payment, hold expiry | hold, then confirm vs lock on select | `hold`, `confirm`, expire | holds expire → payment fails → price tiers → refunds → waitlist → many servers |
| Splitwise | split type | net balance per pair vs a list of expenses | `addExpense`, `settle` | equal / exact / percent → groups → fewest payments → currencies → edit an expense |
| Meeting rooms | room choice | intervals per room in a `TreeMap` vs a scan | `book` (overlap check) | recurring → suggest slots → capacity → cancel + waitlist → time zones |

## 8. How to ask a model for the next page

> Build the LLD workbench for **<problem>** following `lld-v2/BLUEPRINT.md` exactly, with
> `lld-v2/rate-limiter/` as the reference (`wb/Main.java`, `wb/config.py`, `figures.py`, `page/*.html`).
> Take real follow-ups from `research/<name>.md`. **First show me only the outline for approval:** the
> seven questions and what each decides, the spec, the nouns table, the seams, the make-or-break
> decision, the class list with state and methods, the 2–3 logic methods, the invariant, and the ladder
> with box, kind of change and level for each step. After I approve: the master Java (compiled, every
> snapshot run, the race test proven against broken copies), the figures, then the page parts in small
> batches. Build with `tools/lld.py`, screenshot with `tools/shoot-at.mjs`, fix what you see, and give
> me the checklist of section 6.
