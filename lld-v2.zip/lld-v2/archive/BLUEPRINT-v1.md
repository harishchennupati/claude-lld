# LLD page blueprint

The rate limiter page (`rate-limiter.html`) is the reference. It follows every rule below, so when a
rule is unclear, look at what that page does.

## 0. Who the page is for, and how it is read

- The reader is preparing for a 60-minute LLD or machine-coding round. They read everything outside the
  grey folds carefully and skim the folds. Then they close the page and type the code from a blank file.
- Budget per page: about 6,000–8,000 words outside folds. The core code is 120–200 lines, and the
  follow-up code 150–300 lines. Reading takes 60–90 minutes and practice another 60–90, so 2–3 pages fit
  in a day.
- The page must leave the reader able to solve the problem in an interview, and also to think about a
  similar problem at work. Every choice therefore comes with its reason and the cost of the other option.

## 1. The shape of every page

| # | section | what goes in it |
|---|---|---|
| hero | title, pills, reading note, **the problem box** | The interviewer's prompt as a quote (4–6 sentences, realistic). **What this really is**: the core idea in plain words, 4–6 short sentences, ending in the 2–3 answers the design must give. **In scope** / **Out of scope until the interviewer asks** (the out-of-scope items become Part 3). |
| 01 | What it does, from the outside | The system's 1–3 calls and their possible answers, as the caller sees them. Define every word the page uses. **One named example** (Acme, 5 a second) runs through the whole page. Include a figure of the example, plus a table (time, event, state before, answer, state after) that the demo in Part 2 prints exactly. |
| 02 | The hour, and what to ask first | The hour as a table (minutes, what you do, what they check). What must be on screen at minute 45. **5–7 questions** as ask, what to assume if they say "you decide", and what it changes in the code, linking follow-ups by name. **Functional ≤ 5, non-functional ≤ 4**, each one sentence. Close with "Say this before typing". |
| 03 | The core decision | The one choice the whole problem hinges on (rate limiter: the algorithm; parking lot: finding a spot; LRU: map plus list). Tell it as: **The problem**, a story with times and numbers, then **The fix**, then a figure of the failure next to the fix. Follow with a table of the options interviewers name, "**X, not Y**" blocks with the cost of each side, **The one hole**, and **If the interviewer pushes** (2–3 questions). |
| 04 | From the requirements to the classes | 5–8 rows: **what we need, the first idea, what goes wrong, what we do instead**. Each row ends in a class, method or line that exists in the code. Name a pattern in the row where it is born, with its reason. Then **What we leave out, on purpose**: patterns and parts deliberately not used, and why. |
| 05 | The whole design in one picture | The class diagram (SVG), then: **What each box is for** (box, what it is, what it holds). **One call through the boxes**, as a numbered list with real method names. **Where state lives**: what changes, what never changes, what locks. **Why this shape**: one line per structural choice. |
| 06–09 | Part 2: the code, in typing order | 3–5 pieces, each compiling with the pieces before it. Each has: why it exists (2–4 sentences), the code, **What to notice** (3–5 bullets), and **say** (one sentence to say while typing). Add **The one hole** and **If the interviewer pushes** where they apply. The problem story, such as the race, goes in the section whose code fixes it, not in a derivation dump. The last piece is **Prove it**: a demo that replays section 01's example, a concurrency or invariant test, the real output, and **Try it** (break the code on purpose, with the measured numbers). The whole file goes in a fold. |
| 10 | The ladder | A figure of the follow-ups as steps on the core, and a table: the ask, which box it lands on, and the **kind of change** (a new class, a new method, a method added to an interface, a new implementation). |
| 11–16 | One section per follow-up (5–7) | **The ask**, quoted. **Lands on** a named box, with the kind of change. Your thinking (what breaks, what the options are). A figure if it helps. The code: **only the new or changed code**, each block labelled with where it goes ("in TokenBucket"). The output lines from the ladder run. **What to notice**, **The one hole**, **say**. At the end of the part: a fold with the whole ladder file and its output. |
| 17 | Practice | The core from a blank file, in typing order (a timer), then a miss log, then each follow-up (a timer). Read and coded checkboxes. |
| 18 | Remember it | **One map**: 8–10 lines, each starting with a coloured word, for self-testing on days 1, 3 and 7. A **patterns and SOLID** table showing where each actually is, including "not used" with the reason. **Cost** (time and memory, with numbers). **The technical round** in a fold: 6–10 questions and answers. |

## 2. Rules that stop it becoming a template

1. **Derive from this problem, never from a generic method.** No "move 1: underline the nouns". Every row
   in section 04 must be something this problem forces. The test: if the row could be pasted into another
   LLD by changing the names, delete it.
2. **No internal references.** Never write "move 3" or "card 7". Refer to other sections by name, with a
   link ("see *Acme upgrades*").
3. **Put everything where it is used.** Explain concurrency next to the lock, complexity next to the data
   structure, and a failure case next to the code that handles it. Name a pattern where it appears in the
   code. SOLID appears once, in the recap, one line per letter, pointing at real classes.
4. **Keep scope real.** The core is what a strong candidate types in about 35 minutes. Everything else is
   a follow-up. If you list a requirement, the core code must do it.
5. **Use one example everywhere.** Section 01, the demo output and at least two follow-ups use the same
   named example, with numbers small enough to check by hand.
6. **Build the follow-ups on each other.** Order them the way an interview goes: first the rules change,
   then the load grows, then the system grows past one machine, or whatever order fits the domain. Each
   one lands on a box that exists. At least two should reuse an earlier follow-up (in the rate limiter,
   follow-up 4 waits on follow-up 3's two limits, and follow-up 6 replaces the store under both). Say
   plainly when a follow-up changes an interface.
7. **Give every mechanism an honest "one hole"**: what it still gets wrong, how rarely, and the exact fix.
8. **Choose 5–7 follow-ups, not 15.** Merge near-duplicates. Put one-line answers in "If the interviewer
   pushes" instead of making them sections.
9. **Take follow-ups from real reports.** `research/<name>.md` in the old workbench folder lists real
   interview questions with sources. Put the company name in the text when it adds weight ("Atlassian asks
   this, and calls them credits").

## 3. English (the HLD's rules)

- Short sentences: aim for 25 words or fewer, none over 35. One idea per sentence.
- Define every term the first time it appears, in plain words: "A `CountDownLatch` is a gate that opens
  once."
- A section title is a sentence that states the point: "Choosing the algorithm: a counter per minute lets
  through twice the limit".
- Prefer numbers to adjectives. Show the sum ("200 × 5 ÷ 1,000 = 1 token"), and quote only numbers you
  measured or computed, with the machine named.
- In "X, not Y", say what X costs and what Y would have bought.
- Avoid "simply", "just", "obviously", "powerful", "robust", "seamless", and exclamation marks.
- Code comments are one line, say why rather than what, and keep lines ≤ 100 characters.

## 4. Code rules

- Java 17. There are two files, both compiled and run on every build:
  - `<name>/core/Main.java`: exactly what Part 2 shows. It has `//#region words`, `//#region bucket` and
    so on, one region per typing piece.
  - `<name>/ladder/Main.java`: the core plus every follow-up. Each addition sits in `//#region fuN` or
    `//#region fuN-where`, placed where it really goes, inside the class it changes. A nested region is
    hidden when its parent is shown, so follow-up 1's class does not show follow-up 3's method.
- `main` in the core replays section 01's example and asserts with `check(...)`. If the problem has
  shared state, the test must make many threads hit the same invariant many times (rate limiter: 100
  threads over 100 new clients). Prove the test works: break the code (remove the lock, replace the
  atomic operation) and confirm that at least 19 of 20 runs fail. Quote those numbers in **Try it**.
- The ladder's `main` runs one method per follow-up, each with a `check`. Its output lines start with
  `fu1 `, `fu2 ` and so on, so the page can quote them.
- Time is handed in through a `Clock` whenever time matters. No test sleeps, except to show real waiting.
- Measure what you quote: bytes per entity (heap before and after a million entities), nanoseconds per
  operation, throughput on one lock against many. Put the throwaway benchmark in a temp folder, not in the
  page code.
- Anything that cannot run on the machine (such as Redis) is checked another way, and the page says how:
  "run under Lua 5.1 against a stand-in for TIME, HMGET, HSET, PEXPIRE".

## 5. Figures

Figures are SVG, generated by functions in `<name>/figures.py` using `tools/lldkit.py` (`Svg`, `uml`, and
the palette `C`). Required figures:

1. Section 01: the example as the caller sees it (the state over time, with each request marked).
2. Section 03: the first idea failing next to the fix, on the same input.
3. Section 05: the class diagram, using boxes from `uml(...)`: blue dashed boxes for interfaces, teal for
   records, green dashed arrows for things handed in, a diamond for owns, a hollow triangle for
   implements. Include a legend.
4. Part 2: the race or invariant, if the problem has one, shown as two threads side by side, without the
   lock and with it.
5. Section 10: the ladder.

Add 2–3 figures for the follow-ups where a picture beats a paragraph. Every figure gets a sentence title
(`<h3 class="ft">`) that says what to see. Colours keep their meaning: green is allowed or correct, red is
refused or wrong, mauve is the thing we build, yellow is shared or external, blue is an interface or a
network call.

## 6. Build and check

```
python3 tools/build.py <name>                          # compiles + runs both files, fills the page
node tools/shoot.mjs file://$PWD/<name>.html /tmp/p 1512 1300   # screenshots in 1300px slices
```

Placeholders in `<name>/page.html`:
`{{svg:x}}`, `{{code:core:region|label|note}}`, `{{code:ladder:fu3|in TokenBucket}}`,
`{{whole:core|label}}`, `{{out:core|label}}`, `{{outgrep:ladder:fu3}}`. The build stops if any
placeholder is left unfilled.

Before calling a page done:
- [ ] Both files compile with `-Xlint:all -Werror`, and every `check` passes. The page output is the real output.
- [ ] The race test catches both classic bugs in at least 19 of 20 runs, and the numbers are in **Try it**.
- [ ] Every quoted number is measured or computed on the page.
- [ ] Every internal link resolves, and there is no "move N" anywhere.
- [ ] No sentence outside a table is over 35 words (the check script is in the build notes).
- [ ] Every figure has been looked at in a screenshot: no overlapping text, nothing cut off.
- [ ] The functional list matches what the core code does, and nothing more.
- [ ] Each follow-up says which box it lands on and what kind of change it is, and its code compiles in the ladder file.

## 7. Finding the core decision and the ladder for a new problem

1. **The outside view.** Write the 1–3 calls and what each returns. If it needs more than 3, the scope is
   too big: move the rest to the ladder.
2. **The core decision.** Ask: "what does the first thing an ordinary engineer types get wrong, with
   numbers?" That failure, and its fix, is section 03.
3. **The invariant.** What must never be true, even with 100 threads? Two cars in one spot, two tokens
   from one, a seat sold twice, a negative balance. That invariant is the Part 2 race and the Prove it test.
4. **The ladder.** Take the real questions from `research/<name>.md`, merge duplicates, and keep 5–7.
   Order them so each builds on the one before, and tag each with the box it lands on and the kind of
   change.
5. **The example.** Choose numbers small enough to check by hand, and a name to go with them.

Sketches for other problems. These are starting points, to be checked against research before writing:

| problem | core decision (03) | invariant (Part 2) | ladder (Part 3) |
|---|---|---|---|
| Parking lot | find the smallest free spot that fits without scanning: a free list per size | two gates, one last spot | weekend pricing (Decorator) → payment fails at exit (order: pay, then free) → lost ticket (a state) → a truck needs two adjacent spots (all or nothing) → a display per floor (Observer) → many lots or persistence |
| LRU cache | O(1) get and put: a hash map plus a doubly linked list, not a scan for the oldest | the map and the list always agree | TTL per entry → LFU as another eviction policy (Strategy) → capacity in bytes → many threads (one lock, then striped) → write-through to a slow store → many nodes (consistent hashing) |
| Elevator | which car answers a call: nearest idle, or the car already moving that way (LOOK) | one car, one direction; no door open while moving (a state machine) | many cars and a dispatcher → full car skips calls → express or zoned cars → emergency and maintenance modes → morning-peak mode → no call waits forever |
| BookMyShow | hold a seat for 10 minutes, then confirm; not "lock on select" | two users, one seat | holds expire (a sweeper) → payment fails → price tiers → cancel and refund → waitlist → many servers (a conditional update in the database) |
| Splitwise | keep net balances per pair, not a list of every expense | the balances of a group always sum to zero | split types: equal, exact, percent (Strategy) → groups → settle up with the fewest payments → currencies → edit or delete an expense → persistence |
| Meeting rooms | intervals per room in a `TreeMap`: an O(log n) overlap check, not a scan | two bookings never overlap, even when two users book at once | recurring meetings → suggest free slots → capacity and equipment → cancellations and a waitlist → time zones → many buildings |

## 8. How to ask a model for the next page

> Build the LLD page for **<problem>** following `lld-v2/BLUEPRINT.md` exactly. Use
> `lld-v2/rate-limiter/` as the worked reference: `page.html`, `figures.py`, `core/Main.java` and
> `ladder/Main.java`. Take real follow-ups from `research/<name>.md`. First write, and show me for
> approval, only these: the outside view (section 01's calls and example), the core decision, the
> invariant, the 5–7 decisions of section 04, the class list, and the ladder with the box and kind of
> change for each step. Only after I approve, write the Java (core and ladder, both compiled and run,
> the race test proven against broken versions), then the figures, then `page.html`. Build with
> `python3 tools/build.py <name>`, screenshot it, fix what you see, and give me the checklist of section 6.

Approving the outline before any code is what stops a page turning back into a template.
