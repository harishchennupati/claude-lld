"""Build one LLD page:  python3 tools/build.py rate-limiter

Reads   <name>/page.html      the prose, with {{placeholders}}
        <name>/figures.py     fig_<x>() functions that return <svg>
        <name>/core/Main.java     the core (Part 2), with //#region markers
        <name>/ladder/Main.java   the core plus every follow-up (Part 3)
Writes  <name>.html           one self-contained page

Both Java files are compiled and run on every build; the page shows their real output.
Placeholders:
  {{svg:x}}                      figures.fig_x()
  {{code:core|ladder:region|label|note}}
  {{whole:core|ladder|label}}    the whole file
  {{out:core|ladder|label}}      the whole output of `java Main`
  {{outgrep:core|ladder:prefix}} only the output lines that start with prefix
"""
import importlib.util, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from lldkit import region, whole, run_java, code_block, out_block  # noqa: E402


def main(name):
    root = os.path.dirname(HERE)
    d = os.path.join(root, name)
    src = {k: os.path.join(d, k, 'Main.java') for k in ('core', 'ladder')}
    outs = {k: run_java(os.path.join(d, k)) for k in src}
    spec = importlib.util.spec_from_file_location('figures', os.path.join(d, 'figures.py'))
    assert spec is not None and spec.loader is not None
    figs = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(figs)
    page = open(os.path.join(d, 'page.html'), encoding='utf-8').read()

    def sub(m):
        kind, arg = m.group(1), m.group(2)
        parts = arg.split('|')
        if kind == 'svg':
            return getattr(figs, 'fig_' + parts[0])()
        if kind == 'code':
            which, reg = parts[0].split(':')
            label = parts[1] if len(parts) > 1 else ''
            note = parts[2] if len(parts) > 2 else ''
            return code_block(region(src[which], reg), label, note)
        if kind == 'whole':
            return code_block(whole(src[parts[0]]), parts[1] if len(parts) > 1 else 'Main.java')
        if kind == 'out':
            return out_block(outs[parts[0]], 'output · ' + (parts[1] if len(parts) > 1 else 'java Main'))
        if kind == 'outgrep':
            which, prefix = parts[0].split(':')
            lines = [l for l in outs[which].split('\n') if l.startswith(prefix + ' ')]
            if not lines:
                raise ValueError('no output lines for ' + arg)
            return out_block('\n'.join(lines), 'output · the lines of java Main for this follow-up')
        raise ValueError(m.group(0))

    html = re.sub(r'\{\{(svg|code|whole|out|outgrep):([^}]*)\}\}', sub, page)
    left = re.findall(r'\{\{[^}]*\}\}', html)
    if left:
        raise SystemExit('unfilled placeholders: ' + ', '.join(left))
    target = os.path.join(root, name + '.html')
    open(target, 'w', encoding='utf-8').write(html)
    print('wrote', target, f'{len(html):,} bytes')
    check(html)
    for k, o in outs.items():
        print(f'--- {k} output\n{o}')


def check(html):
    """The page rules that a script can check: links, "move N" references, sentence length."""
    import html as H
    ids = set(re.findall(r'id="([^"]+)"', html))
    bad_links = sorted(set(re.findall(r'href="#([^"]+)"', html)) - ids)
    body = html.split('<main>', 1)[1]
    body = re.sub(r'<script.*?</script>|<svg.*?</svg>|<div class="cb[^"]*".*?</pre></div>', '', body, flags=re.S)
    moves = re.findall(r'\b(?:move|card)\s+\d+', H.unescape(re.sub(r'<[^>]+>', ' ', body)), flags=re.I)
    long = []
    for tag, b in re.findall(r'<(p|li|h2|h3)[^>]*>(.*?)</\1>', body, flags=re.S):
        t = ' '.join(H.unescape(re.sub(r'<[^>]+>', '', b)).split())
        for sent in re.split(r'(?<=[.!?;])\s+(?=[A-Z"\u201c(0-9])', t):
            if len(sent.split()) > 35:
                long.append(sent)
    words = len(H.unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'<details.*?</details>', '', body, flags=re.S))).split())
    print(f'check: {words:,} words outside folds; broken links {bad_links or "none"}; '
          f'"move N" refs {moves or "none"}; sentences over 35 words: {len(long)}')
    for sent in long:
        print('   long:', sent[:140])


if __name__ == '__main__':
    main(sys.argv[1])
