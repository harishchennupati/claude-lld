import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

//#region words
// A limit: at most `limit` requests per window. 100 a minute is Rule(100, 60_000).
record Rule(int limit, long windowMillis) {
    Rule {
        if (limit <= 0 || windowMillis <= 0) throw new IllegalArgumentException("must be > 0");
    }
    static Rule perSecond(int n) { return new Rule(n, 1_000); }
    static Rule perMinute(int n) { return new Rule(n, 60_000); }
}

// The answer to one request. On a refusal: when to try again (HTTP's Retry-After).
record Decision(boolean allowed, long retryAfterMillis) {
    static Decision allow()           { return new Decision(true, 0); }
    static Decision deny(long waitMs) { return new Decision(false, waitMs); }

    @Override public String toString() {
        return allowed ? "allowed" : "refused, retry in " + retryAfterMillis + " ms";
    }
}

// Where "now" comes from. It is handed in, so a test moves time by hand instead of sleeping.
interface Clock {
    long millis();
}

class SystemClock implements Clock {
    // nanoTime, not currentTimeMillis: it never jumps back when the machine's clock is fixed
    public long millis() { return System.nanoTime() / 1_000_000; }
}

class ManualClock implements Clock {
    private volatile long now;
    ManualClock(long startMillis) { now = startMillis; }
    public long millis()          { return now; }
    void advance(long ms)         { now += ms; }      // only the test's own thread calls this
}
//#endregion

//#region bucket
// One client's budget. Each algorithm is a class that implements this.
interface Bucket {
    Decision tryTake(long nowMillis);
}

// Makes the bucket for a client seen for the first time. TokenBucket::new is one.
interface BucketFactory {
    Bucket create(Rule rule, long nowMillis);
}

// Holds up to `capacity` tokens and earns `capacity` tokens back per window, a little every
// millisecond. A request spends one token. No timer: each call first adds what time earned.
class TokenBucket implements Bucket {
    private final int capacity;
    private final long windowMillis;
    private double tokens;              // tokens left
    private long lastRefillMillis;      // when `tokens` was last brought up to date

    TokenBucket(Rule rule, long nowMillis) {
        this.capacity = rule.limit();
        this.windowMillis = rule.windowMillis();
        this.tokens = capacity;         // a new client starts with a full bucket
        this.lastRefillMillis = nowMillis;
    }

    @Override
    public synchronized Decision tryTake(long nowMillis) {
        refill(nowMillis);
        if (tokens >= 1) {
            tokens -= 1;
            return Decision.allow();
        }
        // not enough: say how long until one whole token has been earned
        long wait = (long) Math.ceil((1 - tokens) * windowMillis / capacity);
        return Decision.deny(wait);
    }

    private void refill(long nowMillis) {
        long elapsed = nowMillis - lastRefillMillis;
        if (elapsed <= 0) return;       // same millisecond, or an older reading: earn nothing
        tokens = Math.min(capacity, tokens + (double) elapsed * capacity / windowMillis);
        lastRefillMillis = nowMillis;
    }
}
//#endregion

//#region limiter
// What the API calls before it does any work for a request.
interface RateLimiter {
    Decision allow(String clientId);
}

// Which rule each client is on: one default, and overrides for some clients.
class RuleBook {
    private final Rule defaultRule;
    private final Map<String, Rule> overrides = new ConcurrentHashMap<>();

    RuleBook(Rule defaultRule)           { this.defaultRule = defaultRule; }
    void set(String clientId, Rule rule) { overrides.put(clientId, rule); }
    Rule ruleFor(String clientId)        { return overrides.getOrDefault(clientId, defaultRule); }
}

// One process, in memory: a bucket per client, made on the client's first request.
class LocalRateLimiter implements RateLimiter {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();
    private final RuleBook rules;
    private final BucketFactory newBucket;
    private final Clock clock;

    LocalRateLimiter(RuleBook rules, BucketFactory newBucket, Clock clock) {
        this.rules = rules;
        this.newBucket = newBucket;
        this.clock = clock;
    }

    @Override
    public Decision allow(String clientId) {
        long now = clock.millis();
        // exactly one bucket per client, even when two threads see a new client at once
        Bucket bucket = buckets.computeIfAbsent(clientId,
                id -> newBucket.create(rules.ruleFor(id), now));
        return bucket.tryTake(now);     // locks this client's bucket only
    }
}
//#endregion

//#region main
public class Main {
    public static void main(String[] args) throws Exception {
        ManualClock clock = new ManualClock(0);
        RuleBook rules = new RuleBook(Rule.perMinute(100));   // everyone: 100 a minute
        rules.set("acme", Rule.perSecond(5));                 // acme: 5 a second
        RateLimiter limiter = new LocalRateLimiter(rules, TokenBucket::new, clock);

        // t = 0: a burst of 7. The bucket holds 5, so 5 pass and 2 are told to wait.
        for (int i = 1; i <= 7; i++) {
            System.out.println("t=0     #" + i + " " + limiter.allow("acme"));
        }
        clock.advance(200);                                   // 200 ms earns 1 token
        System.out.println("t=200   #8 " + limiter.allow("acme"));
        System.out.println("t=200   #9 " + limiter.allow("acme"));

        clock.advance(5_000);                                 // 5 quiet seconds...
        int passed = 0;
        for (int i = 0; i < 10; i++) if (limiter.allow("acme").allowed()) passed++;
        System.out.println("t=5200  10 more: " + passed + " allowed");
        check(passed == 5, "a bucket never holds more than its capacity");

        race();
    }

    // 100 threads send 1,000 requests each, spread over 100 new clients, on a frozen clock.
    // Every client may pass 500, so exactly 100 x 500 = 50,000 may pass in total.
    static void race() throws Exception {
        ManualClock clock = new ManualClock(0);               // frozen: nothing refills
        RateLimiter limiter = new LocalRateLimiter(
                new RuleBook(Rule.perMinute(500)), TokenBucket::new, clock);
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        AtomicInteger passed = new AtomicInteger();
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();                                   // all 100 start together
                for (int i = 0; i < 1_000; i++) {
                    if (limiter.allow("client-" + i % 100).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("race    100 threads, 100,000 requests: " + passed.get() + " allowed");
        check(passed.get() == 50_000, "never more than the limit, whatever the thread count");
    }

    static void check(boolean ok, String rule) {
        if (!ok) throw new AssertionError("broken: " + rule);
    }
}
//#endregion
