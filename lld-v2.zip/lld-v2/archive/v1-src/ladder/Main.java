import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

// The core from Part 2, with the six follow-ups of Part 3 added on top.
// Every //#region fuN marks what follow-up N added.

//#region words
// A limit: at most `limit` requests per window. 100 a minute is Rule(100, 60_000).
record Rule(int limit, long windowMillis) {
    Rule {
        if (limit <= 0 || windowMillis <= 0) throw new IllegalArgumentException("must be > 0");
    }
    static Rule perSecond(int n) { return new Rule(n, 1_000); }
    static Rule perMinute(int n) { return new Rule(n, 60_000); }
}

// The answer to one request. On a refusal: when to try again (HTTP's Retry-After).
record Decision(boolean allowed, long retryAfterMillis) {
    static Decision allow()           { return new Decision(true, 0); }
    static Decision deny(long waitMs) { return new Decision(false, waitMs); }

    @Override public String toString() {
        return allowed ? "allowed" : "refused, retry in " + retryAfterMillis + " ms";
    }
}

// Where "now" comes from. It is handed in, so a test moves time by hand instead of sleeping.
interface Clock {
    long millis();
}

class SystemClock implements Clock {
    // nanoTime, not currentTimeMillis: it never jumps back when the machine's clock is fixed
    public long millis() { return System.nanoTime() / 1_000_000; }
}

class ManualClock implements Clock {
    private volatile long now;
    ManualClock(long startMillis) { now = startMillis; }
    public long millis()          { return now; }
    void advance(long ms)         { now += ms; }      // only the test's own thread calls this
}
//#endregion

//#region bucket
// One client's budget. Each algorithm is a class that implements this.
interface Bucket {
    Decision tryTake(long nowMillis);
    //#region fu3-iface
    void refund(long nowMillis);            // give back one token taken by tryTake
    //#endregion
    //#region fu5-iface
    boolean isIdle(long nowMillis);         // true when forgetting it loses nothing
    //#endregion
}

// Makes the bucket for a client seen for the first time. TokenBucket::new is one.
interface BucketFactory {
    Bucket create(Rule rule, long nowMillis);
}

// Holds up to `capacity` tokens and earns `capacity` tokens back per window, a little every
// millisecond. A request spends one token. No timer: each call first adds what time earned.
class TokenBucket implements Bucket {
    private final int capacity;
    private final long windowMillis;
    private double tokens;              // tokens left
    private long lastRefillMillis;      // when `tokens` was last brought up to date

    TokenBucket(Rule rule, long nowMillis) {
        this.capacity = rule.limit();
        this.windowMillis = rule.windowMillis();
        this.tokens = capacity;         // a new client starts with a full bucket
        this.lastRefillMillis = nowMillis;
    }

    @Override
    public synchronized Decision tryTake(long nowMillis) {
        refill(nowMillis);
        if (tokens >= 1) {
            tokens -= 1;
            return Decision.allow();
        }
        // not enough: say how long until one whole token has been earned
        long wait = (long) Math.ceil((1 - tokens) * windowMillis / capacity);
        return Decision.deny(wait);
    }

    private void refill(long nowMillis) {
        long elapsed = nowMillis - lastRefillMillis;
        if (elapsed <= 0) return;       // same millisecond, or an older reading: earn nothing
        tokens = Math.min(capacity, tokens + (double) elapsed * capacity / windowMillis);
        lastRefillMillis = nowMillis;
    }
    //#region fu3-token

    @Override
    public synchronized void refund(long nowMillis) {
        tokens = Math.min(capacity, tokens + 1);        // never above a full bucket
    }
    //#endregion
    //#region fu5-token

    @Override
    public synchronized boolean isIdle(long nowMillis) {
        return nowMillis - lastRefillMillis >= windowMillis;   // unused for a window: full again
    }
    //#endregion
}
//#endregion

//#region fu1
// Exact: never more than `limit` requests in ANY stretch of one window.
// It keeps the time of every request it let through, oldest first.
class SlidingWindowLog implements Bucket {
    private final int limit;
    private final long windowMillis;
    private final ArrayDeque<Long> times = new ArrayDeque<>();

    SlidingWindowLog(Rule rule, long nowMillis) {
        this.limit = rule.limit();
        this.windowMillis = rule.windowMillis();
    }

    @Override
    public synchronized Decision tryTake(long nowMillis) {
        // forget the requests that have left the window
        while (!times.isEmpty() && times.peekFirst() <= nowMillis - windowMillis) {
            times.pollFirst();
        }
        if (times.size() < limit) {
            times.addLast(nowMillis);
            return Decision.allow();
        }
        // full: a place opens when the oldest request leaves the window
        return Decision.deny(times.peekFirst() + windowMillis - nowMillis);
    }
    //#region fu3-log

    @Override
    public synchronized void refund(long nowMillis) {
        times.pollLast();                               // un-count the newest request
    }
    //#endregion
    //#region fu5-log

    @Override
    public synchronized boolean isIdle(long nowMillis) {
        return times.isEmpty() || times.peekLast() <= nowMillis - windowMillis;
    }
    //#endregion
}
//#endregion

//#region fu3
// A request must pass the client's own bucket AND the one bucket all clients share.
class BothBuckets implements Bucket {
    private final Bucket own;
    private final Bucket shared;

    BothBuckets(Bucket own, Bucket shared) {
        this.own = own;
        this.shared = shared;
    }

    @Override
    public Decision tryTake(long nowMillis) {
        Decision mine = own.tryTake(nowMillis);
        if (!mine.allowed()) return mine;               // stopped by its own limit: shared untouched
        Decision all = shared.tryTake(nowMillis);
        if (!all.allowed()) own.refund(nowMillis);      // stopped by the shared one: give it back
        return all;
    }

    @Override
    public void refund(long nowMillis) {
        own.refund(nowMillis);
        shared.refund(nowMillis);
    }
    //#region fu5-both

    @Override
    public boolean isIdle(long nowMillis) {
        return own.isIdle(nowMillis);                   // forget the client, never the shared one
    }
    //#endregion
}
//#endregion

//#region limiter
// What the API calls before it does any work for a request.
interface RateLimiter {
    Decision allow(String clientId);
}

// Which rule each client is on: one default, and overrides for some clients.
class RuleBook {
    private final Rule defaultRule;
    private final Map<String, Rule> overrides = new ConcurrentHashMap<>();

    RuleBook(Rule defaultRule)           { this.defaultRule = defaultRule; }
    void set(String clientId, Rule rule) { overrides.put(clientId, rule); }
    Rule ruleFor(String clientId)        { return overrides.getOrDefault(clientId, defaultRule); }
}

// One process, in memory: a bucket per client, made on the client's first request.
class LocalRateLimiter implements RateLimiter {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();
    private final RuleBook rules;
    private final BucketFactory newBucket;
    private final Clock clock;

    LocalRateLimiter(RuleBook rules, BucketFactory newBucket, Clock clock) {
        this.rules = rules;
        this.newBucket = newBucket;
        this.clock = clock;
    }

    @Override
    public Decision allow(String clientId) {
        long now = clock.millis();
        // exactly one bucket per client, even when two threads see a new client at once
        Bucket bucket = buckets.computeIfAbsent(clientId,
                id -> newBucket.create(rules.ruleFor(id), now));
        return bucket.tryTake(now);     // locks this client's bucket only
    }
    //#region fu2

    // A new plan takes effect on the client's next request. The order of the two lines matters.
    void changeRule(String clientId, Rule rule) {
        rules.set(clientId, rule);      // 1. new buckets for this client get the new rule
        buckets.remove(clientId);       // 2. drop the old bucket; the next request makes a new one
    }
    //#endregion
    //#region fu5

    // Forgets clients idle for a whole window. Runs on a timer, never on the request path:
    //   Executors.newSingleThreadScheduledExecutor()
    //            .scheduleAtFixedRate(limiter::evictIdle, 1, 1, TimeUnit.MINUTES);
    int evictIdle() {
        long now = clock.millis();
        int removed = 0;
        for (Map.Entry<String, Bucket> e : buckets.entrySet()) {
            // remove(key, value) removes only if the map still holds this same bucket
            if (e.getValue().isIdle(now) && buckets.remove(e.getKey(), e.getValue())) removed++;
        }
        return removed;
    }

    int size() { return buckets.size(); }
    //#endregion
}
//#endregion

//#region fu4
// For callers that would rather wait than be refused, such as a nightly batch job.
final class Waiting {
    // Waits up to maxWaitMillis for a permit. Returns false at once if the wait would be longer.
    static boolean acquire(RateLimiter limiter, String clientId, long maxWaitMillis)
            throws InterruptedException {
        long deadline = System.nanoTime() + maxWaitMillis * 1_000_000;
        while (true) {
            Decision d = limiter.allow(clientId);
            if (d.allowed()) return true;
            long leftMillis = (deadline - System.nanoTime()) / 1_000_000;
            if (d.retryAfterMillis() > leftMillis) return false;  // give up now, not at the deadline
            Thread.sleep(d.retryAfterMillis());
        }
    }
}
//#endregion

//#region fu6
// The one call this limiter needs from a Redis client library such as Jedis or Lettuce.
interface Redis {
    List<Long> eval(String script, List<String> keys, List<String> args);
}

// Many servers, one budget per client. The bucket lives in Redis, and one Lua script refills
// and takes in one step. Redis runs one script at a time, so two servers never interleave.
class RedisRateLimiter implements RateLimiter {
    static final String TOKEN_BUCKET = """
        local capacity, window = tonumber(ARGV[1]), tonumber(ARGV[2])
        local t = redis.call('TIME')                  -- Redis's clock: every server agrees
        local now = t[1] * 1000 + math.floor(t[2] / 1000)
        local b = redis.call('HMGET', KEYS[1], 'tokens', 'last')
        local tokens = tonumber(b[1]) or capacity      -- a new client starts full
        local last = tonumber(b[2]) or now
        if now > last then
          tokens = math.min(capacity, tokens + (now - last) * capacity / window)
          last = now
        end
        local allowed, wait = 0, 0
        if tokens >= 1 then
          tokens, allowed = tokens - 1, 1
        else
          wait = math.ceil((1 - tokens) * window / capacity)
        end
        redis.call('HSET', KEYS[1], 'tokens', tostring(tokens), 'last', last)
        redis.call('PEXPIRE', KEYS[1], window)        -- unused for a window: Redis forgets it
        return {allowed, wait}
        """;

    private final Redis redis;
    private final RuleBook rules;
    private final boolean failOpen;     // Redis unreachable: let requests through, or refuse?

    RedisRateLimiter(Redis redis, RuleBook rules, boolean failOpen) {
        this.redis = redis;
        this.rules = rules;
        this.failOpen = failOpen;
    }

    @Override
    public Decision allow(String clientId) {
        Rule r = rules.ruleFor(clientId);
        try {
            List<Long> res = redis.eval(TOKEN_BUCKET, List.of("rate:" + clientId),
                    List.of(String.valueOf(r.limit()), String.valueOf(r.windowMillis())));
            return res.get(0) == 1 ? Decision.allow() : Decision.deny(res.get(1));
        } catch (RuntimeException redisDown) {
            return failOpen ? Decision.allow() : Decision.deny(1_000);
        }
    }
}
//#endregion

public class Main {
    public static void main(String[] args) throws Exception {
        fu1SlidingWindow();
        fu2ChangePlan();
        fu3BothLimits();
        fu4Waiting();
        fu5EvictIdle();
        fu6Redis();
        System.out.println("all follow-up checks passed");
    }

    // 5 a minute. A burst of 5 at t=0, then one request a second: how many pass in minute one?
    static void fu1SlidingWindow() {
        for (String name : List.of("TokenBucket", "SlidingWindowLog")) {
            ManualClock clock = new ManualClock(0);
            RuleBook rules = new RuleBook(Rule.perMinute(5));
            //#region fu1-use
            BucketFactory algorithm = name.equals("TokenBucket") ? TokenBucket::new
                                                                  : SlidingWindowLog::new;
            RateLimiter limiter = new LocalRateLimiter(rules, algorithm, clock);
            //#endregion
            int passed = 0;
            for (int i = 0; i < 5; i++) if (limiter.allow("login:asha").allowed()) passed++;
            for (int s = 1; s < 60; s++) {
                clock.advance(1_000);
                if (limiter.allow("login:asha").allowed()) passed++;
            }
            System.out.println("fu1  " + name + ": " + passed + " passed in the first minute");
            check(passed == (name.equals("TokenBucket") ? 9 : 5), "fu1 " + name);
        }
    }

    static void fu2ChangePlan() {
        ManualClock clock = new ManualClock(0);
        RuleBook rules = new RuleBook(Rule.perMinute(100));
        rules.set("acme", Rule.perSecond(5));
        LocalRateLimiter limiter = new LocalRateLimiter(rules, TokenBucket::new, clock);
        for (int i = 0; i < 5; i++) limiter.allow("acme");            // acme spends its 5

        rules.set("acme", Rule.perSecond(50));                        // the bug: only the book
        System.out.println("fu2  book changed only:  " + limiter.allow("acme"));
        check(!limiter.allow("acme").allowed(), "fu2 old bucket still in use");

        limiter.changeRule("acme", Rule.perSecond(50));               // the fix
        int passed = 0;
        for (int i = 0; i < 60; i++) if (limiter.allow("acme").allowed()) passed++;
        System.out.println("fu2  after changeRule:   " + passed + " of 60 at once");
        check(passed == 50, "fu2 new plan applies on the next request");
    }

    // Each client: 10 a second. The whole API: 15 a second, shared by everyone.
    static void fu3BothLimits() {
        ManualClock clock = new ManualClock(0);
        //#region fu3-use
        Bucket wholeApi = new TokenBucket(Rule.perSecond(15), clock.millis());   // made once
        BucketFactory both = (rule, now) -> new BothBuckets(new TokenBucket(rule, now), wholeApi);
        RateLimiter limiter = new LocalRateLimiter(new RuleBook(Rule.perSecond(10)), both, clock);
        //#endregion
        int a = 0, b = 0;
        for (int i = 0; i < 10; i++) if (limiter.allow("A").allowed()) a++;
        for (int i = 0; i < 10; i++) if (limiter.allow("B").allowed()) b++;
        System.out.println("fu3  t=0    A: " + a + " of 10, B: " + b + " of 10 (shared ran out)");
        check(a == 10 && b == 5, "fu3 shared limit");

        clock.advance(400);             // shared earns 6, B's own earns 4 on top of the 5 kept
        int b2 = 0;
        for (int i = 0; i < 10; i++) if (limiter.allow("B").allowed()) b2++;
        System.out.println("fu3  t=400  B: " + b2 + " of 10 (4 without the refund)");
        check(b2 == 6, "fu3 refunds kept B's own tokens");
    }

    static void fu4Waiting() throws InterruptedException {
        RuleBook rules = new RuleBook(Rule.perSecond(5));
        RateLimiter limiter = new LocalRateLimiter(rules, TokenBucket::new, new SystemClock());
        long start = System.nanoTime();
        List<Long> waited = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            check(Waiting.acquire(limiter, "batch-job", 1_000), "fu4 acquire within 1 s");
            long ms = (System.nanoTime() - start) / 1_000_000;
            waited.add(Math.round(ms / 100.0) * 100);
        }
        System.out.println("fu4  8 permits, got at about (ms): " + waited);
        boolean quick = Waiting.acquire(limiter, "batch-job", 50);
        System.out.println("fu4  next one with 50 ms to spare: " + quick);
        check(!quick && waited.get(7) >= 500, "fu4 waits, and gives up early");
    }

    static void fu5EvictIdle() {
        ManualClock clock = new ManualClock(0);
        LocalRateLimiter limiter = new LocalRateLimiter(
                new RuleBook(Rule.perMinute(100)), TokenBucket::new, clock);
        for (int i = 0; i < 100_000; i++) limiter.allow("key-" + i);
        clock.advance(30_000);
        limiter.allow("key-7");                                       // one client stays busy
        int early = limiter.evictIdle();
        clock.advance(30_000);
        int late = limiter.evictIdle();
        System.out.println("fu5  100,000 clients: evicted " + early + " at 30 s, "
                + late + " at 60 s, " + limiter.size() + " left");
        check(early == 0 && late == 99_999 && limiter.size() == 1, "fu5 eviction");
    }

    // No Redis on this machine: a stand-in runs the same token bucket per key, one call at a
    // time, the way Redis runs one script at a time. It checks the Java side, not the Lua.
    static void fu6Redis() {
        Map<String, TokenBucket> store = new HashMap<>();
        long t0 = System.nanoTime();
        Redis standIn = (script, keys, args) -> {
            synchronized (store) {
                long now = (System.nanoTime() - t0) / 1_000_000;
                Rule rule = new Rule(Integer.parseInt(args.get(0)), Long.parseLong(args.get(1)));
                Decision d = store.computeIfAbsent(keys.get(0), k -> new TokenBucket(rule, now))
                                  .tryTake(now);
                return List.of(d.allowed() ? 1L : 0L, d.retryAfterMillis());
            }
        };
        RuleBook rules = new RuleBook(Rule.perMinute(100));
        // three servers, one Redis: together they may pass 100, not 300
        List<RateLimiter> servers = List.of(new RedisRateLimiter(standIn, rules, true),
                new RedisRateLimiter(standIn, rules, true), new RedisRateLimiter(standIn, rules, true));
        int passed = 0;
        for (int i = 0; i < 300; i++) if (servers.get(i % 3).allow("acme").allowed()) passed++;
        System.out.println("fu6  3 servers, 300 requests: " + passed + " allowed");
        check(passed == 100, "fu6 one budget across servers");

        Redis down = (script, keys, args) -> { throw new IllegalStateException("timeout"); };
        Decision open = new RedisRateLimiter(down, rules, true).allow("acme");
        Decision closed = new RedisRateLimiter(down, rules, false).allow("acme");
        System.out.println("fu6  Redis down: fail open -> " + open + "; fail closed -> " + closed);
        check(open.allowed() && !closed.allowed(), "fu6 fail open / closed");
    }

    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError("broken: " + what);
    }
}
