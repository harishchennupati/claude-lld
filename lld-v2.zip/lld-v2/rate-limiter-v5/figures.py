"""v5 figures: the growing diagram, the derivation, the design in layers, and scaling out."""
import sys, os, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'tools'))
from lldkit import Svg, C  # type: ignore  # noqa: E402

_spec = importlib.util.spec_from_file_location('figures_v4', os.path.join(HERE, '..', 'rate-limiter', 'figures.py'))
assert _spec is not None and _spec.loader is not None
v4 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v4)
fig_acme, fig_edge, fig_race_n, fig_fu1_n = v4.fig_acme, v4.fig_edge, v4.fig_race_n, v4.fig_fu1_n

STROKE = {'iface': C['blue'], 'record': C['teal'], 'enum': C['teal'], 'class': C['line']}


def box(s, x, y, w, h, kind, name, sub='', nid=None, size=11):
    dash = ' stroke-dasharray="5 3"' if kind == 'iface' else ''
    g = f'<g class="nd" data-n="{nid}">' if nid else '<g>'
    s.add(g + f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="{C["sur"]}" stroke="{STROKE[kind]}" stroke-width="1.5"{dash}/>'
          f'<text x="{x + w / 2}" y="{y + (15 if sub else h / 2 + 4)}" font-size="{size}" font-weight="600" fill="{C["txt"]}" text-anchor="middle">{name}</text>'
          + (f'<text class="sub" data-n="{nid}" x="{x + w / 2}" y="{y + 29}" font-size="9" fill="{C["mut"]}" text-anchor="middle">{sub}</text>' if sub else '')
          + '</g>')


# ----------------------------------------------------------------------------- the growing diagram
MINI = [
    # id, x, y, w, kind, sub
    ('ApiFilter', 8, 8, 110, 'class', 'HTTP 429, headers'),
    ('RateLimiter', 128, 8, 140, 'iface', 'check(request)'),
    ('Waiting', 278, 8, 90, 'class', 'waits its turn'),
    ('ShadowLimiter', 376, 8, 100, 'class', 'dry run'),
    ('DecisionListener', 8, 68, 132, 'iface', 'onDecision'),
    ('RateLimiterService', 150, 68, 172, 'class', 'all rules, or none'),
    ('Clock', 332, 68, 144, 'iface', 'System · Manual'),
    ('RefusalCounter', 8, 128, 132, 'class', 'refusals per rule'),
    ('RuleBook', 150, 128, 100, 'class', 'rulesFor(req)'),
    ('Rule', 258, 128, 100, 'record', 'a row of config'),
    ('Plans', 366, 128, 110, 'class', 'FREE · PRO'),
    ('Request', 8, 188, 110, 'record', 'who, where, cost'),
    ('Scope', 126, 188, 110, 'enum', 'CLIENT · GLOBAL'),
    ('Limit', 244, 188, 100, 'record', 'permits, window'),
    ('Decision', 352, 188, 124, 'record', 'left · retry · rule'),
    ('BucketStore', 8, 248, 150, 'iface', 'bucket(rule, key)'),
    ('LocalBucketStore', 166, 248, 150, 'class', 'map: key → Bucket'),
    ('LeasingStore', 324, 248, 152, 'class', 'batches per server'),
    ('RedisBucketStore', 8, 308, 150, 'class', 'one budget, fleet-wide'),
    ('FallbackBucket', 166, 308, 150, 'class', 'fail open · closed'),
    ('Breaker', 324, 308, 152, 'class', 'stop calling a dead Redis'),
    ('Algorithm', 8, 368, 150, 'iface', 'newBucket(limit)'),
    ('Bucket', 166, 368, 150, 'iface', 'tryTake · refund'),
    ('RedisTokenBucket', 324, 368, 152, 'class', 'one Lua script'),
    ('TokenBucket', 8, 428, 150, 'class', 'tokens · lastRefill'),
    ('SlidingWindowLog', 166, 428, 150, 'class', 'a timestamp each'),
    ('LeasedBucket', 324, 428, 152, 'class', 'spend leased tokens'),
]
H = 38
_pos = {n: (x, y, w) for n, x, y, w, _, _ in MINI}


def _anchor(n, side):
    x, y, w = _pos[n]
    return {'top': (x + w / 2, y), 'bottom': (x + w / 2, y + H), 'left': (x, y + H / 2), 'right': (x + w, y + H / 2)}[side]


MINI_EDGES = [
    # a, b, kind, a-side, b-side
    ('ApiFilter', 'RateLimiter', 'uses', 'right', 'left'),
    ('Waiting', 'RateLimiter', 'uses', 'left', 'right'),
    ('ShadowLimiter', 'RateLimiter', 'impl', 'top', 'top'),
    ('RateLimiterService', 'RateLimiter', 'impl', 'top', 'bottom'),
    ('RateLimiterService', 'DecisionListener', 'uses', 'left', 'right'),
    ('RefusalCounter', 'DecisionListener', 'impl', 'top', 'bottom'),
    ('RateLimiterService', 'Clock', 'handed', 'right', 'left'),
    ('RateLimiterService', 'RuleBook', 'handed', 'bottom', 'top'),
    ('RuleBook', 'Rule', 'uses', 'right', 'left'),
    ('Rule', 'Plans', 'uses', 'right', 'left'),
    ('Rule', 'Scope', 'uses', 'bottom', 'top'),
    ('Rule', 'Limit', 'uses', 'bottom', 'top'),
    ('LocalBucketStore', 'BucketStore', 'impl', 'left', 'right'),
    ('LeasingStore', 'LocalBucketStore', 'impl', 'left', 'right'),
    ('RedisBucketStore', 'BucketStore', 'impl', 'top', 'bottom'),
    ('FallbackBucket', 'Breaker', 'uses', 'right', 'left'),
    ('Algorithm', 'Bucket', 'makes', 'right', 'left'),
    ('RedisTokenBucket', 'Bucket', 'impl', 'left', 'right'),
    ('TokenBucket', 'Bucket', 'impl', 'top', 'bottom'),
    ('SlidingWindowLog', 'Bucket', 'impl', 'top', 'bottom'),
    ('LeasedBucket', 'Bucket', 'impl', 'left', 'right'),
    ('FallbackBucket', 'Bucket', 'impl', 'bottom', 'top'),
]


def fig_mini():
    s = Svg(484, 520)
    for a, b, kind, sa, sb in MINI_EDGES:
        (x1, y1), (x2, y2) = _anchor(a, sa), _anchor(b, sb)
        if sa == sb == 'top':                                    # a decorator reaching back over the top
            pts = [(x1, y1), (x1, y1 - 4), (x2 + 40, y2 - 4), (x2 + 40, y2)]
        elif sa in ('top', 'bottom') and sb in ('top', 'bottom'):
            my = (y1 + y2) / 2
            pts = [(x1, y1), (x1, my), (x2, my), (x2, y2)]
        else:
            pts = [(x1, y1), (x2, y2)]
        col = {'handed': C['green'], 'makes': C['acc']}.get(kind, C['mut'])
        dash = {'handed': '5 3', 'makes': '2 3'}.get(kind)
        end = {'impl': 'tri', 'handed': 'arr-green', 'makes': 'arr-acc'}.get(kind, 'arr')
        d = 'M' + ' L'.join(f'{x:.0f} {y:.0f}' for x, y in pts)
        extra = (f' stroke-dasharray="{dash}"' if dash else '') + f' marker-end="url(#{end})"'
        s.add(f'<g class="ed" data-a="{a}" data-b="{b}"><path d="{d}" fill="none" stroke="{col}" stroke-width="1.3"{extra}/></g>')
    for n, x, y, w, kind, sub in MINI:
        box(s, x, y, w, H, kind, n, sub, nid=n, size=10.5)
    s.text(8, 490, 'blue dashed: interface · teal: record or enum · green dashed: handed in', size=9, fill=C['dim'])
    s.text(8, 505, '▷ implements · purple: this step · green: new in this step', size=9, fill=C['dim'])
    return s.render('The design, growing step by step')


# ----------------------------------------------------------------------------- derivation
def fig_d_nouns():
    s = Svg(960, 330)
    s.rich(20, 26, [('A ', C['mut'], None), ('CLIENT', C['yellow'], '700'), (' on a ', C['mut'], None), ('PLAN', C['yellow'], '700'),
                    (' sends a ', C['mut'], None), ('REQUEST', C['yellow'], '700'), (' to an ', C['mut'], None), ('ENDPOINT', C['yellow'], '700'),
                    ('. ', C['mut'], None), ('RULES', C['yellow'], '700'), (' cap how many per ', C['mut'], None), ('WINDOW', C['yellow'], '700'),
                    (': per client, per endpoint, and for everyone.', C['mut'], None)], size=12)
    s.rich(20, 46, [('The limiter keeps a ', C['mut'], None), ('BUDGET', C['yellow'], '700'), (' for each, answers with a ', C['mut'], None),
                    ('DECISION', C['yellow'], '700'), (', and tells a ', C['mut'], None), ('DASHBOARD', C['yellow'], '700'), ('.', C['mut'], None)], size=12)
    rows = [
        ('client', 'String clientId', 'class', 'an id; nothing to remember about it', 'dash'),
        ('plan', 'Plans', 'class', 'which plan each client is on', 'solid'),
        ('request', 'Request', 'record', 'who, which endpoint, what it costs', 'rec'),
        ('endpoint', 'a field of Request', 'class', 'information about a request', 'dash'),
        ('rule', 'Rule, RuleBook', 'record', 'which requests, whose budget, how much', 'rec'),
        ('window', 'Limit', 'record', 'permits per window, always together', 'rec'),
        ('per client / everyone', 'Scope', 'enum', 'turns a request into a key: whose budget', 'rec'),
        ('budget', 'Bucket', 'iface', 'changes on every request: the heart', 'solid'),
        ('decision', 'Decision', 'record', 'allowed, left, retry time, which rule said no', 'rec'),
        ('dashboard', 'DecisionListener', 'iface', 'hears every decision', 'solid'),
    ]
    for i, (noun, becomes, kind, why, style) in enumerate(rows):
        col, row = i % 2, i // 2
        x, y = 20 + col * 470, 72 + row * 50
        s.text(x, y + 22, noun, size=11.5, fill=C['yellow'], weight='600')
        s.line([(x + 150, y + 18), (x + 172, y + 18)], end='arr')
        stroke = {'solid': C['acc'], 'rec': C['teal'], 'dash': C['dim']}[style]
        dash = '4 3' if style == 'dash' or kind == 'iface' else None
        s.rect(x + 176, y + 2, 270, 38, fill=C['sur'], stroke=stroke, dash=dash)
        s.text(x + 186, y + 18, becomes, size=11, weight='600')
        s.text(x + 186, y + 33, why, size=9, fill=C['mut'])
    s.text(20, 325, 'purple: holds changing state, so a class with behaviour · teal: a value (record or enum) · grey dashed: not a class',
           size=9.5, fill=C['dim'])
    return s.render('The nouns, and what each becomes')


def fig_d_axes():
    s = Svg(960, 340)
    s.rect(365, 140, 230, 60, fill=C['sur'], stroke=C['acc'], sw=2)
    s.text(480, 165, 'RateLimiterService', size=13, weight='600', anchor='middle')
    s.text(480, 184, 'the orchestrator: knows none of these', size=9.5, fill=C['mut'], anchor='middle')
    axes = [
        (20, 20, 'WHICH requests, and how many?', 'RuleBook · Rule', 'a new plan, a new endpoint limit'),
        (350, 20, 'WHOSE budget?', 'Scope', 'per IP, per tenant'),
        (680, 20, 'HOW to count?', 'Algorithm → Bucket', 'exact logins: a sliding log'),
        (20, 250, 'WHERE does the count live?', 'BucketStore', 'twelve servers: Redis'),
        (350, 250, 'WHO hears about it?', 'DecisionListener', 'a dashboard, an audit log'),
        (680, 250, 'WHEN is now?', 'Clock', 'a test that never sleeps'),
    ]
    for x, y, q, seam, change in axes:
        s.rect(x, y, 260, 70, fill=C['sur'], stroke=C['blue'], dash='5 3')
        s.text(x + 12, y + 20, q, size=11, fill=C['yellow'], weight='600')
        s.text(x + 12, y + 40, seam, size=11.5, weight='600')
        s.text(x + 12, y + 58, 'changes for: ' + change, size=9.5, fill=C['mut'])
        cx, cy = x + 130, (y + 70 if y < 140 else y)
        tx, ty = (480, 140) if y < 140 else (480, 200)
        s.line([(cx, cy), (cx, (cy + ty) / 2), (tx + (cx - 480) * 0.25, (cy + ty) / 2), (tx + (cx - 480) * 0.25, ty)],
               stroke=C['green'], dash='5 3', end='arr-green', sw=1.2)
    s.text(480, 334, 'Six questions, six seams: each changes for its own reason, so each sits behind its own interface or value.',
           size=10, fill=C['mut'], anchor='middle')
    return s.render('Six things change independently')


def fig_d_all():
    s = Svg(960, 250)
    s.rect(15, 95, 150, 50, fill=C['bg'], stroke=C['mut'], dash='3 3')
    s.text(90, 116, 'globex /search', size=11, anchor='middle', weight='600')
    s.text(90, 132, 'cost 1', size=9.5, fill=C['mut'], anchor='middle')
    steps = [(215, 'pro-client', '48 → 47', C['green'], 'took 1'), (455, 'search', '0 left', C['red'], 'refused'),
             (695, 'global', 'never asked', C['dim'], '')]
    for x, rule, st, col, lab in steps:
        s.rect(x, 90, 200, 60, fill=C['sur'], stroke=col, sw=1.6)
        s.text(x + 100, 113, 'rule: ' + rule, size=11.5, anchor='middle', weight='600')
        s.text(x + 100, 132, st, size=10, fill=col, anchor='middle')
    s.line([(165, 120), (213, 120)], end='arr')
    s.line([(415, 120), (453, 120)], stroke=C['green'], end='arr-green')
    s.text(434, 112, 'took', size=9, fill=C['green'], anchor='middle')
    s.line([(655, 120), (693, 120)], stroke=C['dim'], dash='3 3')
    s.text(674, 112, 'stops', size=9, fill=C['dim'], anchor='middle')
    s.line([(555, 150), (555, 190), (315, 190), (315, 152)], stroke=C['peach'], dash='4 3', end='arr')
    s.text(435, 206, 'refund: pro-client goes back to 48', size=10.5, fill=C['peach'], anchor='middle', weight='600')
    s.text(480, 36, 'All or nothing: rules are checked in order; the first that refuses ends it, and every token already taken',
           size=11, anchor='middle')
    s.text(480, 54, 'goes back. A refused request is charged by no rule, and the global lock is never touched for it.',
           size=11, anchor='middle')
    s.text(480, 240, 'Narrow rules first, global last: a noisy client is stopped early and never touches the lock everyone shares.',
           size=10, fill=C['mut'], anchor='middle')
    return s.render('One request, three rules, all or nothing')


def fig_layers():
    s = Svg(960, 470)
    bands = [
        ('EDGE', 10, [('ApiFilter', 'Decision → 200 or 429', 'class')]),
        ('ORCHESTRATOR', 92, [('RateLimiterService', 'check: every rule or none', 'class'),
                              ('RateLimiter', 'the one call the API knows', 'iface')]),
        ('RULES: which, whose, how much', 174, [('RuleBook', 'rulesFor(request), in order', 'class'), ('Rule', 'which · whose · limit · how', 'record'),
                                               ('Scope', 'request → key', 'enum'), ('Plans', 'client → FREE / PRO', 'class')]),
        ('COUNTING: how', 256, [('Bucket', 'tryTake(cost) · refund(cost)', 'iface'), ('TokenBucket', 'tokens, lastRefill, locked', 'class'),
                                ('Algorithm', 'makes a Bucket', 'iface')]),
        ('STORAGE: where', 338, [('BucketStore', 'bucket(rule, key)', 'iface'), ('LocalBucketStore', 'map + computeIfAbsent', 'class')]),
    ]
    for label, y, boxes in bands:
        s.rect(10, y, 940, 72, fill=C['sur2'], stroke=C['line'], rx=8)
        s.text(22, y + 18, label, size=9.5, fill=C['green'], weight='700')
        for i, (n, sub, kind) in enumerate(boxes):
            x = 200 + i * 188
            box(s, x, y + 14, 178, 46, kind, n, sub, size=11)
    for y1, y2 in ((82, 106), (164, 188), (246, 270), (328, 352)):
        s.line([(289, y1 - 22), (289, y2 - 2)], end='arr')
    s.rect(10, 420, 460, 40, fill=C['sur2'], stroke=C['line'], rx=8)
    s.text(22, 444, 'SIDE: Clock (when is now) · DecisionListener (who hears)', size=10.5, fill=C['txt'])
    s.rect(490, 420, 460, 40, fill=C['sur2'], stroke=C['line'], rx=8)
    s.text(502, 444, 'VALUES: Request · Limit · Decision (records, never change)', size=10.5, fill=C['txt'])
    return s.render('The design in five layers')


# ----------------------------------------------------------------------------- scaling out
def fig_s_problem():
    s = Svg(700, 250)
    def side(x0, title, shared):
        s.text(x0, 20, title, size=11.5, weight='600')
        for i in range(3):
            y = 36 + i * 62
            s.rect(x0, y, 130, 46, fill=C['sur'], stroke=C['line'])
            s.text(x0 + 65, y + 19, f'server {i + 1}', size=10.5, anchor='middle', weight='600')
            s.text(x0 + 65, y + 35, 'own map' if not shared else 'RedisBucketStore', size=9, fill=C['mut'], anchor='middle')
            if shared:
                s.line([(x0 + 130, y + 23), (x0 + 196, 118)], stroke=C['blue'], end='arr-blue', sw=1.2)
            else:
                s.text(x0 + 140, y + 27, 'acme: 100', size=10, fill=C['red'])
        if shared:
            s.rect(x0 + 200, 90, 110, 56, fill=C['sur'], stroke=C['acc'], sw=1.8)
            s.text(x0 + 255, 114, 'Redis', size=11.5, anchor='middle', weight='600')
            s.text(x0 + 255, 131, 'acme: 100', size=10, fill=C['green'], anchor='middle')
        s.text(x0, 238, 'acme gets 300 a minute' if not shared else 'acme gets 100 a minute, on any server',
               size=11, fill=C['red'] if not shared else C['green'], weight='600')
    side(10, 'Before: a map in each server', False)
    side(360, 'After: one store every server shares', True)
    return s.render('Many servers, one budget')


def fig_s_redis():
    s = Svg(700, 300)
    s.rect(10, 20, 200, 60, fill=C['sur'], stroke=C['acc'])
    s.text(110, 44, 'RateLimiterService', size=11.5, anchor='middle', weight='600')
    s.text(110, 62, 'unchanged: rules, all or nothing', size=9.5, fill=C['mut'], anchor='middle')
    s.rect(10, 110, 200, 50, fill=C['sur'], stroke=C['line'])
    s.text(110, 132, 'RedisBucketStore', size=11.5, anchor='middle', weight='600')
    s.text(110, 148, 'bucket(rule, key) → proxy', size=9.5, fill=C['mut'], anchor='middle')
    s.rect(10, 190, 200, 50, fill=C['sur'], stroke=C['line'])
    s.text(110, 212, 'RedisTokenBucket', size=11.5, anchor='middle', weight='600')
    s.text(110, 228, 'tryTake → TAKE · refund → REFUND', size=9.5, fill=C['mut'], anchor='middle')
    s.line([(110, 80), (110, 108)], end='arr')
    s.line([(110, 160), (110, 188)], end='arr')
    s.line([(210, 215), (298, 215)], stroke=C['blue'], end='arr-blue')
    s.text(254, 208, 'EVALSHA', size=9, fill=C['blue'], anchor='middle')
    s.rect(300, 20, 390, 270, fill=C['sur2'], stroke=C['acc'], sw=1.6)
    s.text(495, 42, 'Redis: one script at a time, on its own clock', size=11.5, anchor='middle', weight='600')
    keys = [('rate:{acme}:free-client', 'tokens 4.0 · last 1700…'), ('rate:{acme search}:search', 'same idea'),
            ('rate:{*}:global', 'the one everyone shares')]
    for i, (k, v) in enumerate(keys):
        s.rect(318, 58 + i * 44, 354, 36, fill=C['sur'], stroke=C['line'])
        s.text(328, 75 + i * 44, k, size=10.5, fill=C['yellow'])
        s.text(328, 89 + i * 44, v, size=9, fill=C['mut'])
    for i, t in enumerate(['TAKE: refill from TIME, check, spend, PEXPIRE, in one step',
                           'REFUND: give back, capped at capacity',
                           '{…} is a hash tag: one key per shard slot group',
                           'the global key is one hot key: see leasing']):
        s.text(318, 210 + i * 18, t, size=10, fill=C['txt'] if i < 2 else C['mut'])
    return s.render('The Redis store: same service, buckets that live in Redis')


def fig_s_lease():
    s = Svg(700, 250)
    s.rect(260, 16, 180, 56, fill=C['sur'], stroke=C['acc'], sw=1.8)
    s.text(350, 40, 'Redis: acme 100 a minute', size=11, anchor='middle', weight='600')
    s.text(350, 58, 'handed out in batches of 10', size=9.5, fill=C['mut'], anchor='middle')
    for i, (held, note) in enumerate([(7, 'spends locally, no round trip'), (10, 'just leased 10'), (2, 'asks for 10 more at 0')]):
        x = 20 + i * 230
        s.rect(x, 130, 200, 74, fill=C['sur'], stroke=C['line'])
        s.text(x + 100, 152, f'server {i + 1}: LeasedBucket', size=11, anchor='middle', weight='600')
        s.text(x + 100, 172, f'holds {held} tokens', size=10.5, fill=C['green'], anchor='middle')
        s.text(x + 100, 190, note, size=9.5, fill=C['mut'], anchor='middle')
        s.line([(350, 72), (x + 100, 128)], stroke=C['blue'], sw=1.2, end='arr-blue')
    s.text(20, 228, 'Never over the limit: tokens are taken from Redis before they are spent. The cost: a server may hold', size=10, fill=C['txt'])
    s.text(20, 244, 'unused tokens while another refuses, so a client can be refused slightly early. 300 requests: 16 calls.', size=10, fill=C['txt'])
    return s.render('Leasing: fewer round trips, a cooler hot key')


def fig_s_breaker():
    s = Svg(700, 190)
    states = [(20, 'CLOSED', 'every call goes to Redis', C['green']), (260, 'OPEN', 'skip Redis; answer by policy', C['red']),
              (500, 'TRY AGAIN', 'after 5 s, one call through', C['yellow'])]
    for x, name, sub, col in states:
        s.rect(x, 50, 180, 60, fill=C['sur'], stroke=col, sw=1.8)
        s.text(x + 90, 75, name, size=12, anchor='middle', weight='700', fill=col)
        s.text(x + 90, 95, sub, size=9.5, fill=C['mut'], anchor='middle')
    s.line([(200, 80), (258, 80)], end='arr')
    s.text(229, 72, '3 failures', size=9, fill=C['mut'], anchor='middle')
    s.line([(440, 80), (498, 80)], end='arr')
    s.text(469, 72, 'cooldown', size=9, fill=C['mut'], anchor='middle')
    s.line([(590, 110), (590, 140), (110, 140), (110, 112)], stroke=C['green'], dash='4 3', end='arr-green')
    s.text(350, 155, 'it answers: back to CLOSED · it fails: back to OPEN', size=10, fill=C['mut'], anchor='middle')
    s.text(20, 30, 'Policy per rule: fail open (allow) for a public API, fail closed (refuse) for logins.', size=10.5, fill=C['txt'])
    s.text(20, 182, 'Why: a Redis that times out after 50 ms would add 50 ms to every request; the breaker makes that 0.', size=10, fill=C['txt'])
    return s.render('Redis down: the breaker, and the policy per rule')
