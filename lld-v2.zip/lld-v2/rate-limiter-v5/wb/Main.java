import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;

// One request, as the limiter sees it: who sent it, to which endpoint, and what it costs.
record Request(String clientId, String endpoint, int cost) {
    Request {
        if (cost <= 0) throw new IllegalArgumentException("cost must be > 0");
    }
    static Request of(String clientId, String endpoint) { return new Request(clientId, endpoint, 1); }
}

// A limit: at most `permits` per window. 100 a minute is Limit.perMinute(100).
record Limit(int permits, long windowMillis) {
    Limit {
        if (permits <= 0 || windowMillis <= 0) throw new IllegalArgumentException("must be > 0");
    }
    static Limit perSecond(int n) { return new Limit(n, 1_000); }
    static Limit perMinute(int n) { return new Limit(n, 60_000); }
}

// The answer. Allowed: how much is left. Refused: when to retry, and which rule said no.
record Decision(boolean allowed, long remaining, long retryAfterMillis, String ruleId) {
    static final long NEVER = -1;             // costs more than the limit: it can never pass
    static Decision allow(long remaining) { return new Decision(true, remaining, 0, ""); }
    static Decision deny(long waitMillis) { return new Decision(false, 0, waitMillis, ""); }
    Decision by(String ruleId)            { return new Decision(allowed, remaining, retryAfterMillis, ruleId); }

    @Override public String toString() {
        if (allowed) return remaining == Long.MAX_VALUE ? "allowed" : "allowed, " + remaining + " left";
        return "refused by " + ruleId + (retryAfterMillis == NEVER ? ", can never fit" : ", retry in " + retryAfterMillis + " ms");
    }
}

enum Plan { FREE, PRO }

// Which plan each client is on. A client nobody has set up is on FREE.
class Plans {
    private final Map<String, Plan> byClient = new ConcurrentHashMap<>();
    Plan of(String clientId)             { return byClient.getOrDefault(clientId, Plan.FREE); }
    void set(String clientId, Plan plan) { byClient.put(clientId, plan); }
}

// Whose budget a rule counts against. Each scope turns a request into a key.
enum Scope {
    CLIENT          { String key(Request r) { return r.clientId(); } },
    CLIENT_ENDPOINT { String key(Request r) { return r.clientId() + " " + r.endpoint(); } },
    GLOBAL          { String key(Request r) { return "*"; } };

    abstract String key(Request r);
}

// Where "now" comes from. Handed in, so a test moves time by hand instead of sleeping.
interface Clock {
    long millis();
}

class SystemClock implements Clock {
    public long millis() { return System.nanoTime() / 1_000_000; }   // never jumps back
}

class ManualClock implements Clock {
    private volatile long now;
    ManualClock(long startMillis) { now = startMillis; }
    public long millis()          { return now; }
    void advance(long ms)         { now += ms; }      // only the test's own thread calls this
}

// One key's budget. Each algorithm is a class that implements it.
interface Bucket {
    Decision tryTake(int cost, long nowMillis);    // take `cost` now, or say how long until it fits
    void refund(int cost, long nowMillis);         // give back what tryTake took
    //@ from e5
    boolean isIdle(long nowMillis);                // true when forgetting it loses nothing
    //@ end
}

// How a rule counts: an algorithm makes the Bucket that counts for one key. TokenBucket::new is one.
interface Algorithm {
    Bucket newBucket(Limit limit, long nowMillis);
}

// Holds up to `capacity` tokens and earns `capacity` back per window, a little every millisecond.
class TokenBucket implements Bucket {
    private final int capacity;
    private final long windowMillis;
    private double tokens;              // tokens left
    private long lastRefillMillis;      // when `tokens` was last brought up to date

    TokenBucket(Limit limit, long nowMillis) {
        this.capacity = limit.permits();
        this.windowMillis = limit.windowMillis();
        this.tokens = capacity;         // a new key starts with a full bucket
        this.lastRefillMillis = nowMillis;
    }

    @Override
    public synchronized Decision tryTake(int cost, long nowMillis) {
        if (cost > capacity) return Decision.deny(Decision.NEVER);   // waiting would never help
        refill(nowMillis);
        if (tokens >= cost) {
            tokens -= cost;
            return Decision.allow((long) tokens);
        }
        return Decision.deny((long) Math.ceil((cost - tokens) * windowMillis / capacity));
    }

    @Override
    public synchronized void refund(int cost, long nowMillis) {
        tokens = Math.min(capacity, tokens + cost);   // never above a full bucket
    }

    private void refill(long nowMillis) {
        long elapsed = nowMillis - lastRefillMillis;
        if (elapsed <= 0) return;       // same millisecond, or an older reading: earn nothing
        tokens = Math.min(capacity, tokens + (double) elapsed * capacity / windowMillis);
        lastRefillMillis = nowMillis;
    }
    //@ from e5

    @Override
    public synchronized boolean isIdle(long nowMillis) {
        return nowMillis - lastRefillMillis >= windowMillis;   // unused for a window: full again
    }
    //@ end
}
//@ from e1

// Exact: never more than `limit` in ANY stretch of one window. Keeps a timestamp per unit taken.
class SlidingWindowLog implements Bucket {
    private final int limit;
    private final long windowMillis;
    private final ArrayDeque<Long> times = new ArrayDeque<>();   // oldest first

    SlidingWindowLog(Limit limit, long nowMillis) {
        this.limit = limit.permits();
        this.windowMillis = limit.windowMillis();
    }

    @Override
    public synchronized Decision tryTake(int cost, long nowMillis) {
        if (cost > limit) return Decision.deny(Decision.NEVER);
        while (!times.isEmpty() && times.peekFirst() <= nowMillis - windowMillis) {
            times.pollFirst();                                   // forget what left the window
        }
        if (times.size() + cost <= limit) {
            for (int i = 0; i < cost; i++) times.addLast(nowMillis);
            return Decision.allow(limit - times.size());
        }
        // a place for `cost` opens when enough of the oldest entries have left the window
        long oldestThatMustLeave = times.stream().skip(times.size() + cost - limit - 1).findFirst().orElse(nowMillis);
        return Decision.deny(oldestThatMustLeave + windowMillis - nowMillis);
    }

    @Override
    public synchronized void refund(int cost, long nowMillis) {
        for (int i = 0; i < cost && !times.isEmpty(); i++) times.pollLast();
    }
    //@ from e5

    @Override
    public synchronized boolean isIdle(long nowMillis) {
        return times.isEmpty() || times.peekLast() <= nowMillis - windowMillis;
    }
    //@ end
}
//@ end

// A rule: which requests it covers, whose budget it counts, how much, and how it counts.
record Rule(String id, Predicate<Request> appliesTo, Scope scope, Limit limit, Algorithm algorithm) { }

// All the rules, in the order they are checked: the narrowest first, the global cap last.
class RuleBook {
    private final List<Rule> rules;
    RuleBook(List<Rule> rules)     { this.rules = List.copyOf(rules); }
    List<Rule> rulesFor(Request r) { return rules.stream().filter(x -> x.appliesTo().test(r)).toList(); }
}

// Where each key's bucket lives: in this process here, in Redis when there are many servers.
interface BucketStore {
    Bucket bucket(Rule rule, String key, long nowMillis);
}

class LocalBucketStore implements BucketStore {
    private final ConcurrentHashMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        // one bucket per rule and key, made once, even when two threads meet a new key together
        //@ from core until e2
        return buckets.computeIfAbsent(rule.id() + "|" + key,
                k -> rule.algorithm().newBucket(rule.limit(), nowMillis));
        //@ end
        //@ from e2
        return buckets.computeIfAbsent(rule.id() + "|" + rule.limit() + "|" + key,   // new limit, new bucket
                k -> rule.algorithm().newBucket(rule.limit(), nowMillis));
        //@ end
    }
    //@ from e5

    // Forgets buckets idle for a whole window. Runs on a timer, never on the request path.
    int evictIdle(long nowMillis) {
        int removed = 0;
        for (Map.Entry<String, Bucket> e : buckets.entrySet()) {
            // remove(key, value) removes only if the map still holds this same bucket
            if (e.getValue().isIdle(nowMillis) && buckets.remove(e.getKey(), e.getValue())) removed++;
        }
        return removed;
    }

    int size() { return buckets.size(); }
    //@ end
}

// What the API calls before any work is done for a request.
interface RateLimiter {
    Decision check(Request request);
}

// Anyone who wants to hear about decisions: metrics, an audit log. Told after the decision.
interface DecisionListener {
    void onDecision(Request request, Decision decision);
}

// A listener that counts refusals per rule, for a dashboard.
class RefusalCounter implements DecisionListener {
    private final ConcurrentHashMap<String, LongAdder> byRule = new ConcurrentHashMap<>();

    @Override
    public void onDecision(Request request, Decision d) {
        if (!d.allowed()) byRule.computeIfAbsent(d.ruleId(), k -> new LongAdder()).increment();
    }

    long refusedBy(String ruleId) {
        LongAdder n = byRule.get(ruleId);
        return n == null ? 0 : n.sum();
    }
}

// The orchestrator. Every rule that applies must allow the request, or no rule is charged.
class RateLimiterService implements RateLimiter {
    //@ from core until e2
    private final RuleBook rules;
    //@ end
    //@ from e2
    private volatile RuleBook rules;          // swapped whole when ops change a rule
    //@ end
    private final BucketStore store;
    private final Clock clock;
    private final List<DecisionListener> listeners = new CopyOnWriteArrayList<>();

    RateLimiterService(RuleBook rules, BucketStore store, Clock clock) {
        this.rules = rules;
        this.store = store;
        this.clock = clock;
    }

    void addListener(DecisionListener listener) { listeners.add(listener); }
    //@ from e2

    void replaceRules(RuleBook newRules) { rules = newRules; }    // the next request sees the new book
    //@ end

    @Override
    public Decision check(Request request) {
        long now = clock.millis();
        Decision result = Decision.allow(Long.MAX_VALUE);
        List<Bucket> charged = new ArrayList<>();
        for (Rule rule : rules.rulesFor(request)) {
            Bucket bucket = store.bucket(rule, rule.scope().key(request), now);
            Decision d = bucket.tryTake(request.cost(), now);
            if (!d.allowed()) {
                for (Bucket b : charged) b.refund(request.cost(), now);   // all or nothing
                result = d.by(rule.id());
                break;
            }
            charged.add(bucket);
            result = Decision.allow(Math.min(result.remaining(), d.remaining()));
        }
        for (DecisionListener l : listeners) {
            try { l.onDecision(request, result); }
            catch (RuntimeException e) { /* a broken listener must never break the limiter */ }
        }
        return result;
    }
}

// What the HTTP client gets back.
record Response(int status, Map<String, String> headers) { }

// The edge: turns a Decision into an HTTP status and the standard rate-limit headers.
class ApiFilter {
    private final RateLimiter limiter;
    ApiFilter(RateLimiter limiter) { this.limiter = limiter; }

    Response handle(Request request) {
        Decision d = limiter.check(request);
        Map<String, String> h = new TreeMap<>();
        if (d.allowed()) {
            if (d.remaining() != Long.MAX_VALUE) h.put("X-RateLimit-Remaining", String.valueOf(d.remaining()));
            return new Response(200, h);
        }
        h.put("X-RateLimit-Rule", d.ruleId());
        if (d.retryAfterMillis() != Decision.NEVER) {
            h.put("Retry-After", String.valueOf((d.retryAfterMillis() + 999) / 1000));   // whole seconds, up
        }
        return new Response(429, h);
    }
}
//@ from e3

// For callers that would rather wait than be refused, such as a nightly batch job.
final class Waiting {
    // Waits up to maxWaitMillis for the request to pass. False at once if the wait would be longer.
    static boolean acquire(RateLimiter limiter, Request request, long maxWaitMillis) throws InterruptedException {
        long deadline = System.nanoTime() + maxWaitMillis * 1_000_000;
        while (true) {
            Decision d = limiter.check(request);
            if (d.allowed()) return true;
            long leftMillis = (deadline - System.nanoTime()) / 1_000_000;
            if (d.retryAfterMillis() == Decision.NEVER || d.retryAfterMillis() > leftMillis) return false;
            Thread.sleep(d.retryAfterMillis());
        }
    }
}
//@ end
//@ from e4

// Decorator: enforces the live rules, and also asks a candidate limiter with new rules, counting
// what it would have refused. Try a stricter rule on real traffic without refusing anyone.
class ShadowLimiter implements RateLimiter {
    private final RateLimiter live;
    private final RateLimiter candidate;
    private final LongAdder wouldRefuse = new LongAdder();

    ShadowLimiter(RateLimiter live, RateLimiter candidate) {
        this.live = live;
        this.candidate = candidate;
    }

    @Override
    public Decision check(Request request) {
        Decision d = live.check(request);
        if (d.allowed() && !candidate.check(request).allowed()) wouldRefuse.increment();   // and log it
        return d;
    }

    long wouldHaveRefused() { return wouldRefuse.sum(); }
}
//@ end
//@ from s1

// The one call this needs from a Redis client library such as Jedis or Lettuce.
interface Redis {
    List<Long> eval(String script, List<String> keys, List<String> args);
}

// A proxy: it looks like a Bucket, but the numbers live in Redis, and each call runs one script
// there. Redis runs one script at a time, so the script is the fleet's `synchronized`.
class RedisTokenBucket implements Bucket {
    static final String TAKE = """
        local capacity, window, cost = tonumber(ARGV[1]), tonumber(ARGV[2]), tonumber(ARGV[3])
        local t = redis.call('TIME')                   -- Redis's clock: every server agrees
        local now = t[1] * 1000 + math.floor(t[2] / 1000)
        local b = redis.call('HMGET', KEYS[1], 'tokens', 'last')
        local tokens = tonumber(b[1]) or capacity       -- a new key starts full
        local last = tonumber(b[2]) or now
        if now > last then
          tokens = math.min(capacity, tokens + (now - last) * capacity / window)
          last = now
        end
        local allowed, wait = 0, 0
        if tokens >= cost then
          tokens, allowed = tokens - cost, 1
        else
          wait = math.ceil((cost - tokens) * window / capacity)
        end
        redis.call('HSET', KEYS[1], 'tokens', tostring(tokens), 'last', last)
        redis.call('PEXPIRE', KEYS[1], window)         -- unused for a window: Redis forgets it
        return {allowed, math.floor(tokens), wait}
        """;
    static final String REFUND = """
        local capacity, cost = tonumber(ARGV[1]), tonumber(ARGV[2])
        local tokens = tonumber(redis.call('HGET', KEYS[1], 'tokens'))
        if tokens then redis.call('HSET', KEYS[1], 'tokens', tostring(math.min(capacity, tokens + cost))) end
        return {1}
        """;

    private final Redis redis;
    private final String key;
    private final Limit limit;

    RedisTokenBucket(Redis redis, String key, Limit limit) {
        this.redis = redis;
        this.key = key;
        this.limit = limit;
    }

    @Override
    public Decision tryTake(int cost, long nowMillis) {             // Redis's clock is used, not nowMillis
        if (cost > limit.permits()) return Decision.deny(Decision.NEVER);
        List<Long> r = redis.eval(TAKE, List.of(key),
                List.of(String.valueOf(limit.permits()), String.valueOf(limit.windowMillis()), String.valueOf(cost)));
        return r.get(0) == 1 ? Decision.allow(r.get(1)) : Decision.deny(r.get(2));
    }

    @Override
    public void refund(int cost, long nowMillis) {
        redis.eval(REFUND, List.of(key), List.of(String.valueOf(limit.permits()), String.valueOf(cost)));
    }

    @Override
    public boolean isIdle(long nowMillis) { return false; }         // Redis expires idle keys itself
}
//@ end
//@ from s2

// Opens after `threshold` failures in a row, and stays open for `cooldownMillis`: while open,
// nobody waits on a Redis that keeps failing.
class Breaker {
    private final int threshold;
    private final long cooldownMillis;
    private int failures;
    private long openUntil;

    Breaker(int threshold, long cooldownMillis) {
        this.threshold = threshold;
        this.cooldownMillis = cooldownMillis;
    }

    synchronized boolean isOpen(long nowMillis) { return nowMillis < openUntil; }
    synchronized void success()                  { failures = 0; }
    synchronized void failure(long nowMillis) {
        if (++failures >= threshold) {
            openUntil = nowMillis + cooldownMillis;
            failures = 0;
        }
    }
}

// Decorator: when Redis fails or the breaker is open, answer from the rule's policy instead of
// failing the request. Fail open for a public API; fail closed for logins.
class FallbackBucket implements Bucket {
    private final Bucket remote;
    private final boolean failOpen;
    private final Breaker breaker;

    FallbackBucket(Bucket remote, boolean failOpen, Breaker breaker) {
        this.remote = remote;
        this.failOpen = failOpen;
        this.breaker = breaker;
    }

    @Override
    public Decision tryTake(int cost, long nowMillis) {
        if (breaker.isOpen(nowMillis)) return fallback();
        try {
            Decision d = remote.tryTake(cost, nowMillis);
            breaker.success();
            return d;
        } catch (RuntimeException redisDown) {
            breaker.failure(nowMillis);
            return fallback();
        }
    }

    private Decision fallback() { return failOpen ? Decision.allow(Long.MAX_VALUE) : Decision.deny(1_000); }

    @Override
    public void refund(int cost, long nowMillis) {
        try { remote.refund(cost, nowMillis); } catch (RuntimeException ignored) { /* expires anyway */ }
    }

    @Override
    public boolean isIdle(long nowMillis) { return false; }
}
//@ end
//@ from s1

// Every server builds buckets the same way, so they all share one budget per rule and key.
class RedisBucketStore implements BucketStore {
    private final Redis redis;
    //@ from s2
    private final Set<String> failClosedRules;
    private final Breaker breaker = new Breaker(3, 5_000);
    //@ end

    //@ from s1 until s2
    RedisBucketStore(Redis redis) { this.redis = redis; }
    //@ end
    //@ from s2
    RedisBucketStore(Redis redis, Set<String> failClosedRules) {
        this.redis = redis;
        this.failClosedRules = failClosedRules;
    }
    //@ end

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        // {key} is a hash tag: all of one client's keys land on the same Redis Cluster slot
        String redisKey = "rate:{" + key + "}:" + rule.id();
        //@ from s1 until s2
        return new RedisTokenBucket(redis, redisKey, rule.limit());
        //@ end
        //@ from s2
        Bucket remote = new RedisTokenBucket(redis, redisKey, rule.limit());
        return new FallbackBucket(remote, !failClosedRules.contains(rule.id()), breaker);
        //@ end
    }
}
//@ end
//@ from s3

// Round trips and hot keys: each server takes tokens from Redis in batches and spends them
// locally. Never over the limit, since tokens are taken before they are spent.
class LeasedBucket implements Bucket {
    private final Bucket remote;
    private final int batch;
    private int leased;                 // tokens this server holds and may spend without asking
    private long quietUntil;            // Redis said "not before this": don't ask again until then

    LeasedBucket(Bucket remote, int batch) {
        this.remote = remote;
        this.batch = batch;
    }

    @Override
    public synchronized Decision tryTake(int cost, long nowMillis) {
        if (leased < cost) {
            if (nowMillis < quietUntil) return Decision.deny(quietUntil - nowMillis);
            int need = Math.max(batch, cost - leased);
            Decision d = remote.tryTake(need, nowMillis);
            if (d.allowed()) {
                leased += need;
            } else {
                d = remote.tryTake(cost - leased, nowMillis);       // no whole batch left: take what is missing
                if (!d.allowed()) {
                    quietUntil = nowMillis + Math.max(1, d.retryAfterMillis());
                    return d;
                }
                leased = cost;
            }
        }
        leased -= cost;
        return Decision.allow(leased);
    }

    @Override
    public synchronized void refund(int cost, long nowMillis) { leased += cost; }

    @Override
    public boolean isIdle(long nowMillis) { return false; }
}

// Decorator over any store: one LeasedBucket per rule and key on this server.
class LeasingStore implements BucketStore {
    private final BucketStore remote;
    private final int batch;
    private final ConcurrentHashMap<String, Bucket> local = new ConcurrentHashMap<>();

    LeasingStore(BucketStore remote, int batch) {
        this.remote = remote;
        this.batch = batch;
    }

    @Override
    public Bucket bucket(Rule rule, String key, long nowMillis) {
        return local.computeIfAbsent(rule.id() + "|" + key,
                k -> new LeasedBucket(remote.bucket(rule, key, nowMillis), batch));
    }
}
//@ end
//@ from extra name=cas

// Lock-free: both numbers live in one immutable State, swapped with compareAndSet. A thread that
// loses the swap reads the new State and tries again; nobody waits on a lock.
class CasTokenBucket implements Bucket {
    private record State(double tokens, long lastRefillMillis) { }
    private final int capacity;
    private final long windowMillis;
    private final AtomicReference<State> state;

    CasTokenBucket(Limit limit, long nowMillis) {
        this.capacity = limit.permits();
        this.windowMillis = limit.windowMillis();
        this.state = new AtomicReference<>(new State(capacity, nowMillis));
    }

    @Override
    public Decision tryTake(int cost, long nowMillis) {
        if (cost > capacity) return Decision.deny(Decision.NEVER);
        while (true) {
            State s = state.get();
            long elapsed = Math.max(0, nowMillis - s.lastRefillMillis());
            double tokens = Math.min(capacity, s.tokens() + (double) elapsed * capacity / windowMillis);
            if (tokens < cost) return Decision.deny((long) Math.ceil((cost - tokens) * windowMillis / capacity));
            State next = new State(tokens - cost, Math.max(nowMillis, s.lastRefillMillis()));
            if (state.compareAndSet(s, next)) return Decision.allow((long) next.tokens());   // lost: loop
        }
    }

    @Override
    public void refund(int cost, long nowMillis) {
        state.updateAndGet(s -> new State(Math.min(capacity, s.tokens() + cost), s.lastRefillMillis()));
    }

    @Override
    public boolean isIdle(long nowMillis) { return nowMillis - state.get().lastRefillMillis() >= windowMillis; }
}
//@ end
//@ from extra name=hits

// LeetCode 362: hits in the last 300 seconds. One slot per second, reused every 300 seconds.
class HitCounter {
    private final int[] second = new int[300];
    private final int[] count = new int[300];

    synchronized void hit(int now) {
        int i = now % 300;
        if (second[i] != now) {         // the slot still holds an old second: reuse it
            second[i] = now;
            count[i] = 0;
        }
        count[i]++;
    }

    synchronized int getHits(int now) {
        int total = 0;
        for (int i = 0; i < 300; i++) if (now - second[i] < 300) total += count[i];
        return total;
    }
}
//@ end

public class Main {
    public static void main(String[] args) throws Exception {
        ManualClock clock = new ManualClock(0);
        Plans plans = new Plans();
        plans.set("globex", Plan.PRO);                                  // acme stays on FREE
        RuleBook rules = new RuleBook(List.of(
                new Rule("free-client", r -> plans.of(r.clientId()) == Plan.FREE, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new),
                new Rule("pro-client", r -> plans.of(r.clientId()) == Plan.PRO, Scope.CLIENT, Limit.perSecond(50), TokenBucket::new),
                new Rule("search", r -> r.endpoint().equals("/search"), Scope.CLIENT_ENDPOINT, Limit.perSecond(2), TokenBucket::new),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perSecond(60), TokenBucket::new)));
        RateLimiterService limiter = new RateLimiterService(rules, new LocalBucketStore(), clock);
        RefusalCounter refusals = new RefusalCounter();
        limiter.addListener(refusals);
        ApiFilter api = new ApiFilter(limiter);

        // acme, on FREE (5 a second), sends 7 at once: 5 pass, then its client rule says no
        for (int i = 1; i <= 7; i++) {
            System.out.println("t=0     acme   /items   #" + i + "  " + limiter.check(Request.of("acme", "/items")));
        }
        // globex, on PRO, searches 3 times: the search rule stops the 3rd, and the token the
        // pro-client rule took for it goes back, so its next request shows 47 left, not 46
        for (int i = 1; i <= 3; i++) {
            System.out.println("t=0     globex /search  #" + i + "  " + limiter.check(Request.of("globex", "/search")));
        }
        Decision next = limiter.check(Request.of("globex", "/items"));
        System.out.println("t=0     globex /items       " + next);
        check(next.remaining() == 47, "a refused request is charged by no rule");

        // at the edge, a refusal becomes 429 with Retry-After in whole seconds
        System.out.println("t=0     HTTP   acme /items  " + api.handle(Request.of("acme", "/items")));

        // a second later: a request costing 3 fits; one costing 6 can never fit a limit of 5
        clock.advance(1_000);
        System.out.println("t=1000  acme   cost 3       " + limiter.check(new Request("acme", "/export", 3)));
        System.out.println("t=1000  acme   cost 6       " + limiter.check(new Request("acme", "/export", 6)));
        System.out.println("refusals by rule: free-client " + refusals.refusedBy("free-client")
                + ", search " + refusals.refusedBy("search") + ", global " + refusals.refusedBy("global"));

        race(TokenBucket::new);
        //@ from e1 proof
        e1ExactLogins();
        //@ end
        //@ from e2 proof
        e2ChangeRule();
        //@ end
        //@ from e3 proof
        e3Waiting();
        //@ end
        //@ from e4 proof
        e4Shadow();
        //@ end
        //@ from e5 proof
        e5EvictIdle();
        //@ end
        //@ from s1 proof
        s1ManyServers();
        //@ end
        //@ from s2 proof
        s2RedisDown();
        //@ end
        //@ from s3 proof
        s3Leasing();
        //@ end
        //@ from extra proof
        extraAnswers();
        //@ end
    }

    // 100 threads, 100 clients, 1,000 requests per thread, on a frozen clock. Each client may pass
    // 500 a day, but the global cap is 30,000: exactly 30,000 pass, and none charges a refused one.
    static void race(Algorithm algorithm) throws Exception {
        ManualClock clock = new ManualClock(0);
        RateLimiterService limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("client", r -> true, Scope.CLIENT, new Limit(500, 86_400_000), algorithm),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perMinute(30_000), algorithm))),
                new LocalBucketStore(), clock);
        AtomicInteger passed = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(100);
        CountDownLatch go = new CountDownLatch(1);
        List<Future<?>> threads = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            threads.add(pool.submit(() -> {
                go.await();                                          // all 100 start together
                for (int i = 0; i < 1_000; i++) {
                    if (limiter.check(Request.of("client-" + i % 100, "/items")).allowed()) passed.incrementAndGet();
                }
                return null;
            }));
        }
        go.countDown();
        for (Future<?> f : threads) f.get();
        pool.shutdown();
        System.out.println("race    100 threads, 100,000 requests: " + passed.get() + " allowed");
        check(passed.get() == 30_000, "never more than any rule allows, whatever the thread count");

        // a minute later the global cap is full again; each client can spend exactly what it
        // did not use, so the refused requests must all have been refunded: 100 x 500 - 30,000
        clock.advance(60_000);
        int more = 0;
        for (int c = 0; c < 100; c++) {
            for (int i = 0; i < 600; i++) if (limiter.check(Request.of("client-" + c, "/items")).allowed()) more++;
        }
        System.out.println("after   a minute, each client's unused budget: " + more + " allowed");
        check(more == 20_000, "a refused request is charged by no rule");
    }
    //@ from e1 proof

    static void e1ExactLogins() {
        for (String name : List.of("TokenBucket", "SlidingWindowLog")) {
            ManualClock clock = new ManualClock(0);
            //@ from e1 design
            Algorithm algorithm = name.equals("TokenBucket") ? TokenBucket::new : SlidingWindowLog::new;
            Rule login = new Rule("login", r -> r.endpoint().equals("/login"), Scope.CLIENT_ENDPOINT, Limit.perMinute(5), algorithm);
            //@ end
            RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(login)), new LocalBucketStore(), clock);
            int passed = 0;
            for (int i = 0; i < 5; i++) if (limiter.check(Request.of("asha", "/login")).allowed()) passed++;
            for (int s = 1; s < 60; s++) {
                clock.advance(1_000);
                if (limiter.check(Request.of("asha", "/login")).allowed()) passed++;
            }
            System.out.println("e1  " + name + ": " + passed + " logins passed in the first minute");
            check(passed == (name.equals("TokenBucket") ? 9 : 5), "e1 " + name);
        }
    }
    //@ end
    //@ from e2 proof

    static void e2ChangeRule() {
        ManualClock clock = new ManualClock(0);
        Rule free5 = new Rule("free-client", r -> true, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new);
        RateLimiterService limiter = new RateLimiterService(new RuleBook(List.of(free5)), new LocalBucketStore(), clock);
        for (int i = 0; i < 5; i++) limiter.check(Request.of("acme", "/items"));
        System.out.println("e2  before the change: " + limiter.check(Request.of("acme", "/items")));
        //@ from e2 design
        Rule free10 = new Rule("free-client", r -> true, Scope.CLIENT, Limit.perSecond(10), TokenBucket::new);
        limiter.replaceRules(new RuleBook(List.of(free10)));     // ops raise FREE to 10 a second
        //@ end
        int passed = 0;
        for (int i = 0; i < 12; i++) if (limiter.check(Request.of("acme", "/items")).allowed()) passed++;
        System.out.println("e2  after the change:  " + passed + " of 12 at once");
        check(passed == 10, "e2 a new limit takes effect on the next request");
    }
    //@ end
    //@ from e3 proof

    static void e3Waiting() throws InterruptedException {
        RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("batch", r -> true, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new))),
                new LocalBucketStore(), new SystemClock());
        long start = System.nanoTime();
        List<Long> at = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            check(Waiting.acquire(limiter, Request.of("batch-job", "/items"), 1_000), "e3 acquire within 1 s");
            at.add(Math.round((System.nanoTime() - start) / 1e6 / 100.0) * 100);
        }
        System.out.println("e3  8 requests, passed at about (ms): " + at);
        boolean quick = Waiting.acquire(limiter, Request.of("batch-job", "/items"), 50);
        System.out.println("e3  the next one, with only 50 ms to wait: " + quick);
        check(!quick && at.get(7) >= 500, "e3 waits its turn, and gives up early");
    }
    //@ end
    //@ from e4 proof

    static void e4Shadow() {
        ManualClock clock = new ManualClock(0);
        RateLimiter live = new RateLimiterService(new RuleBook(List.of(
                new Rule("free-client", r -> true, Scope.CLIENT, Limit.perSecond(5), TokenBucket::new))),
                new LocalBucketStore(), clock);
        RateLimiter stricter = new RateLimiterService(new RuleBook(List.of(
                new Rule("free-client", r -> true, Scope.CLIENT, Limit.perSecond(3), TokenBucket::new))),
                new LocalBucketStore(), clock);
        //@ from e4 design
        ShadowLimiter shadow = new ShadowLimiter(live, stricter);   // the API is handed this instead
        //@ end
        int passed = 0;
        for (int i = 0; i < 5; i++) if (shadow.check(Request.of("acme", "/items")).allowed()) passed++;
        System.out.println("e4  live let " + passed + " of 5 through; the stricter rule would have refused "
                + shadow.wouldHaveRefused());
        check(passed == 5 && shadow.wouldHaveRefused() == 2, "e4 shadow mode");
    }
    //@ end
    //@ from e5 proof

    static void e5EvictIdle() {
        ManualClock clock = new ManualClock(0);
        LocalBucketStore store = new LocalBucketStore();
        RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("client", r -> true, Scope.CLIENT, Limit.perMinute(100), TokenBucket::new))), store, clock);
        for (int i = 0; i < 100_000; i++) limiter.check(Request.of("key-" + i, "/items"));
        clock.advance(30_000);
        limiter.check(Request.of("key-7", "/items"));                   // one client stays busy
        int early = store.evictIdle(clock.millis());
        clock.advance(30_000);
        int late = store.evictIdle(clock.millis());
        System.out.println("e5  100,000 clients: evicted " + early + " at 30 s, " + late + " at 60 s, " + store.size() + " left");
        check(early == 0 && late == 99_999 && store.size() == 1, "e5 eviction");
    }
    //@ end
    //@ from s1 proof

    // No Redis on this machine: a stand-in runs the same arithmetic as the Lua scripts, one call at
    // a time as Redis does, on its own clock (Redis's TIME). It checks the Java side; the Lua was
    // run separately under Lua 5.1, the version inside Redis.
    static final class RedisStandIn implements Redis {
        final Map<String, double[]> hashes = new HashMap<>();           // key -> {tokens, last}
        final ManualClock time = new ManualClock(0);
        final AtomicInteger calls = new AtomicInteger();
        volatile boolean down;

        @Override
        public synchronized List<Long> eval(String script, List<String> keys, List<String> args) {
            calls.incrementAndGet();
            if (down) throw new IllegalStateException("redis timeout");
            double capacity = Double.parseDouble(args.get(0));
            if (script.equals(RedisTokenBucket.REFUND)) {
                double[] h = hashes.get(keys.get(0));
                if (h != null) h[0] = Math.min(capacity, h[0] + Double.parseDouble(args.get(1)));
                return List.of(1L);
            }
            double window = Double.parseDouble(args.get(1)), cost = Double.parseDouble(args.get(2));
            long now = time.millis();
            double[] h = hashes.computeIfAbsent(keys.get(0), k -> new double[] {capacity, now});
            if (now > h[1]) {
                h[0] = Math.min(capacity, h[0] + (now - h[1]) * capacity / window);
                h[1] = now;
            }
            if (h[0] >= cost) {
                h[0] -= cost;
                return List.of(1L, (long) Math.floor(h[0]), 0L);
            }
            return List.of(0L, (long) Math.floor(h[0]), (long) Math.ceil((cost - h[0]) * window / capacity));
        }
    }

    static List<RateLimiter> servers(int n, Function<Integer, BucketStore> store, List<Rule> rules) {
        List<RateLimiter> out = new ArrayList<>();
        for (int i = 0; i < n; i++) out.add(new RateLimiterService(new RuleBook(rules), store.apply(i), new ManualClock(0)));
        return out;
    }

    static void s1ManyServers() {
        RedisStandIn redis = new RedisStandIn();
        List<Rule> rules = List.of(
                new Rule("client", r -> true, Scope.CLIENT, Limit.perMinute(100), TokenBucket::new),
                new Rule("global", r -> true, Scope.GLOBAL, Limit.perMinute(150), TokenBucket::new));
        //@ from s1 until s2 design
        List<RateLimiter> three = servers(3, i -> new RedisBucketStore(redis), rules);
        //@ end
        //@ from s2 design
        List<RateLimiter> three = servers(3, i -> new RedisBucketStore(redis, Set.of()), rules);
        //@ end
        int acme = 0, globex = 0;
        for (int i = 0; i < 400; i++) {
            String client = i % 2 == 0 ? "acme" : "globex";
            boolean ok = three.get(i % 3).check(Request.of(client, "/items")).allowed();
            if (ok && client.equals("acme")) acme++;
            if (ok && client.equals("globex")) globex++;
        }
        System.out.println("s1  3 servers, 400 requests: acme " + acme + ", globex " + globex + ", together " + (acme + globex));
        check(acme + globex == 150 && acme <= 100 && globex <= 100, "s1 one budget per rule across servers");
    }
    //@ end
    //@ from s2 proof

    static void s2RedisDown() {
        RedisStandIn redis = new RedisStandIn();
        redis.down = true;
        ManualClock clock = new ManualClock(0);
        //@ from s2 design
        BucketStore store = new RedisBucketStore(redis, Set.of("login"));   // logins fail closed
        //@ end
        RateLimiter limiter = new RateLimiterService(new RuleBook(List.of(
                new Rule("login", r -> r.endpoint().equals("/login"), Scope.CLIENT, Limit.perMinute(5), TokenBucket::new),
                new Rule("api", r -> !r.endpoint().equals("/login"), Scope.CLIENT, Limit.perMinute(100), TokenBucket::new))),
                store, clock);
        System.out.println("s2  Redis down, /login: " + limiter.check(Request.of("acme", "/login")));
        int passed = 0;
        for (int i = 0; i < 5; i++) if (limiter.check(Request.of("acme", "/items")).allowed()) passed++;
        System.out.println("s2  Redis down, /items: " + passed + " of 5 allowed; Redis was called " + redis.calls.get() + " times");
        int before = redis.calls.get();
        clock.advance(5_000);                                               // the breaker's cooldown ends
        limiter.check(Request.of("acme", "/items"));
        System.out.println("s2  after the cooldown, Redis is tried again: " + (redis.calls.get() - before) + " call");
        check(passed == 5 && before == 3 && redis.calls.get() == 4, "s2 fail open or closed, and the breaker");
    }
    //@ end
    //@ from s3 proof

    static void s3Leasing() {
        RedisStandIn redis = new RedisStandIn();
        List<Rule> rules = List.of(new Rule("client", r -> true, Scope.CLIENT, Limit.perMinute(100), TokenBucket::new));
        //@ from s3 design
        List<RateLimiter> three = servers(3, i -> new LeasingStore(new RedisBucketStore(redis, Set.of()), 10), rules);
        //@ end
        int passed = 0;
        for (int i = 0; i < 300; i++) if (three.get(i % 3).check(Request.of("acme", "/items")).allowed()) passed++;
        System.out.println("s3  3 servers leasing 10 at a time: " + passed + " allowed, " + redis.calls.get()
                + " Redis calls instead of 300");
        check(passed == 100 && redis.calls.get() == 16, "s3 never over the limit, far fewer round trips");
    }
    //@ end
    //@ from extra proof

    static void extraAnswers() throws Exception {
        race(CasTokenBucket::new);                                          // the lock-free bucket, same race
        HitCounter hits = new HitCounter();
        hits.hit(1);
        hits.hit(2);
        hits.hit(3);
        hits.hit(300);
        System.out.println("extra HitCounter: " + hits.getHits(300) + " at 300 s, " + hits.getHits(301)
                + " at 301 s, " + hits.getHits(302) + " at 302 s");
        check(hits.getHits(300) == 4 && hits.getHits(301) == 3 && hits.getHits(302) == 2, "hit counter");
    }
    //@ end

    static void check(boolean ok, String promise) {
        if (!ok) throw new AssertionError("broken: " + promise);
    }
}
