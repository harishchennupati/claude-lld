TITLE = 'Rate limiter'
# core, then the follow-ups (e = extend), then scaling out to many servers (s), then extra answers
SNAPS = ['core', 'e1', 'e2', 'e3', 'e4', 'e5', 's1', 's2', 's3', 'extra']
# Broken copies of the core, compiled and run several times; each must fail every run.
MUTANTS = {
    'nolock': ('core', [('public synchronized Decision tryTake(int cost, long nowMillis) {',
                         'public Decision tryTake(int cost, long nowMillis) {')], 10),
    'getput': ('core', [(
        """        return buckets.computeIfAbsent(rule.id() + "|" + key,
                k -> rule.algorithm().newBucket(rule.limit(), nowMillis));""",
        """        Bucket b = buckets.get(rule.id() + "|" + key);
        if (b == null) {
            b = rule.algorithm().newBucket(rule.limit(), nowMillis);
            buckets.put(rule.id() + "|" + key, b);
        }
        return b;""")], 10),
    'norefund': ('core', [('for (Bucket b : charged) b.refund(request.cost(), now);   // all or nothing',
                           '// (no refund)')], 3),
}
