STEPS = [
dict(id='f-concurrency', stage='Defend', title='Concurrency: three gaps, where each is closed, and the hot lock you name',
think="""
<p><b>Three places where threads can break the limit:</b></p>
<ol>
<li><b>Inside a bucket:</b> two threads read "1 token" and both spend it. <code>synchronized tryTake</code> makes refill, check and take one step.</li>
<li><b>In the store:</b> two threads find no bucket for a new key and both make one. <code>computeIfAbsent</code> makes the lookup and the insert one step.</li>
<li><b>Across rules:</b> a request takes from its client bucket, then the global bucket refuses it. The refund returns the token, so the refused request costs nothing. The race proves all three: exactly 30,000, then exactly 20,000.</li>
</ol>
{{svg:race_n}}
<p><b>Measured on an Apple M4 Pro with JDK 17:</b> one <code>check</code> takes about 66 ns with one rule and 95 ns with two. Fourteen threads on fourteen clients get 47 million checks a second with only per-client rules, because no two clients share a lock. <b>Add the global rule and it drops to 7.3 million</b>: every request now takes the one global bucket's lock. Say that unprompted. It is fine far beyond any real API. If they push, stripe the global limit into 8 buckets of an eighth each (close, not exact), or lease from it in batches, the same idea as the scale-out steps.</p>
<p><b>If they ask for lock-free:</b> keep both numbers in one immutable <code>State</code> and swap it with <code>compareAndSet</code>. It passes the same race.</p>
""",
code=[('extra', 'CasTokenBucket', 'CasTokenBucket: the lock-free bucket, if they ask')],
say="Three gaps: the bucket's read-then-write, the store's check-then-put, and the partial charge across rules. Closed by synchronized, computeIfAbsent and a refund. The global rule is the one hot lock.",
hot='TokenBucket,LocalBucketStore,RateLimiterService', file=('core', None), practice=('the lock-free CasTokenBucket', 8)),

dict(id='f-principles', stage='Defend', title='Design principles and patterns: where each one actually is',
think="""
<table>
<tr><th>principle</th><th>where it is in this code</th></tr>
<tr><td><b>S</b>ingle responsibility</td><td>The bucket counts, the store finds buckets, the rule book knows rules, the service coordinates, the filter speaks HTTP. None does two of these.</td></tr>
<tr><td><b>O</b>pen/closed</td><td>The exact log, shadow mode, waiting, the Redis store, the breaker and leasing were all new classes. The service never changed.</td></tr>
<tr><td><b>L</b>iskov substitution</td><td>Any <code>Bucket</code> works: token, log, Redis proxy, fallback, leased. Any <code>BucketStore</code> works too, and no caller checks which.</td></tr>
<tr><td><b>I</b>nterface segregation</td><td>Every interface has one or two methods: <code>RateLimiter</code>, <code>Bucket</code>, <code>BucketStore</code>, <code>Algorithm</code>, <code>Clock</code>, <code>DecisionListener</code>.</td></tr>
<tr><td><b>D</b>ependency inversion</td><td>The service depends on those interfaces and is handed the implementations. That is why a test hands it a <code>ManualClock</code>, and production a Redis store.</td></tr>
<tr><td>Tell, don't ask</td><td>The service tells a bucket <code>tryTake</code>; it never reads tokens and decides for it.</td></tr>
<tr><td>Composition over inheritance</td><td>No class extends another. Behaviour is combined by holding interfaces: fallback wraps a remote bucket, leasing wraps a store.</td></tr>
<tr><td>Immutability</td><td>Request, Limit, Decision and Rule are records, and the rule book is swapped whole, never edited.</td></tr>
<tr><td>KISS, YAGNI</td><td>No Singleton, no timer thread, no factory class, no <code>Client</code> class, and no interface for <code>RuleBook</code> or <code>Plans</code>.</td></tr>
</table>
<table>
<tr><th>pattern</th><th>where</th><th>why it earned its place</th></tr>
<tr><td>Strategy</td><td><code>Bucket</code> (how to count), <code>Scope</code> (whose budget)</td><td>the two things a rule varies by</td></tr>
<tr><td>Factory</td><td><code>Algorithm</code>: <code>TokenBucket::new</code></td><td>rules make buckets without naming classes</td></tr>
<tr><td>Observer</td><td><code>DecisionListener</code></td><td>dashboards without the limiter knowing them</td></tr>
<tr><td>Decorator</td><td><code>ShadowLimiter</code>, <code>FallbackBucket</code>, <code>LeasingStore</code></td><td>add behaviour around an existing piece without editing it</td></tr>
<tr><td>Proxy</td><td><code>RedisTokenBucket</code></td><td>looks like a local bucket; the state lives in Redis</td></tr>
<tr><td>Adapter</td><td><code>ApiFilter</code></td><td>Decision to HTTP, only at the edge</td></tr>
<tr><td>not used: Singleton</td><td></td><td>one limiter is wiring; tests need fresh ones</td></tr>
</table>
""",
say="Each principle has a class name here: SRP per layer, OCP through the seams, DIP through constructor injection; Strategy, Observer, Decorator and Proxy each earned their place.",
hot='', file=('core', None)),

dict(id='f-pokes', stage='Defend', title='The pokes: two-breath answers',
think="""
<table class="poke">
<tr><td>Why are rules data, not classes?</td><td>New limits come from ops and product, weekly. A row of config plus a predicate covers them without a deploy.</td></tr>
<tr><td>Why check narrow rules first?</td><td>A noisy client is stopped by its own rule and never takes the global lock everyone shares.</td></tr>
<tr><td>Why does Bucket need refund?</td><td>All or nothing across rules: a request refused by the third rule must give back what the first two took.</td></tr>
<tr><td>Could two rules deadlock?</td><td>No. A bucket's lock is held only inside its own method, never while taking another.</td></tr>
<tr><td>Why is the rule id in the store key?</td><td>Two rules with the same scope, per second and per minute, need different buckets for the same client.</td></tr>
<tr><td>Why aren't the tokens volatile?</td><td>Every read and write happens inside the bucket's lock, and the lock publishes the writes.</td></tr>
<tr><td>A request costs more than the limit?</td><td>It can never pass. Refuse it with no <code>Retry-After</code>, so the client doesn't retry forever.</td></tr>
<tr><td>Limit by IP as well?</td><td>One new <code>Scope</code> constant, and a rule that uses it.</td></tr>
<tr><td>VIPs never wait behind others?</td><td>A PRO rule with its own buckets, and a separate global cap for PRO traffic.</td></tr>
<tr><td>Hits in the last 5 minutes (LeetCode 362)?</td><td>300 reused slots, one per second. Code below.</td></tr>
<tr><td>Test a refill without sleeping?</td><td>A <code>ManualClock</code>, and <code>advance(200)</code>.</td></tr>
<tr><td>The clock jumps back?</td><td><code>nanoTime</code> never goes back, and an older reading earns nothing.</td></tr>
</table>
{{named:extra:hits|HitCounter: 300 reused slots}}
""",
say="Every poke gets a class, a number or a line of code, never an adjective.",
hot='', file=('core', None)),
]
