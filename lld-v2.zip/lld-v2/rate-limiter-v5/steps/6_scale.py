STEPS = [
dict(id='s0', stage='Scale', title='Many servers: the problem, and five ways out',
think="""
<p class="ask">“We run twelve copies of the service behind a load balancer. acme is on 100 a minute. What does it actually get?”</p>
<p>Up to 1,200: each server's <code>LocalBucketStore</code> gives acme a full budget. The limit is only true if every server counts from the same budget.</p>
{{svg:s_problem}}
<table>
<tr><th>option</th><th>how</th><th>breaks when</th></tr>
<tr><td>divide the limit</td><td>each server allows 100 ÷ 12</td><td>traffic is uneven, which it always is: acme on 2 servers gets 17</td></tr>
<tr><td>sticky routing</td><td>the load balancer sends each client to one server</td><td>a server dies or scales, and its clients start fresh elsewhere</td></tr>
<tr><td><b>a shared store</b></td><td><b>every bucket in Redis; one script does refill, check and take</b></td><td>Redis is down or slow: steps 27 and 28</td></tr>
<tr><td>leasing on top</td><td>each server takes tokens in batches and spends them locally</td><td>a server holds unused tokens: slightly early refusals</td></tr>
<tr><td>gossip counts</td><td>servers share counts every second</td><td>up to a second of over-admission; complex</td></tr>
</table>
<p><b>Where it lands:</b> <code>BucketStore</code>. The service, the rules, the scopes, all-or-nothing and the listeners stay exactly as they are. That is the payoff of making "where" a seam in step 5.</p>
""",
say="Twelve servers with their own maps give twelve times the limit. The fix is one shared store, and in this design that is one new BucketStore.",
hot='BucketStore', file=('e5', None)),

dict(id='s1', stage='Scale', title='The Redis store: same service, buckets that live in Redis',
think="""
<p><code>RedisBucketStore</code> hands out a <code>RedisTokenBucket</code> for each rule and key. That is a <b>proxy</b>: it looks like a local bucket, but its numbers live in a Redis hash, and <code>tryTake</code> runs one Lua script there. Redis runs one script at a time, so refill, check and take cannot interleave across servers. The script is the fleet's <code>synchronized</code>.</p>
{{svg:s_redis}}
<ul>
<li><b>Redis's clock, not the server's.</b> The script reads <code>TIME</code>. Twelve servers' clocks differ by milliseconds, and a budget must use one clock.</li>
<li><b>Idle keys delete themselves.</b> <code>PEXPIRE</code> for one window, since an idle bucket is full anyway. That is follow-up 5, done by Redis.</li>
<li><b>Refund is its own tiny script.</b> All or nothing still works across Redis keys, because the service is unchanged.</li>
<li><b><code>{acme}</code> is a hash tag.</b> In Redis Cluster, all of acme's keys land in one slot, so one script could touch them together later. The global key cannot share a slot with every client, which is why the refund stays.</li>
</ul>
""",
code=[('s1', 'diff', '')], out=('s1', 's1'),
say="A Redis store hands out proxy buckets whose numbers live in Redis; one Lua script on Redis's clock refills and takes atomically, and the service does not change.",
after="""<div class="hole">Every rule is now a network round trip, about 0.5 ms each, so three rules cost 1.5 ms per request. Step 28 cuts that. <span class="mut">The Lua was run under Lua 5.1, the version inside Redis, against a stand-in for TIME, HMGET, HSET and PEXPIRE; the Java side ran against a stand-in that does one call at a time.</span></div>""",
new='RedisBucketStore,RedisTokenBucket', hot='BucketStore,Bucket', pattern=[('Proxy', 'RedisTokenBucket: a local-looking bucket whose state lives in Redis')],
file=('s1', None), practice=('RedisBucketStore and RedisTokenBucket', 12)),

dict(id='s2', stage='Scale', title='Redis slow or down: fail open or closed, and a circuit breaker',
think="""
<p class="ask">“Redis times out. What happens to every request?”</p>
<p>Without care, every request waits for the timeout and then errors, so the limiter takes the whole API down with it. Two decisions fix that. First, <b>a policy per rule</b>: a public API fails open (allow), because a minute over the limit beats an outage, while logins fail closed (refuse), because a password attack must not get through while Redis is down. Second, <b>a circuit breaker</b>: after 3 failures in a row, stop calling Redis for 5 seconds and answer from the policy at once, then let one call through to test it.</p>
{{svg:s_breaker}}
<p>Both are decorators. <code>FallbackBucket</code> wraps each remote bucket, and the store wraps every bucket it hands out. The service still doesn't know.</p>
""",
code=[('s2', 'diff', '')], out=('s2', 's2'),
say="Redis down: each rule fails open or closed by policy, and a breaker stops calling a dead Redis after 3 failures, so no request waits on a timeout.",
after="""<div class="hole">Failing open means the limit is off while Redis is down. Alert on it, and keep a coarse local limit per server as a backstop, for example the global cap ÷ 12.</div>""",
new='FallbackBucket,Breaker', hot='RedisBucketStore', pattern=[('Decorator', 'FallbackBucket wraps any remote bucket')], file=('s2', None), practice=('FallbackBucket and Breaker', 10)),

dict(id='s3', stage='Scale', title='Hot keys and round trips: lease tokens in batches',
think="""
<p class="ask">“The global key is one Redis key hit by every request on every server, and each rule costs a round trip. Make it cheaper.”</p>
<p><code>LeasingStore</code> wraps any store. Each server keeps a <code>LeasedBucket</code> per rule and key that takes tokens from Redis <b>ten at a time</b> and spends them locally. It is never over the limit, because tokens are taken before they are spent. Round trips drop about tenfold: 300 requests made 16 Redis calls. And when Redis refuses, the bucket remembers the retry time, so it doesn't ask again until then.</p>
{{svg:s_lease}}
""",
code=[('s3', 'diff', '')], out=('s3', 's3'),
say="Each server leases tokens in batches of 10 and spends them locally: never over the limit, about ten times fewer round trips, and the hot key cools.",
after="""<div class="hole">A server can hold unused tokens while another refuses, so a client may be refused a little early. Keep batches small next to the limit, and return leases a server hasn't used for a while.</div>
<p><b>What else they may push on, one breath each.</b> <b>Redis failover</b> can lose the last few writes, so budgets may briefly reset: accept it, or run limits across regions per region. <b>Several regions:</b> a limit per region, or a global limit split by region. <b>Clock skew:</b> none, because the script uses Redis's <code>TIME</code>. <b>Memory in Redis:</b> about 100 bytes a hash, with <code>PEXPIRE</code> removing idle ones.</p>""",
new='LeasingStore,LeasedBucket', hot='BucketStore,Bucket', file=('s3', None), practice=('LeasedBucket and LeasingStore', 10)),
]
