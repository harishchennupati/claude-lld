STEPS = [
dict(id='problem', stage='Brief', wide=True, title='The problem, in plain words',
think="""
<p class="ask">“Design a rate limiter for our public API. Every request carries the caller's API key. Free clients get a small limit and paid clients a bigger one. Search is expensive, so it has its own tighter limit. And the whole API must never take more than the servers can handle. Some calls cost more than one unit. Many threads, and later many servers. Working code.”</p>
<p><b>What it is.</b> Before the API does any work, it asks the limiter one question: <code>check(request)</code>. The answer is <span class="ok">allowed</span> with how much budget is left, or <span class="no">refused</span> with when to retry and which rule said no. The API turns a refusal into HTTP 429 with a <code>Retry-After</code> header. Several rules can apply to one request, and it passes only if every one of them allows it.</p>
<p><b>What they grade.</b> The rules are data, not <code>if</code>s. The counting algorithm sits behind an interface. A refused request is charged by no rule. The lock is in the right place, and a test proves it. And each follow-up lands as a new class, not a rewrite, including the jump to many servers.</p>
<p><b>Ask these first. If they say "you decide", assume the answer shown.</b></p>
<table>
<tr><th>ask</th><th>assume</th><th>it decides</th></tr>
<tr><td>One server, or many sharing the limits?</td><td>one process now; many later</td><td>where budgets live is its own seam: <code>BucketStore</code></td></tr>
<tr><td>Limit by what: API key, IP, endpoint?</td><td>API key; also per endpoint; also a global cap</td><td>a <code>Scope</code> turns a request into a key</td></tr>
<tr><td>Same limit for everyone?</td><td>FREE and PRO plans</td><td><code>Plans</code>, and a rule per plan</td></tr>
<tr><td>Can one call cost more than one?</td><td>yes: an export costs 3</td><td><code>Request.cost</code>; buckets take a cost</td></tr>
<tr><td>Is a refused request counted?</td><td>no, by no rule</td><td>all or nothing: a refund</td></tr>
<tr><td>Bursts, or evenly spaced?</td><td>bursts up to the limit</td><td>a token bucket</td></tr>
<tr><td>Refused: fail, or wait?</td><td>fail fast, say when</td><td><code>Decision</code> carries the retry time</td></tr>
</table>
<p><b>Functional:</b> <code>check(request)</code> answers allowed with what's left, or refused with the retry time and the rule. Rules come from config: which requests, whose budget, how much, and how it is counted. A request passes only if all its rules allow it, and a refused one is charged by none. Costs can exceed 1.
<br><b>Non-functional:</b> never over any rule, whatever the thread count. O(1) per rule, and one client never slows another. New rules, algorithms and stores plug in without edits. Tests control time.</p>
<p><b>The example on every step.</b> acme is FREE: 5 a second. globex is PRO: 50 a second. Search: 2 a second per client. Global: 60 a second in total.</p>
{{svg:acme}}
""",
say="Rules as data, applied all or nothing; a token bucket per rule and key, behind an interface; a store that is its own seam; time injected. One process first, many servers later."),

dict(id='algorithm', stage='Brief', wide=True, title='Pick the counting algorithm first: a per-minute counter lets through twice the limit',
think="""
<p><b>The first idea</b> is a counter per client that resets every minute. At 12:00:59.9 acme sends 100 and all pass. The counter resets, and at 12:01:00.1 acme sends 100 more, and all pass. That is 200 in 0.2 seconds.</p>
{{svg:edge}}
<table>
<tr><th>algorithm</th><th>keeps per key</th><th>goes wrong</th><th>use it when</th></tr>
<tr><td>fixed window</td><td>a count, and its minute</td><td>2× the limit at the edge</td><td>edges don't matter: a daily quota</td></tr>
<tr><td>sliding window log</td><td>a timestamp per unit</td><td>memory grows with the limit</td><td>small exact limits: logins</td></tr>
<tr><td>sliding window counter</td><td>this and last window's count</td><td>an estimate</td><td>O(1) and close is enough</td></tr>
<tr><td><b>token bucket</b></td><td>tokens, and when counted</td><td>a quiet key may burst its capacity</td><td><b>an API: O(1), bursts, cost, a one-line retry time</b></td></tr>
</table>
<p>I pick the token bucket as the default, but the design will not depend on it: the algorithm is a seam, and each rule names its own. Follow-up 1 adds the exact log for logins.</p>
""",
say="A fixed window lets twice the limit through at the edge; the token bucket is my default, and each rule can pick another."),
]
