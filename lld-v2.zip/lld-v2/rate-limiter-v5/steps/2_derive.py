STEPS = [
dict(id='d-nouns', stage='Derive', wide=True, title='Nouns: which become classes, which stay values',
think="""
<p>I read the spec for its nouns and put each through one filter. <b>Does it hold state that changes, or enforce a rule?</b> Then it is a class with behaviour. <b>Is it a few values that travel together?</b> Then it is a record, or an enum when the set is fixed. <b>Does it only describe something else?</b> Then it is a field.</p>
{{svg:d_nouns}}
<p>Two nouns tempt people and stay out. A <code>Client</code> class would hold nothing but an id. An <code>Endpoint</code> class would hold nothing but a path. Adding them is code with no rule in it, and an interviewer notices.</p>
<div class="trap">Two maps in the limiter: tokens by client, and last refill by client. Every request writes both in two steps, so threads see one updated and not the other, and every new algorithm adds more maps. One <code>Bucket</code> object per rule and key keeps its own numbers, and gives the lock an obvious home.</div>
""",
say="Nouns with changing state become classes: Bucket, Plans, RuleBook. Values become records: Request, Limit, Decision, Rule. A client stays a String."),

dict(id='d-verbs', stage='Derive', wide=True, title='Verbs: each goes to the class that owns the state it touches',
think="""
<p>For every verb I ask which class holds the state it reads and writes, and that class gets the method. The caller tells an object what to do; it never pulls the object's numbers out and decides for it. That is "tell, don't ask", and it is what keeps each class small.</p>
<table>
<tr><th>verb in the spec</th><th>state it touches</th><th>owner</th><th>method</th></tr>
<tr><td>spend a unit, or say when</td><td>tokens, last refill</td><td><code>TokenBucket</code></td><td><code>tryTake(cost, now)</code></td></tr>
<tr><td>give a unit back</td><td>tokens</td><td><code>TokenBucket</code></td><td><code>refund(cost, now)</code></td></tr>
<tr><td>find the budget for a key</td><td>the map of buckets</td><td><code>LocalBucketStore</code></td><td><code>bucket(rule, key)</code></td></tr>
<tr><td>which rules cover a request</td><td>the list of rules</td><td><code>RuleBook</code></td><td><code>rulesFor(request)</code></td></tr>
<tr><td>whose budget is this</td><td>none: a function of the request</td><td><code>Scope</code></td><td><code>key(request)</code></td></tr>
<tr><td>which plan is this client on</td><td>client → plan</td><td><code>Plans</code></td><td><code>of(clientId)</code></td></tr>
<tr><td>check a request against every rule</td><td>spread over all of the above</td><td><code>RateLimiterService</code></td><td><code>check(request)</code></td></tr>
</table>
<p>The last row matters. A verb whose state is spread over several classes goes to the one class that can see them all: <b>the orchestrator</b>. It holds no counts itself. It only coordinates the objects that do, which is why it will need no lock of its own.</p>
""",
say="Each verb goes to the class that owns its state; the one verb that spans them all becomes the orchestrator, RateLimiterService."),

dict(id='d-seams', stage='Derive', wide=True, title='What will change: six seams, and the right shape for each',
think="""
<p>Now I ask what the interviewer will change mid-round, and give each thing its own seam. That way each changes for its own reason, and nothing else opens. Six things change independently here.</p>
{{svg:d_axes}}
<p><b>The right shape for each is not always an interface:</b></p>
<ul>
<li><b>How to count</b> is behaviour with its own state per key, so <code>Bucket</code> is an interface, and <code>Algorithm</code> is a factory for it: <code>TokenBucket::new</code>. This is the <b>Strategy</b> pattern.</li>
<li><b>Where it lives</b> is an interface, <code>BucketStore</code>. The whole jump to many servers will be one new implementation.</li>
<li><b>Whose budget</b> is a small fixed set, so <code>Scope</code> is an enum whose constants each compute a key. Adding "per IP" is one constant.</li>
<li><b>Which requests and how many</b> is data, so a <code>Rule</code> is a record, and its "which requests" is a <code>Predicate&lt;Request&gt;</code>. New rules are config, not classes.</li>
<li><b>Who hears</b> is <code>DecisionListener</code>. This is <b>Observer</b>: the limiter tells whoever registered, and does not know what a dashboard is.</li>
<li><b>When is now</b> is <code>Clock</code>, handed in, so tests move time by hand.</li>
</ul>
<p>What I do not make an interface: <code>RuleBook</code>, <code>Plans</code>, and the records. Nobody will swap them. An interface with one implementation and no reason to change is ceremony.</p>
""",
say="Six seams: what and how many as data, whose as an enum, how to count as a strategy, where as a store, who hears as listeners, and time as a clock."),

dict(id='d-rules', stage='Derive', wide=True, title='Many rules on one request: all or nothing',
think="""
<p>A request can match several rules: its plan's rule, the search rule, and the global cap. The spec says it passes only if all of them allow it, and that a refused request is charged by none. So the orchestrator checks the rules in order, takes from each bucket as it goes, and on the first refusal gives back everything it took. That undo is a <b>refund</b>, which is why <code>Bucket</code> has two methods, not one.</p>
{{svg:d_all}}
<p><b>The order is a design decision.</b> Narrow rules come first, the global cap last. A noisy client is then stopped by its own rule and never touches the one lock every client shares. The <code>RuleBook</code> keeps the rules in the order it was given.</p>
<div class="hole">Between taking a token and refunding it, the first bucket shows one fewer token, for nanoseconds. Another request on the same key arriving just then may be refused although in the end there was room. It never lets through more than a rule allows; rarely, it refuses one it could have allowed. Locking every bucket first would close this, but it needs one global lock order, and it turns every request into a multi-lock step.</div>
""",
say="Rules are checked narrow to wide, taking as I go; the first refusal refunds everything taken, so a refused request is charged by no rule."),

dict(id='d-state', stage='Derive', wide=True, title='Shared state and lookups: where the locks go, and why every lookup is O(1)',
think="""
<p><b>What do many threads change at once?</b> Only the buckets: one key's tokens. So the lock goes on each bucket (<code>synchronized tryTake</code>), and two keys never wait for each other. The map of buckets is a <code>ConcurrentHashMap</code>, and <code>computeIfAbsent</code> makes exactly one bucket for a new key, even when two threads meet it at once. The orchestrator takes no lock at all, and listeners are told after the decision, outside every lock.</p>
{{svg:race_n}}
<p><b>What question is asked of each collection?</b> I pick the shape that answers it in O(1), or say why not.</p>
<table>
<tr><th>question</th><th>shape</th><th>cost</th></tr>
<tr><td>the bucket for this rule and key?</td><td><code>ConcurrentHashMap&lt;String, Bucket&gt;</code></td><td>O(1)</td></tr>
<tr><td>tokens left now?</td><td>two numbers, refilled from elapsed time</td><td>O(1), no timer</td></tr>
<tr><td>which rules cover this request?</td><td>a list, filtered in order</td><td>O(rules): fine for tens. With hundreds, index by endpoint.</td></tr>
<tr><td>which plan is this client on?</td><td><code>ConcurrentHashMap&lt;String, Plan&gt;</code></td><td>O(1)</td></tr>
</table>
""",
say="The lock lives on each bucket, computeIfAbsent makes one bucket per key, the orchestrator holds no lock, and every lookup is a hash map or two numbers."),

dict(id='d-design', stage='Derive', wide=True, title='The whole design, up front: five layers, one call through them',
think="""
{{svg:layers}}
<p><b>One call through the layers.</b> The <code>ApiFilter</code> builds a <code>Request</code> and calls <code>check</code>. <code>RateLimiterService</code> reads the clock once and asks the <code>RuleBook</code> which rules apply. For each rule, <code>Scope</code> turns the request into a key, and the <code>BucketStore</code> finds or makes that key's bucket. The bucket locks itself, refills, and takes the cost or says when. On a refusal the service refunds what it took. Listeners hear the <code>Decision</code>, and the filter answers 200, or 429 with <code>Retry-After</code>.</p>
<p><b>Where state lives.</b> Buckets change on every request, each behind its own lock. The store's map changes when a key is new. <code>Plans</code> changes when a client pays. Everything else is a record that never changes.</p>
<p><b>Why this shape.</b> Each layer changes for its own reason: the edge when HTTP changes, rules when plans change, counting when they ask for exactness, storage when they add servers. The orchestrator depends only on interfaces and records, so every follow-up lands in one layer. No Singleton: one limiter per process is wiring in <code>main</code>, and tests need fresh ones.</p>
<p>The next steps build this bottom-up, in typing order. The diagram on the right fills in as you go.</p>
""",
say="Five layers: edge, orchestrator, rules, counting, storage, with time and listeners on the side; the orchestrator sees only interfaces, so every change lands in one layer."),
]
