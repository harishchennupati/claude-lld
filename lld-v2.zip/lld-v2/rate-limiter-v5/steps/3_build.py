T_VALUES = 'Request,Limit,Decision'
T_CLOCK = T_VALUES + ',Clock,SystemClock,ManualClock'
T_BUCKET = T_CLOCK + ',Bucket,Algorithm,TokenBucket'
T_RULES = T_BUCKET + ',Plan,Plans,Scope,Rule,RuleBook'
T_STORE = T_RULES + ',BucketStore,LocalBucketStore'
T_SERVICE = T_STORE + ',RateLimiter,DecisionListener,RefusalCounter,RateLimiterService'
T_EDGE = T_SERVICE + ',Response,ApiFilter'

STEPS = [
dict(id='b-values', stage='Build', title='Request, Limit, Decision: the three values everything passes around',
think="""
<p>I start with the words every other class uses. A <code>Request</code> is who sent it, to which endpoint, and what it costs. A <code>Limit</code> is permits per window. A <code>Decision</code> is allowed with what's left, or refused with when to retry and which rule said no.</p>
<p>All three are records: set once, never changed, so any thread can share them without a lock. Each checks itself when made, so a cost of 0 or a limit of 0 fails at the call that made it. <code>Decision.NEVER</code> marks a request that costs more than a whole bucket. Telling that one to wait would have it wait forever.</p>
""",
code=[('core', 'Request,Limit,Decision', 'Request, Limit, Decision')],
say="Three immutable records: Request, Limit, and a Decision that carries what's left, the retry time and the rule.",
hot='Request,Limit,Decision', file=('core', T_VALUES), practice=('Request, Limit, Decision', 4)),

dict(id='b-clock', stage='Build', title='Clock: time is handed in, never read inside',
think="""
<p>Every rule is about elapsed time, so no class reads the clock itself. <code>SystemClock</code> uses <code>nanoTime</code>, which only moves forward: the wall clock can jump back when the machine corrects it. <code>ManualClock</code> is for tests. <code>advance(200)</code> is 200 ms that pass at once, so no test sleeps and every run gives the same answer.</p>
""",
code=[('core', 'Clock,SystemClock,ManualClock', 'Clock and its two implementations')],
say="Time is an interface: nanoTime in production, a manual clock in tests.",
hot='Clock', file=('core', T_CLOCK), practice=('Clock, SystemClock, ManualClock', 3)),

dict(id='b-bucket', stage='Build', title='Bucket and TokenBucket: how one key counts',
think="""
<p><code>Bucket</code> is one key's budget, whatever the algorithm. It has two methods: <code>tryTake(cost, now)</code> and <code>refund(cost, now)</code>. The refund exists because rules are all or nothing. <code>Algorithm</code> makes a bucket for a rule's limit, and <code>TokenBucket::new</code> is one: the limiter will never name an algorithm.</p>
<p>The token bucket holds four numbers. With acme's limit of 5 a second:</p>
<ul>
<li><b>earned</b> = elapsed × capacity ÷ window: 200 ms earns 1 token.</li>
<li><b>never above capacity</b>: 5 quiet seconds leave 5 tokens, not 25.</li>
<li><b>wait</b> = (cost − tokens) × window ÷ capacity, rounded up: 0 tokens and cost 1 gives 200 ms.</li>
<li><b>cost above capacity</b>: refuse with <code>NEVER</code>, since no wait will help.</li>
</ul>
<p><code>tryTake</code> and <code>refund</code> are <code>synchronized</code>, so refill, check and take are one step, for this key only.</p>
""",
code=[('core', 'Bucket,Algorithm,TokenBucket', 'Bucket, Algorithm, TokenBucket')],
say="A bucket per rule and key takes a cost or says when, and gives it back on refund; the algorithm is a factory, TokenBucket::new.",
hot='Bucket,Algorithm,TokenBucket', pattern=[('Strategy', 'Bucket: one interface, any counting algorithm'), ('Factory', 'Algorithm: TokenBucket::new makes a bucket')],
file=('core', T_BUCKET), practice=('Bucket, Algorithm and TokenBucket', 8)),

dict(id='b-rules', stage='Build', title='Plans, Scope, Rule, RuleBook: the rules are data',
think="""
<p>A <code>Rule</code> is one row of config. <code>appliesTo</code> says which requests it covers, <code>scope</code> says whose budget it counts against, then come the limit and the algorithm. <code>appliesTo</code> is a <code>Predicate&lt;Request&gt;</code>, so "FREE clients", "only /search" and "everyone" are one line each. A new rule is config, not a new class.</p>
<p><code>Scope</code> is an enum whose constants each compute a key. CLIENT gives <code>acme</code>, CLIENT_ENDPOINT gives <code>acme /search</code>, and GLOBAL gives <code>*</code>, so the global rule has one bucket for everyone. <code>RuleBook</code> keeps the rules in the order it was given, narrow first and global last, and returns those that apply. <code>Plans</code> says which plan each client is on.</p>
""",
code=[('core', 'Plan,Plans,Scope,Rule,RuleBook', 'Plan, Plans, Scope, Rule, RuleBook')],
say="Rules are data: which requests, whose budget, how much and how counted, checked narrow first; a scope turns a request into a key.",
hot='Plans,Scope,Rule,RuleBook', pattern=[('Strategy, as an enum', 'Scope: each constant computes its own key')],
file=('core', T_RULES), practice=('Plans, Scope, Rule, RuleBook', 6)),

dict(id='b-store', stage='Build', title='BucketStore: where each key\'s budget lives',
think="""
<p>Where buckets live is its own seam, because it is exactly what changes when there are many servers. <code>LocalBucketStore</code> is a <code>ConcurrentHashMap</code> from "rule and key" to bucket. The rule's id is part of the key, so acme's FREE bucket and acme's search bucket are different buckets.</p>
<p><code>computeIfAbsent</code> makes the bucket in one step. Two threads that meet a new key at the same moment still get one bucket between them. With a <code>get</code> and then a <code>put</code>, each would make its own full bucket.</p>
""",
code=[('core', 'BucketStore,LocalBucketStore', 'BucketStore, LocalBucketStore')],
say="A store finds or makes the bucket for a rule and key; in memory it is a ConcurrentHashMap with computeIfAbsent.",
hot='BucketStore,LocalBucketStore', file=('core', T_STORE), practice=('BucketStore and LocalBucketStore', 3)),

dict(id='b-service', stage='Build', title='RateLimiterService: every rule, or none',
think="""
<p>The API depends on <code>RateLimiter</code>, a one-method interface. <code>RateLimiterService</code> implements it and is handed its rule book, store and clock. <code>check</code> reads the clock once, walks the rules that apply in order, and takes the cost from each rule's bucket. The first refusal refunds every bucket already charged, and the decision names the rule that refused. When all rules allow, "what's left" is the smallest across them.</p>
<p>Then it tells the listeners. That happens outside every lock, in a <code>try</code>, because a broken dashboard must never break the limiter. The service holds no lock and no counts: it only coordinates.</p>
""",
code=[('core', 'RateLimiter,DecisionListener,RefusalCounter,RateLimiterService', 'RateLimiter, DecisionListener, RefusalCounter, RateLimiterService')],
say="The service checks every applicable rule in order, refunds on the first refusal, and tells listeners after; it holds no lock of its own.",
hot='RateLimiter,DecisionListener,RefusalCounter,RateLimiterService',
pattern=[('Observer', 'DecisionListener: the limiter tells, and doesn\'t know who listens'), ('Dependency injection', 'the service is handed rules, store and clock')],
file=('core', T_SERVICE), practice=('RateLimiterService.check, with the refund', 8)),

dict(id='b-edge', stage='Build', title='ApiFilter: the edge, where a Decision becomes HTTP',
think="""
<p>The limiter knows nothing about HTTP. The filter does: 200 with <code>X-RateLimit-Remaining</code>, or 429 with <code>Retry-After</code> in whole seconds, rounded up, and the rule that refused. A request that can never fit gets no <code>Retry-After</code>, so the client doesn't retry forever.</p>
<p>Keeping HTTP at the edge means the same limiter can sit behind a gRPC server or a queue consumer unchanged.</p>
""",
code=[('core', 'Response,ApiFilter', 'Response, ApiFilter')],
say="HTTP lives only at the edge: 200 with remaining, or 429 with Retry-After in seconds.",
hot='ApiFilter', pattern=[('Adapter, at the edge', 'ApiFilter turns a Decision into HTTP')], file=('core', T_EDGE), practice=('ApiFilter', 3)),

dict(id='b-main', stage='Build', title='Main: the story, and a race that must let exactly 30,000 through',
think="""
<p>I wire it the way production would, then prove it. acme (FREE, 5 a second) sends 7, and 5 pass. globex (PRO) searches 3 times: the search rule stops the third, and the token the pro rule took for it goes back, so its next request shows 47 left, not 46. The edge turns a refusal into 429. A request costing 3 fits, and one costing 6 never can.</p>
<p>Then the race: 100 threads, 100 clients, each allowed 500 a day, under a global cap of 30,000, on a frozen clock. Exactly 30,000 may pass. A minute later each client may spend exactly what it didn't use, 20,000 in all, and that is only true if every refused request was refunded.</p>
<p>Then I break it on purpose. Without <code>synchronized</code>: {{mutant:nolock}}. With a get then a put: {{mutant:getput}}. Without the refund: {{mutant:norefund}}.</p>
""",
code=[('core', 'Main', 'Main')], out=('core', None),
say="And I prove it: the story, then a 100-thread race that must let exactly 30,000 through, then refund exactly what went unused.",
hot='', file=('core', None), practice=('Main: the story and the race', 10)),
]
