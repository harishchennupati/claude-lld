"""v7 figures: a sequence diagram of one check, the class diagram, and v5's figures with the example's new names."""
import sys, os, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'tools'))
from lldkit import Svg, C  # type: ignore  # noqa: E402

_spec = importlib.util.spec_from_file_location('figures_v5', os.path.join(HERE, '..', 'rate-limiter-v5', 'figures.py'))
assert _spec is not None and _spec.loader is not None
v5 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v5)
fig_edge, fig_fu1_n, fig_s_breaker = v5.fig_edge, v5.fig_fu1_n, v5.fig_s_breaker


def _renamed(svg, pairs):
    import html
    for a, b in pairs:
        a, b = html.escape(a), html.escape(b)                 # the SVG holds escaped text
        assert a in svg, a
        svg = svg.replace(a, b)
    return svg


def fig_bucket():
    return _renamed(v5.fig_acme(), [("Acme's bucket: capacity 5, earns 5 a second", "The widget's bucket: holds 5, earns 5 a second")])


def fig_race_n():
    return _renamed(v5.fig_race_n(), [("acme's bucket", "the widget's bucket")])


def fig_s_problem():
    return _renamed(v5.fig_s_problem(), [('acme: 100', 'widget: 100'), ('acme gets 300 a minute', 'the widget gets 300 a minute'),
                                         ('acme gets 100 a minute, on any server', 'the widget gets 100 a minute, on any server')])


def fig_s_redis():
    return _renamed(v5.fig_s_redis(), [('rate:{acme}:free-client', 'rate:{weather-widget}:free-plan'),
                                       ('rate:{acme search}:search', 'rate:{weather-widget /search}:search'),
                                       ('TAKE: refill from TIME, check, spend, PEXPIRE, in one step', 'TAKE: refill by Redis TIME, check, take, expire: one step'),
                                       ('REFUND: give back, capped at capacity', 'REFUND: give tokens back, never above capacity'),
                                       ('{…} is a hash tag: one key per shard slot group', "{…} is a hash tag: one client's keys on one node"),
                                       ('the global key is one hot key: see leasing', 'every request uses the global key: see leasing')])


def fig_s_lease():
    s = Svg(700, 250)
    s.rect(220, 16, 260, 56, fill=C['sur'], stroke=C['acc'], sw=1.8)
    s.text(350, 40, "Redis: the widget's 100 a minute", size=11, anchor='middle', weight='600')
    s.text(350, 58, 'handed out in batches of 10', size=9.5, fill=C['mut'], anchor='middle')
    for i, (held, note) in enumerate([(7, 'spends locally, no round trip'), (10, 'has just leased 10'), (2, 'will ask for 10 more at 0')]):
        x = 20 + i * 230
        s.rect(x, 130, 200, 74, fill=C['sur'], stroke=C['line'])
        s.text(x + 100, 152, f'server {i + 1}: LeasedBucket', size=11, anchor='middle', weight='600')
        s.text(x + 100, 172, f'holds {held} tokens', size=10.5, fill=C['green'], anchor='middle')
        s.text(x + 100, 190, note, size=9.5, fill=C['mut'], anchor='middle')
        s.line([(350, 72), (x + 100, 128)], stroke=C['blue'], sw=1.2, end='arr-blue')
    s.text(20, 228, 'The limit still holds: a token is taken from Redis before it is spent. The cost: a server may hold', size=10, fill=C['txt'])
    s.text(20, 244, 'tokens it does not use while another refuses. In the demo, 300 requests needed 16 calls to Redis.', size=10, fill=C['txt'])
    return s.render('Leasing: fewer round trips to Redis')


def fig_refund():
    s = Svg(720, 236)
    s.text(360, 22, 'The rules are checked in order. The first refusal ends the check,', size=12, anchor='middle')
    s.text(360, 40, 'and every token already taken is given back.', size=12, anchor='middle')
    boxes = [(14, 'weather-widget', 'GET /search, cost 1', C['mut'], True), (192, 'rule free-plan', '3 → 2 tokens: took 1', C['green'], False),
             (370, 'rule search', '0 tokens: refused', C['red'], False), (548, 'rule global', 'never asked', C['dim'], False)]
    for x, name, sub, col, dashed in boxes:
        s.rect(x, 64, 158, 58, fill=C['bg'] if dashed else C['sur'], stroke=col, sw=1.6, dash='3 3' if dashed else None)
        s.text(x + 79, 88, name, size=12, anchor='middle', weight='600')
        s.text(x + 79, 107, sub, size=11, fill=col if not dashed else C['mut'], anchor='middle')
    s.line([(172, 93), (190, 93)], end='arr')
    s.line([(350, 93), (368, 93)], stroke=C['green'], end='arr-green')
    s.line([(528, 93), (546, 93)], stroke=C['dim'], dash='3 3')
    s.line([(449, 122), (449, 158), (271, 158), (271, 124)], stroke=C['peach'], dash='4 3', end='arr')
    s.text(360, 178, 'refund: free-plan goes back to 3 tokens', size=11.5, fill=C['peach'], anchor='middle', weight='600')
    s.text(360, 206, 'So a refused request uses no budget, and the global bucket is never touched for it.', size=11, fill=C['mut'], anchor='middle')
    s.text(360, 224, 'Narrow rules come first, so a busy client is stopped before it reaches the shared bucket.', size=11, fill=C['mut'], anchor='middle')
    return s.render('One request, three rules: all or nothing')


def fig_mini():
    return v5.fig_mini().replace('green dashed: handed in', 'green dashed: passed in')


# ----------------------------------------------------------------------------- the class diagram
def ub(s, x, y, w, name, fields=(), methods=(), kind='class'):
    """A UML class box. kind: class | interface | record | enum. Returns its height."""
    head = 24 if kind == 'class' else 34
    lh = 15
    h = head + (len(fields) * lh + 10 if fields else 0) + (len(methods) * lh + 10 if methods else 0) + 2
    stroke = {'interface': C['blue'], 'record': C['teal'], 'enum': C['teal']}.get(kind, C['line'])
    s.rect(x, y, w, h, fill=C['sur'], stroke=stroke, dash='5 3' if kind == 'interface' else None, sw=1.5)
    if kind == 'class':
        s.text(x + w / 2, y + 17, name, size=12.5, weight='600', anchor='middle')
    else:
        s.text(x + w / 2, y + 13, '«' + kind + '»', size=9.5, fill=C['mut'], anchor='middle')
        s.text(x + w / 2, y + 28, name, size=12.5, weight='600', anchor='middle')
    cy = y + head
    for rows, fill in ((fields, C['mut']), (methods, C['txt'])):
        if rows:
            s.line([(x, cy), (x + w, cy)], stroke=C['line'], sw=1)
            for i, r in enumerate(rows):
                s.text(x + 9, cy + 14 + i * lh, r, size=10.5, fill=fill)
            cy += len(rows) * lh + 10
    return h


def fig_classes7():
    s = Svg(1000, 790)
    G, P = dict(stroke=C['green'], dash='5 3', end='arr-green'), dict(stroke=C['acc'], dash='2 3', end='arr-acc')
    ub(s, 16, 14, 220, 'Response', ['status: int', 'headers: Map<String, String>'], kind='record')
    ub(s, 390, 14, 240, 'ApiFilter', ['limiter: RateLimiter'], ['handle(Request): Response'])
    ub(s, 390, 118, 240, 'RateLimiter', methods=['check(Request): Decision'], kind='interface')
    s.rect(660, 14, 324, 176, fill=C['sur'], stroke=C['teal'], sw=1.5)
    s.text(822, 30, '«record» values passed everywhere', size=9.5, fill=C['mut'], anchor='middle')
    vals = [('Request(clientId, endpoint, int cost)', C['txt']), ('  of(clientId, endpoint): cost 1', C['mut']),
            ('Limit(int permits, long windowMillis)', C['txt']), ('  perSecond(n) · perMinute(n)', C['mut']),
            ('Decision(boolean allowed, long remaining,', C['txt']), ('         long retryAfterMillis, String ruleId)', C['txt']),
            ('  allow(left) · deny(wait) · by(ruleId)', C['mut']), ('  NEVER = -1: it can never fit', C['mut'])]
    for i, (t, f) in enumerate(vals):
        s.text(672, 52 + i * 17, t, size=10.5, fill=f)
    ub(s, 16, 214, 240, 'DecisionListener', methods=['onDecision(Request, Decision)'], kind='interface')
    ub(s, 355, 214, 310, 'RateLimiterService', ['rules: RuleBook', 'store: BucketStore', 'clock: Clock',
                                                 'listeners: List<DecisionListener>'],
       ['check(Request): Decision', 'addListener(DecisionListener)'])
    ub(s, 764, 214, 220, 'Clock', methods=['millis(): long'], kind='interface')
    ub(s, 16, 304, 240, 'RefusalCounter', ['byRule: Map<String, LongAdder>'], ['onDecision(request, d)', 'refusedBy(ruleId): long'])
    ub(s, 764, 304, 106, 'SystemClock', methods=['millis()'])
    ub(s, 878, 304, 106, 'ManualClock', ['now: long'], ['advance(ms)'])
    ub(s, 16, 440, 200, 'RuleBook', ['rules: List<Rule>, in order'], ['rulesFor(Request): List<Rule>'])
    ub(s, 250, 440, 220, 'Rule', ['id: String', 'appliesTo: Predicate<Request>', 'scope: Scope', 'limit: Limit',
                                  'algorithm: Algorithm'], kind='record')
    ub(s, 16, 560, 200, 'Plans', ['byClient: Map<String, Plan>'], ['of(clientId): Plan', 'set(clientId, plan)'])
    ub(s, 16, 680, 200, 'Plan', ['FREE · PRO'], kind='enum')
    ub(s, 250, 590, 220, 'Scope', ['CLIENT', 'CLIENT_ENDPOINT', 'GLOBAL'], ['key(Request): String'], kind='enum')
    ub(s, 500, 470, 220, 'Bucket', methods=['tryTake(cost, now): Decision', 'refund(cost, now)'], kind='interface')
    ub(s, 500, 580, 220, 'TokenBucket', ['capacity: int', 'windowMillis: long', 'tokens: double', 'lastRefillMillis: long'],
       ['synchronized tryTake(cost, now)', 'synchronized refund(cost, now)', 'refill(now)'])
    ub(s, 764, 440, 220, 'BucketStore', methods=['bucket(Rule, key, now): Bucket'], kind='interface')
    ub(s, 764, 528, 220, 'LocalBucketStore', ['buckets: ConcurrentHashMap', '  key: "ruleId|scope key"'],
       ['bucket(rule, key, now)'])
    ub(s, 764, 650, 220, 'Algorithm', methods=['newBucket(Limit, now): Bucket'], kind='interface')

    def lab(x, y, t, fill=None, anchor='middle'):
        s.text(x, y, t, size=9.5, fill=fill or C['dim'], anchor=anchor)
    s.line([(510, 90), (510, 116)], end='arr'); lab(516, 107, 'calls', anchor='start')
    s.line([(390, 52), (238, 52)], end='arr'); lab(314, 46, 'returns')
    s.line([(510, 214), (510, 181)], end='tri')
    s.line([(355, 244), (258, 244)], end='arr'); lab(306, 238, 'tells')
    s.line([(136, 304), (136, 277)], end='tri')
    s.line([(665, 244), (762, 244)], **G); lab(713, 238, 'passed in', C['green'])
    s.line([(817, 304), (817, 277)], end='tri'); s.line([(931, 304), (931, 277)], end='tri')
    s.line([(400, 350), (400, 412), (116, 412), (116, 438)], **G); lab(258, 406, 'passed in', C['green'])
    s.line([(640, 350), (640, 412), (874, 412), (874, 438)], **G); lab(757, 406, 'passed in', C['green'])
    s.line([(580, 350), (580, 468)], end='arr'); lab(586, 452, 'tryTake · refund', anchor='start')
    s.line([(216, 478), (248, 478)], end='arr')
    s.line([(360, 561), (360, 588)], end='arr')
    s.line([(250, 548), (233, 548), (233, 600), (218, 600)], dash='2 3', end='arr')
    s.line([(116, 651), (116, 678)], end='arr')
    s.line([(874, 528), (874, 503)], end='tri')
    s.line([(764, 538), (722, 538)], start='dia', end='arr')
    s.line([(874, 619), (874, 648)], end='arr'); lab(880, 638, 'asks it', anchor='start')
    s.line([(764, 680), (722, 680)], **P); lab(743, 673, 'makes', C['acc'])
    s.line([(610, 580), (610, 548)], end='tri')
    y = 762
    s.line([(16, y), (46, y)], end='tri'); lab(52, y + 4, 'implements', C['mut'], 'start')
    s.line([(140, y), (170, y)], start='dia', end='arr'); lab(176, y + 4, 'owns: one per rule and key', C['mut'], 'start')
    s.line([(350, y), (380, y)], **G); lab(386, y + 4, 'passed in through the constructor', C['mut'], 'start')
    s.line([(580, y), (610, y)], **P); lab(616, y + 4, 'creates', C['mut'], 'start')
    s.line([(676, y), (706, y)], end='arr'); lab(712, y + 4, 'calls, holds or returns', C['mut'], 'start')
    s.line([(856, y), (886, y)], dash='2 3', end='arr'); lab(892, y + 4, 'may ask', C['mut'], 'start')
    lab(16, y + 24, 'Box outlines: blue dashed = interface, teal = record or enum, grey = class.', C['mut'], 'start')
    return s.render('Every class of the core, with its fields and methods').replace('<text ', '<text xml:space="preserve" ')


# ----------------------------------------------------------------------------- the sequence diagram
def sequence(parts, events, w, title):
    """A UML sequence diagram. parts: [(id, name, x)]. events, one row each:
    ('in', to, label)  a request from outside     ('out', frm, label)  the reply to outside
    ('call', a, b, label)  a call; b stays active until its ('ret', b, a, label)
    ('call0', a, b, label) a call with no reply drawn   ('frag', kind, cond, a, b) ... ('end',)  a fragment"""
    X = {p: x for p, _, x in parts}
    top, row = 72, 29
    ys, y, frags = [], top, []
    for e in events:                                           # y of each row
        y += {'frag': 30, 'end': 12}.get(e[0], row)
        ys.append(y)
    h = y + 62
    s = Svg(w, h)
    for p, name, x in parts:                                   # heads and lifelines
        bw = len(name) * 7.2 + 20
        s.rect(x - bw / 2, 14, bw, 30, fill=C['sur'], stroke=C['line'], sw=1.4)
        s.text(x, 34, name, size=11, anchor='middle', weight='600')
        s.line([(x, 44), (x, h - 44)], stroke=C['line'], sw=1, dash='4 4')
    # activation bars: from a call (or the request) to its reply
    open_, bars = {}, []
    for e, y in zip(events, ys):
        if e[0] == 'in':
            open_.setdefault(e[1], []).append(y)
        elif e[0] == 'out':
            bars.append((e[1], open_[e[1]].pop(), y))
        elif e[0] == 'call':
            open_.setdefault(e[2], []).append(y)
        elif e[0] == 'ret':
            bars.append((e[1], open_[e[1]].pop(), y))
        elif e[0] == 'call0':
            bars.append((e[2], y, y + 14))
    for p, y0, y1 in bars:
        s.rect(X[p] - 5, y0, 10, y1 - y0, fill=C['sur2'], stroke=C['mut'], rx=1, sw=1)
    # fragments: drawn first, so arrows sit on top
    stack = []
    for e, y in zip(events, ys):
        if e[0] == 'frag':
            stack.append((e, y))
        elif e[0] == 'end':
            (f, y0) = stack.pop()
            depth = len(stack)                                 # an inner fragment sits inside the outer one
            x0, x1 = X[f[3]] - 56 + 12 * depth, X[f[4]] + 50 - 12 * depth
            s.rect(x0, y0 - 20, x1 - x0, y - y0 + 26, fill='none', stroke=C['acc'], rx=3, sw=1.2)
            tw = len(f[1]) * 7 + 16
            s.add(f'<path d="M{x0} {y0 - 20} h{tw} v12 l-7 7 h{-(tw - 7)} z" fill="{C["sur"]}" stroke="{C["acc"]}" stroke-width="1.2"/>')
            s.text(x0 + 7, y0 - 6, f[1], size=10.5, fill=C['acc'], weight='700')
            s.text(x0 + tw + 8, y0 - 6, '[' + f[2] + ']', size=10.5, fill=C['acc'])
    for e, y in zip(events, ys):                               # messages
        k = e[0]
        if k in ('call', 'call0', 'ret'):
            a, b, label = e[1], e[2], e[3]
            dx = 5 if X[b] > X[a] else -5
            x0, x1 = X[a] + dx, X[b] - dx
            ret = k == 'ret'
            s.line([(x0, y), (x1, y)], stroke=C['mut'] if ret else C['txt'], sw=1.2, dash='5 3' if ret else None, end='arr')
            s.text((x0 + x1) / 2, y - 6, label, size=10, fill=C['mut'] if ret else C['txt'], anchor='middle')
        elif k == 'in':
            s.line([(8, y), (X[e[1]] - 6, y)], stroke=C['txt'], sw=1.2, end='arr')
            for i, part in enumerate(reversed(e[2].split('\n'))):
                s.text(12, y - 6 - i * 14, part, size=10, fill=C['txt'])
        elif k == 'out':
            s.line([(X[e[1]] - 6, y), (8, y)], stroke=C['mut'], sw=1.2, dash='5 3', end='arr')
            s.text(12, y - 6, e[2], size=10, fill=C['mut'])
    s.text(8, h - 18, 'Solid arrow: a call. Dashed arrow: its answer. A narrow box on a lifeline: that object is working. '
                      'loop and break are UML fragments: break ends the loop.', size=9.5, fill=C['dim'])
    return s.render(title)


def fig_seq():
    parts = [('api', 'ApiFilter', 150), ('svc', 'RateLimiterService', 300), ('clk', 'Clock', 438), ('book', 'RuleBook', 538),
             ('scope', 'Scope', 636), ('store', 'BucketStore', 742), ('bucket', 'Bucket', 852), ('lst', 'DecisionListener', 968)]
    events = [
        ('in', 'api', 'weather-widget:\nGET /search'),
        ('call', 'api', 'svc', 'check(request)'),
        ('call', 'svc', 'clk', 'millis()'),
        ('ret', 'clk', 'svc', 'now'),
        ('call', 'svc', 'book', 'rulesFor(request)'),
        ('ret', 'book', 'svc', '[free-plan, search, global]'),
        ('frag', 'loop', 'for each rule, in order', 'svc', 'bucket'),
        ('call', 'svc', 'scope', 'key(request)'),
        ('ret', 'scope', 'svc', 'key'),
        ('call', 'svc', 'store', 'bucket(rule, key, now)'),
        ('ret', 'store', 'svc', 'the bucket, created on first use'),
        ('call', 'svc', 'bucket', 'tryTake(cost, now)'),
        ('ret', 'bucket', 'svc', 'Decision: allowed, or refused'),
        ('frag', 'break', 'the bucket refused', 'svc', 'bucket'),
        ('call0', 'svc', 'bucket', 'refund(cost, now) on every bucket that took the cost'),
        ('end',),
        ('end',),
        ('call0', 'svc', 'lst', 'onDecision(request, decision)'),
        ('ret', 'svc', 'api', 'Decision'),
        ('out', 'api', '429, Retry-After: 1'),
    ]
    return sequence(parts, events, 1040, 'One request, step by step: weather-widget searches, and its search budget is used up')
