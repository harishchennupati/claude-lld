STEPS = [
dict(id='s0', stage='Scale', title='Many servers: why local counts fail, and the options',
think="""
<p class="ask">“We run twelve copies of the service behind a load balancer. <code>weather-widget</code> is limited to 100 requests a minute. How many can it actually make?”</p>
<p>Up to 1,200 a minute. Each server has its own <code>LocalBucketStore</code>, so each one gives the widget a full budget of 100. A limit only holds if every server counts from the same budget.</p>
{{svg:s_problem}}
<table>
<tr><th>option</th><th>how it works</th><th>where it breaks</th></tr>
<tr><td>divide the limit</td><td>Each server allows 100 ÷ 12, about 8 a minute.</td><td>Traffic is never spread evenly. A client whose requests reach only 2 servers gets 17 a minute instead of 100.</td></tr>
<tr><td>sticky routing</td><td>The load balancer sends each client to the same server every time.</td><td>When that server dies, or the fleet grows, its clients start again with fresh budgets elsewhere.</td></tr>
<tr><td><b>a shared store</b></td><td><b>Every bucket lives in Redis, and one script refills, checks and takes in a single step.</b></td><td>Redis itself can be slow or down. The next two steps deal with that.</td></tr>
<tr><td>leasing on top</td><td>Each server takes tokens from the shared store in batches, and spends them locally.</td><td>A server may hold tokens it does not use, so a few requests are refused a little early.</td></tr>
<tr><td>sharing counts</td><td>Servers tell each other their counts every second.</td><td>Up to a second of extra requests, and complex to run.</td></tr>
</table>
<p><b>Where it goes:</b> a new <code>BucketStore</code>. The service, the rules, the scopes, the refunds and the listeners stay exactly as they are. This is the pay-off of giving "where the buckets live" its own interface.</p>
""",
hot='BucketStore', file=('e5', None)),

dict(id='s1', stage='Scale', title='A shared store: buckets in Redis',
think="""
<p class="lands">Where it goes: a new <b>BucketStore</b> and a new <b>Bucket</b>. The service does not change.</p>
<p><code>RedisBucketStore</code> returns a <code>RedisTokenBucket</code> for each rule and key. That bucket is a <b>proxy</b>: it looks like a local bucket, but its numbers live in Redis, in a hash, and <code>tryTake</code> runs a small Lua script inside Redis. Redis runs one script at a time, so the refill, the check and the take cannot interleave, even when requests come from different servers. The script does for the whole fleet what <code>synchronized</code> did inside one process.</p>
{{svg:s_redis}}
<p>The script does the same arithmetic as <code>TokenBucket</code>. It reads the tokens and the time of the last update, and a key that doesn't exist yet starts full. It adds the tokens earned since then, takes the cost or works out the wait, saves both numbers, and returns three: allowed or not, the tokens left, and the wait. The Java side turns those three numbers back into a <code>Decision</code>, so the service cannot tell that the bucket is remote.</p>
<ul>
<li><b>Redis's clock, not the server's.</b> The script reads the time with Redis's <code>TIME</code> command. The twelve servers' clocks differ by a few milliseconds, and one budget needs one clock.</li>
<li><b>Idle keys delete themselves.</b> The script sets each key to expire after one window, with <code>PEXPIRE</code>. An idle bucket would be full anyway, so this is follow-up 5, done by Redis.</li>
<li><b>A refund is a second, smaller script,</b> so a refused request still uses no budget.</li>
<li><b><code>{weather-widget}</code> in the key is a hash tag.</b> In Redis Cluster, keys with the same tag are stored on the same node, so all of one client's buckets sit together.</li>
</ul>
""",
code=[('s1', 'diff', '')], out=('s1', 's1'),
after="""<div class="hole limit">Every rule is now a network round trip of about half a millisecond, so three rules add about 1.5 milliseconds to each request. Step 23 cuts that down. <span class="mut">The Lua was run under Lua 5.1, the version inside Redis, against a stand-in for TIME, HMGET, HSET and PEXPIRE. The Java side ran against a stand-in that handles one call at a time, as Redis does.</span></div>""",
new='RedisBucketStore,RedisTokenBucket', hot='BucketStore,Bucket', pattern=[('Proxy', 'RedisTokenBucket: looks like a local bucket, but its numbers live in Redis')],
file=('s1', None), practice=('RedisBucketStore and RedisTokenBucket', 12)),

dict(id='s2', stage='Scale', title='When Redis is slow or down: fail open or closed, with a circuit breaker',
think="""
<p class="ask">“Redis starts timing out. What happens to every request?”</p>
<p class="lands">Where it goes: a wrapper around <b>Bucket</b>, which <b>RedisBucketStore</b> puts around every bucket it returns.</p>
<p>Without care, every request waits for Redis to time out and then fails, so a problem in the rate limiter takes the whole API down. Two decisions prevent that.</p>
<p><b>A policy for each rule.</b> Most rules <b>fail open</b>: when Redis cannot answer, the request is allowed, because a few minutes over the limit is better than an outage. The login rule <b>fails closed</b>: the request is refused, because a password-guessing attack must not get through while Redis is down.</p>
<p><b>A circuit breaker.</b> After 3 failures in a row, the breaker opens. For the next 5 seconds nobody calls Redis, and every request is answered at once from its rule's policy. When the 5 seconds are over, the next request tries Redis again.</p>
{{svg:s_breaker}}
<p>Both are wrappers, so the service still knows nothing about Redis. <code>FallbackBucket</code> wraps each Redis bucket, and all the buckets from one store share one <code>Breaker</code>.</p>
""",
code=[('s2', 'diff', '')], out=('s2', 's2'),
after="""<div class="hole limit">Failing open means the limits are off while Redis is down. Raise an alert when that happens, and keep a rough limit on each server as a backstop, for example the global limit divided by 12.</div>""",
new='FallbackBucket,Breaker', hot='RedisBucketStore', pattern=[('Decorator', 'FallbackBucket wraps any remote bucket')], file=('s2', None), practice=('FallbackBucket and Breaker', 10)),

dict(id='s3', stage='Scale', title='Fewer round trips: lease tokens in batches',
think="""
<p class="ask">“Every request on every server hits the one global key in Redis, and every rule costs a round trip. Make it cheaper.”</p>
<p class="lands">Where it goes: a wrapper around <b>BucketStore</b>, and one around <b>Bucket</b>. Nothing else changes.</p>
<p><code>LeasingStore</code> wraps any store. On each server it keeps a <code>LeasedBucket</code> for each rule and key, which takes tokens from Redis <b>ten at a time</b> and hands them out locally until they run out. The limit still holds, because a token is always taken from Redis before it is spent. In the demo, 300 requests needed 16 calls to Redis instead of 300.</p>
{{svg:s_lease}}
<p><b>How <code>LeasedBucket</code> works.</b> If it holds enough leased tokens, it spends them without asking Redis. If not, it asks Redis for a batch of 10, or for just the tokens that are missing when a whole batch isn't available. When Redis refuses, the bucket remembers the retry time and refuses locally until then, so a busy key is not asked again and again. A refund goes back to this server's lease, where the next request can use it.</p>
""",
code=[('s3', 'diff', '')], out=('s3', 's3'),
after="""<div class="hole limit">A server can hold unused tokens while another server refuses, so a client may be refused a little early. Keep batches small compared with the limit, and give back leases that a server has not used for a while.</div>
<p><b>Other questions they may ask.</b></p>
<ul>
<li><b>Redis fails over to a replica.</b> The last few writes can be lost, so some budgets may briefly reset. Accept that.</li>
<li><b>Several regions.</b> Give each region its own limit, or split one global limit between the regions.</li>
<li><b>Clocks that differ between servers.</b> They don't matter, because the script uses Redis's clock.</li>
<li><b>Memory in Redis.</b> About 100 bytes per bucket, and <code>PEXPIRE</code> removes the idle ones.</li>
</ul>""",
new='LeasingStore,LeasedBucket', hot='BucketStore,Bucket', file=('s3', None), practice=('LeasedBucket and LeasingStore', 10)),
]
