T_RULES = 'Request,Limit,Decision,Clock,SystemClock,ManualClock,Bucket,Algorithm,TokenBucket,Plan,Plans,Scope,Rule,RuleBook'
T_STORE = T_RULES + ',BucketStore,LocalBucketStore'
T_SERVICE = T_STORE + ',RateLimiter,DecisionListener,RefusalCounter,RateLimiterService'
T_EDGE = T_SERVICE + ',Response,ApiFilter'

STEPS = [
dict(id='b-store', stage='Build', title='BucketStore: finding the bucket for a rule and a client',
think="""
<p>Every check needs the bucket for a rule and a key, such as the <code>free-plan</code> bucket of <code>weather-widget</code>. <code>BucketStore</code> is the interface that finds that bucket, or creates it the first time it is needed. It is an interface because where the buckets live is exactly what changes when there are many servers: they move to Redis, and only this part is replaced.</p>
<p><code>LocalBucketStore</code> keeps the buckets in memory, in a <code>ConcurrentHashMap</code> from a string key to a bucket. The key joins the rule's id and the scope's key, for example <code>"free-plan|weather-widget"</code>. That way each rule has its own buckets, even when two rules count the same client.</p>
<p>A bucket must be created exactly once, even when two threads see a new client at the same moment. <code>computeIfAbsent</code> does the lookup and the insert as one atomic step: the first thread creates the bucket, and the second thread gets that same bucket. The new bucket is made by the rule's algorithm, so the store never needs to know what kind of bucket it holds.</p>
<div class="trap mistake">Calling <code>get</code>, and then <code>put</code> if nothing was found. Two threads can both find nothing, and each creates a full bucket. The client then has two budgets: 10 requests where the limit is 5. The race in step 11 catches this on every run.</div>
""",
code=[('core', 'BucketStore,LocalBucketStore', 'BucketStore, LocalBucketStore')],
hot='BucketStore,LocalBucketStore', file=('core', T_STORE), practice=('BucketStore and LocalBucketStore', 3)),

dict(id='b-service', stage='Build', title='RateLimiterService: checking every rule, or none',
think="""
<p><code>RateLimiterService</code> runs one check from start to finish. It implements <code>RateLimiter</code>, the one-method interface that the API depends on. Its rule book, bucket store and clock are passed in through the constructor, so a test can pass a manual clock, and production can later pass a Redis store. It keeps no counts and takes no lock of its own: it only coordinates the objects that do.</p>
<p><b>What <code>check</code> does.</b></p>
<ol>
<li>It reads the clock once, so every rule sees the same time.</li>
<li>It asks the rule book for the rules that cover the request, in order.</li>
<li>For each rule, it gets the key from the rule's scope, gets the bucket from the store, and tries to take the request's cost. It remembers every bucket that allowed the request.</li>
<li>If a bucket refuses, the service gives the cost back to every bucket it remembered, stops, and answers with the refusal, labelled with that rule's id.</li>
<li>If every rule allows the request, the answer is allowed, and the budget left is the smallest among the rules. The widget may have 4 requests left under <code>free-plan</code> but only 1 under <code>search</code>, so it really has 1.</li>
<li>Last, it tells each listener about the decision.</li>
</ol>
{{svg:refund}}
<p><b>Why this is safe with many threads.</b> Each bucket holds its own lock, and only inside its own methods. The service never holds one bucket's lock while it calls another, so two checks can never deadlock. The one gap is the moment between taking a token and refunding it: another request for the same client can see one token fewer and be refused, although in the end there was room. That can refuse a request early, rarely, but it can never let too many through.</p>
<p><b>Listeners</b> are told after the decision is made, outside every lock, and each call is wrapped in a <code>try</code>, so a broken dashboard can never break the API. The listener list is a <code>CopyOnWriteArrayList</code>, a list that makes a fresh copy whenever something is added. Listeners are added rarely and read on every request, and this list can be read without any locking. <code>RefusalCounter</code> is an example listener that counts refusals per rule. It uses a <code>LongAdder</code>, a counter that many threads can increase at the same time without slowing each other down.</p>
<div class="trap mistake">Checking every rule first, and taking from the buckets afterwards. Between the check and the take, other threads can spend the tokens you saw, and the request goes over the limit. The take has to be the check.</div>
""",
code=[('core', 'RateLimiter,DecisionListener,RefusalCounter,RateLimiterService', 'RateLimiter, DecisionListener, RefusalCounter, RateLimiterService')],
hot='RateLimiter,DecisionListener,RefusalCounter,RateLimiterService',
pattern=[('Observer', 'DecisionListener: the limiter tells listeners about decisions without knowing who they are'), ('Dependency injection', 'the service is given its rule book, store and clock')],
file=('core', T_SERVICE), practice=('RateLimiterService.check, with the refund', 8)),

dict(id='b-edge', stage='Build', title='ApiFilter: turning a decision into an HTTP response',
think="""
<p>The rate limiter knows nothing about HTTP; only <code>ApiFilter</code> does. It calls <code>check</code>, and then builds the response:</p>
<ul>
<li>If the request is allowed, the status is 200, and an <code>X-RateLimit-Remaining</code> header shows the budget left.</li>
<li>If it is refused, the status is 429. <code>Retry-After</code> gives the wait in whole seconds, rounded up: 120 milliseconds becomes 1 second, because rounding down to 0 would make the client retry too early. <code>X-RateLimit-Rule</code> names the limit it hit.</li>
<li>If the request can never fit, the status is 429 with no <code>Retry-After</code>, so the client does not keep retrying a request that can never pass.</li>
</ul>
<p>The filter depends on the <code>RateLimiter</code> interface, not on the service, so it works unchanged with every wrapper that the follow-ups add. And because HTTP stays here, the same limiter could sit behind a gRPC server or a message queue.</p>
""",
code=[('core', 'Response,ApiFilter', 'Response, ApiFilter')],
hot='ApiFilter', pattern=[('Adapter', 'ApiFilter turns a Decision into an HTTP response')], file=('core', T_EDGE), practice=('ApiFilter', 3)),

dict(id='b-main', stage='Build', title='Main: wiring it up, and proving it with a race',
think="""
<p><code>main</code> creates the objects the way production would, and then checks the promises the design makes. Each check throws an error if it fails, so a wrong result cannot go unnoticed.</p>
<p><b>The story.</b> Time starts at 0 on a manual clock, and <code>travel-app</code> is put on the Pro plan.</p>
<ul>
<li><code>weather-widget</code> sends 7 requests at once. The first 5 pass, and the last 2 are refused by <code>free-plan</code>, with a retry time of 200 milliseconds.</li>
<li><code>travel-app</code> searches 3 times. Two searches pass, and the third is refused by <code>search</code>. The <code>pro-plan</code> token that the third search had taken is given back, so the app's next request shows 47 left, not 46.</li>
<li>Through the filter, a refused request becomes a 429 with <code>Retry-After: 1</code>.</li>
<li>One second later the widget's bucket is full again. A request that costs 3 passes. A request that costs 6 can never fit a limit of 5, so it is refused with no retry time.</li>
</ul>
<p><b>The race.</b> 100 threads send 1,000 requests each, spread over 100 clients, while the clock stands still. Each client may make 500 requests a day, 50,000 in total, but a global limit allows only 30,000 a minute. Exactly 30,000 requests must pass, on every run. Then the clock moves forward a minute, and each client should be able to spend exactly the part of its 500 that it has not used: 20,000 requests in all. That second number is right only if every request the global rule refused was refunded to its client's bucket.</p>
<p><b>Breaking it on purpose.</b> To show that the race really catches mistakes, the build also runs it on three broken copies of the code. Without <code>synchronized</code> in the bucket: {{mutant:nolock}}. With <code>get</code> and then <code>put</code> in the store: {{mutant:getput}}. Without the refund: {{mutant:norefund}}.</p>
""",
code=[('core', 'Main', 'Main')], out=('core', None),
hot='', file=('core', None), practice=('Main: the story and the race', 10)),
]
