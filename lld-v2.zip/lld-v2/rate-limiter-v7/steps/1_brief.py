STEPS = [
dict(id='problem', stage='Brief', wide=True, title='The problem',
think="""
<p class="ask">“We sell a weather data API to other companies. Every request carries the caller's API key. Clients on the Free plan get a small limit, and clients on the Pro plan get a bigger one. Searching for a city by name is expensive, so search has its own, tighter limit. And the API as a whole must never take more traffic than our servers can handle. Some calls cost more than one unit. Design the rate limiter and write working code. It must be correct with many threads now, and with many servers later.”</p>

<p><b>What we are building.</b> A rate limiter sits in front of the API. Before the API does any work for a request, it asks the rate limiter whether the request may go ahead. The answer is either <span class="ok">allowed</span>, with how much of the client's budget is left, or <span class="no">refused</span>, with how long the client should wait and which limit it hit. The API turns a refusal into the HTTP status 429 Too Many Requests, with a <code>Retry-After</code> header that tells the client when to try again.</p>
<p>One request can fall under several limits at once. When a Free client searches, the search counts against the Free plan's limit, the search limit and the limit for the whole API. It may go ahead only if all three allow it.</p>

<p><b>Questions to ask before designing.</b> Interviewers leave details open on purpose, to see whether you ask. If they say "you decide", state the assumption and move on.</p>
<table>
<tr><th>question</th><th>what we assume</th><th>what it changes in the design</th></tr>
<tr><td>One server, or many servers sharing the limits?</td><td>One process for now, many servers later.</td><td>The place where counts are kept must be easy to replace.</td></tr>
<tr><td>What do we limit by: API key, IP address or endpoint?</td><td>The API key, and also per endpoint, and also one limit for the whole API.</td><td>Each limit must say whose budget a request uses.</td></tr>
<tr><td>Does every client get the same limit?</td><td>No. There are Free and Pro plans.</td><td>There is one limit for each plan.</td></tr>
<tr><td>Can one call cost more than one unit?</td><td>Yes. An export costs 3.</td><td>Every request carries a cost.</td></tr>
<tr><td>Does a refused request still use up budget?</td><td>No, it uses no budget from any limit.</td><td>When one limit refuses, the budget the other limits took is given back.</td></tr>
<tr><td>May a client send a burst, or must requests be evenly spaced?</td><td>Short bursts, up to the limit, are fine.</td><td>We need a counting method that allows bursts.</td></tr>
<tr><td>When a request is refused, should the caller wait, or fail?</td><td>Fail at once, and say when to retry.</td><td>Every refusal carries a retry time.</td></tr>
</table>

<p><b>What the rate limiter must do.</b></p>
<ul>
<li>For each request, answer allowed, with the budget left, or refused, with how long to wait and which limit refused it.</li>
<li>Read its limits from configuration. Each limit says which requests it covers (one plan, one endpoint, or every request), whose budget it counts against (one client, one client on one endpoint, or everyone together), how many units it allows in a period, and how it counts them.</li>
<li>Let a request through only if every limit that covers it allows it. A refused request must use no budget from any limit.</li>
<li>Allow short bursts up to the limit, and handle requests that cost more than one unit.</li>
</ul>
<p><b>How well it must do it.</b></p>
<ul>
<li><b>Correct under load.</b> However many threads call it at once, no limit is ever exceeded, and one client's traffic never makes another client wait.</li>
<li><b>Fast and small.</b> A check does a fixed amount of work for each limit, and memory is used only for clients that are active.</li>
<li><b>Easy to extend.</b> A new counting method, a store shared by many servers, or a dashboard that watches refusals can be added without editing the code that already exists.</li>
<li><b>Easy to test.</b> Tests control the clock, so they never have to sleep.</li>
</ul>

<p><b>The example used on every step.</b> Two clients call the API. <code>weather-widget</code> is a small widget that websites embed, on the Free plan. <code>travel-app</code> is a busy travel booking app, on the Pro plan. Four limits apply:</p>
<table>
<tr><th>limit</th><th>it covers</th><th>it counts separately for</th><th>it allows</th></tr>
<tr><td><code>free-plan</code></td><td>requests from Free clients</td><td>each client</td><td>5 a second</td></tr>
<tr><td><code>pro-plan</code></td><td>requests from Pro clients</td><td>each client</td><td>50 a second</td></tr>
<tr><td><code>search</code></td><td>requests to <code>/search</code></td><td>each client</td><td>2 a second</td></tr>
<tr><td><code>global</code></td><td>every request</td><td>everyone together</td><td>100 a second</td></tr>
</table>
<p>So when <code>weather-widget</code> searches, three limits apply to that one request: <code>free-plan</code>, <code>search</code> and <code>global</code>.</p>
"""),

dict(id='algorithm', stage='Brief', wide=True, title='How to count: why a token bucket',
think="""
<p><b>The first idea is a counter that resets every minute.</b> Keep a count for each client, and set it back to zero at the start of every minute. It is simple, but it breaks at the edge between two minutes. Say the limit is 100 a minute. <code>weather-widget</code> sends 100 requests at 12:00:59.9, and all of them pass. The counter resets at 12:01:00, and the widget sends 100 more at 12:01:00.1. They all pass too: 200 requests in 0.2 seconds, twice the limit.</p>
{{svg:edge}}
<p><b>The four usual ways to count.</b></p>
<table>
<tr><th>method</th><th>how it counts</th><th>what it keeps for each client</th><th>its weakness</th><th>good for</th></tr>
<tr><td>fixed window</td><td>a counter that resets every minute</td><td>a count, and the minute it belongs to</td><td>twice the limit can pass at the edge of two minutes</td><td>daily quotas, where the edge doesn't matter</td></tr>
<tr><td>sliding window log</td><td>the time of every request; counts those in the last minute</td><td>one time for every request</td><td>memory grows with the limit</td><td>small limits that must be exact, such as logins</td></tr>
<tr><td>sliding window counter</td><td>this minute's count plus a share of the last minute's</td><td>two counts</td><td>an estimate, not exact</td><td>large limits where close is good enough</td></tr>
<tr><td><b>token bucket</b></td><td>tokens that flow back in at a steady rate</td><td>two numbers: the tokens left, and when they were last updated</td><td>a client that has been quiet can send a full burst at once</td><td><b>APIs: it allows bursts, handles costs, and says exactly when to retry</b></td></tr>
</table>
<p><b>How a token bucket works.</b> Picture a bucket that holds at most 5 tokens. Each request takes one token, or more if it costs more. Tokens flow back in at a steady rate, 5 a second, which is one every 200 milliseconds, but the bucket never holds more than 5. A client that has been quiet has a full bucket, so it can send 5 requests at once. After that it can send one request every 200 milliseconds. Over any longer period, it averages at most 5 a second.</p>
{{svg:bucket}}
<p>No timer is needed to refill the bucket. We keep two numbers: the tokens left, and the time we last updated them. When a request arrives, we first add the tokens earned since then, which is the time passed multiplied by the refill rate. When a request is refused, the same two numbers tell us exactly how long until enough tokens are back.</p>
<p><b>The choice.</b> The token bucket is the default. The rest of the design will not depend on it, though: each limit names its own counting method, and follow-up 1 adds the exact sliding window log for logins.</p>
"""),

dict(id='design', stage='Brief', wide=True, title='The design: from one call to the whole class diagram',
think="""
<p>I design outward from the one call the API makes. At each point I ask what is needed next, and each answer becomes a class.</p>

<p><b>The call.</b> The API asks one question per request, so the design starts with one method, <code>check(request)</code>. A <code>Request</code> holds who sent it, which endpoint it calls, and what it costs. The answer cannot be a plain true or false, because the API also needs the budget left, the time to wait, and the name of the limit that refused. So <code>check</code> returns a <code>Decision</code>. The API sees only an interface, <code>RateLimiter</code>, so that everything behind it can change.</p>

<p><b>The limits.</b> Limits change often: a new plan, a new expensive endpoint. If each limit were an <code>if</code> statement, every change would be a code change. So each limit is data: a <code>Rule</code> that says which requests it covers, whose budget it counts against, how many units it allows, and how it counts them. A <code>RuleBook</code> holds the rules in the order they are checked, and <code>Plans</code> records which plan each client is on.</p>

<p><b>Whose budget.</b> <code>free-plan</code> counts each client separately, <code>search</code> counts each client's searches, and <code>global</code> counts everyone together. A <code>Scope</code> turns a request into the key of the budget it uses: <code>"weather-widget"</code>, <code>"weather-widget /search"</code>, or <code>"*"</code> for everyone.</p>

<p><b>Counting one budget.</b> For each rule and key there is one object that keeps the count, and answers the question "may this request take its cost now, and if not, when?". That object is a <code>Bucket</code>. It is an interface, because the counting method can change, and <code>TokenBucket</code> is the first implementation. An <code>Algorithm</code> creates buckets, so a rule can name its counting method without the rest of the code knowing which one it is.</p>

<p><b>Where the buckets live.</b> On one server, the buckets live in a map in memory. With many servers, they must live in a shared store such as Redis. We already know this will change, so it gets its own interface, <code>BucketStore</code>, and <code>LocalBucketStore</code> is the in-memory version.</p>

<p><b>Running a check.</b> One class runs a check from start to finish: <code>RateLimiterService</code>. It gets the rules that apply, and for each one it finds the bucket and takes the cost. If a rule refuses, it gives back what the earlier rules took, so a refused request uses no budget. It keeps no counts itself; it only coordinates the classes that do.</p>

<p><b>Time and listeners.</b> Buckets need the current time, and tests need to control it, so the time comes from a <code>Clock</code> that is passed in. A dashboard wants to hear about refusals, so the service tells every registered <code>DecisionListener</code> about each decision.</p>

<p><b>HTTP at the edge.</b> Only <code>ApiFilter</code> knows about HTTP. It turns a <code>Decision</code> into a 200 or a 429 response, so the limiter itself could sit behind any other protocol.</p>

<p><b>The classes, with their fields and methods.</b></p>
{{svg:classes7}}

<p><b>One request, step by step.</b> <code>weather-widget</code> calls <code>GET /search</code>, and it has already used its 2 searches for this second. Three rules apply, and they are checked in order: <code>free-plan</code>, then <code>search</code>, then <code>global</code>.</p>
{{svg:seq}}
<p>In the first pass of the loop, the <code>free-plan</code> bucket allows the request and takes a token. In the second pass, the <code>search</code> bucket refuses. The service gives the <code>free-plan</code> token back and leaves the loop, so the <code>global</code> bucket is never touched. The listeners hear about the refusal, and the filter answers 429 with <code>Retry-After</code>.</p>

<p><b>What we leave out, and why.</b> There is no <code>Client</code> or <code>Endpoint</code> class, because each would hold a single string and no behaviour. There is no timer thread, because buckets refill when they are asked. There is no Singleton: the one limiter a process needs is created in <code>main</code>, and tests create fresh ones. And <code>RuleBook</code> and <code>Plans</code> are plain classes, not interfaces, because nothing will replace them.</p>
<p>The next steps write this code from the bottom up, so that it compiles after every step: the values, the clock, the buckets, the rules, the store, the service, the edge, and finally <code>Main</code>, which proves that it works.</p>
"""),
]
