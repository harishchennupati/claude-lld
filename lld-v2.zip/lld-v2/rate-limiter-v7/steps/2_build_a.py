T_VALUES = 'Request,Limit,Decision'
T_CLOCK = T_VALUES + ',Clock,SystemClock,ManualClock'
T_BUCKET = T_CLOCK + ',Bucket,Algorithm,TokenBucket'
T_RULES = T_BUCKET + ',Plan,Plans,Scope,Rule,RuleBook'

STEPS = [
dict(id='b-values', stage='Build', title='Request, Limit and Decision: the values passed between classes',
think="""
<p>Three small types carry data between the classes. A <code>Request</code> is one call: who sent it, which endpoint it is for, and what it costs. A <code>Limit</code> is a number of units per period, such as 5 a second. A <code>Decision</code> is the answer to a check: allowed, with the budget left, or refused, with how long to wait and which rule refused.</p>
<p>All three are Java records. A record's fields are set once, in the constructor, and never change, so any thread can read a record without a lock. Java also writes the constructor, the getters, <code>equals</code>, <code>hashCode</code> and <code>toString</code> for us.</p>
<p>Each record checks its values in a <b>compact constructor</b>, the block that runs every time one is created. A cost of 0 or a limit of 0 is rejected on the line that tried to create it, instead of causing a division by zero somewhere else later.</p>
<p>Two parts of <code>Decision</code> need a word:</p>
<ul>
<li><code>NEVER</code> is the retry time for a request that costs more than a whole bucket can hold. Waiting can never help it, so the API must not tell the client to retry.</li>
<li><code>by(ruleId)</code> returns a copy of the decision with the rule's name filled in. A bucket does not know which rule it belongs to, so the service adds the name after the bucket has answered.</li>
</ul>
<div class="trap mistake">Returning a plain <code>boolean</code> from <code>check</code>. The API then cannot tell the client when to retry, and a dashboard cannot tell which limit refused. Adding that information later means changing every caller.</div>
""",
code=[('core', 'Request,Limit,Decision', 'Request, Limit, Decision')],
hot='Request,Limit,Decision', file=('core', T_VALUES), practice=('Request, Limit, Decision', 4)),

dict(id='b-clock', stage='Build', title='Clock: where the time comes from',
think="""
<p>A bucket refills according to how much time has passed, so it needs the current time. It should not read the system clock itself, for two reasons. Tests would have to sleep to see a bucket refill, which makes them slow and unreliable. And the machine's wall clock can jump backwards when it corrects its time, which would confuse the refill.</p>
<p>So the time comes from a small interface, <code>Clock</code>, which is passed into the service when it is created:</p>
<ul>
<li>In production it is <code>SystemClock</code>, which uses <code>System.nanoTime()</code>. That value only ever moves forward. Its starting point means nothing, but we only ever subtract one reading from another, so that doesn't matter.</li>
<li>In tests it is <code>ManualClock</code>. Calling <code>advance(200)</code> moves time forward by 200 milliseconds at once, so a test can check a refill instantly and gets the same result on every run.</li>
</ul>
<p>The service reads the clock once per check and passes that time to every bucket, so all the rules in one check see the same moment.</p>
<p><code>ManualClock</code>'s field is <code>volatile</code> because the test's thread changes it while other threads read it. <code>volatile</code> makes sure those threads see the new value.</p>
""",
code=[('core', 'Clock,SystemClock,ManualClock', 'Clock, SystemClock, ManualClock')],
hot='Clock', file=('core', T_CLOCK), practice=('Clock, SystemClock, ManualClock', 3)),

dict(id='b-bucket', stage='Build', title='Bucket and TokenBucket: counting one budget',
think="""
<p>A bucket keeps the budget for one rule and one key, for example the <code>free-plan</code> budget of <code>weather-widget</code>. The rest of the code talks to it through the <code>Bucket</code> interface, which has two methods:</p>
<ul>
<li><code>tryTake(cost, now)</code> takes <code>cost</code> units if they are there, and otherwise says how long until they will be;</li>
<li><code>refund(cost, now)</code> gives units back. The service needs it when a later rule refuses a request that this bucket has already allowed.</li>
</ul>
<p>Because <code>Bucket</code> is an interface, the service never knows which counting method it is talking to. <code>Algorithm</code> is a second, one-method interface that creates a bucket for a limit. A rule stores <code>TokenBucket::new</code> as its algorithm, and the store calls it whenever it needs a new bucket.</p>

<p><b>How <code>TokenBucket</code> works.</b> The capacity and the window come from the limit: 5 per 1,000 milliseconds for <code>free-plan</code>. The bucket also tracks the tokens left and the time they were last updated, and a new bucket starts full. Each call to <code>tryTake</code> does three things:</p>
<ol>
<li><b>Refill.</b> It adds the tokens earned since the last update: the milliseconds passed × capacity ÷ window. For <code>free-plan</code>, 200 milliseconds earn 1 token. The bucket never goes above its capacity, so after 10 quiet seconds it holds 5 tokens, not 50.</li>
<li><b>Take.</b> If at least <code>cost</code> tokens are there, it subtracts them and answers allowed, with the whole tokens left.</li>
<li><b>Or say when.</b> Otherwise it works out how long until enough tokens are back: the tokens missing × the milliseconds per token. With 0.4 tokens left and a cost of 1, that is 0.6 × 200 = 120 milliseconds. It rounds up, so a client that waits exactly that long finds the token there.</li>
</ol>
<p>Here is the widget's <code>free-plan</code> bucket through a few requests:</p>
<table>
<tr><th>time</th><th>what happens</th><th>tokens before</th><th>tokens after</th><th>answer</th></tr>
<tr><td>0 ms</td><td>5 requests arrive at once</td><td>5 (a new bucket is full)</td><td>0</td><td>all 5 allowed</td></tr>
<tr><td>0 ms</td><td>a 6th request</td><td>0</td><td>0</td><td>refused, retry in 200 ms</td></tr>
<tr><td>120 ms</td><td>a request</td><td>0 + 120 × 5 ÷ 1000 = 0.6</td><td>0.6</td><td>refused, retry in 80 ms</td></tr>
<tr><td>200 ms</td><td>a request</td><td>0.6 + 80 × 5 ÷ 1000 = 1</td><td>0</td><td>allowed</td></tr>
</table>
<p>Two more rules: a request that costs more than the capacity can never pass, so it is refused at once with <code>NEVER</code>; and <code>refund</code> adds tokens back, but never above the capacity.</p>

<p><b>Three details that matter.</b></p>
<ul>
<li>The tokens are a <code>double</code>, because a refill earns fractions of a token. At 5 a second, one millisecond earns 0.005 tokens, and an <code>int</code> would round small amounts like that down to zero.</li>
<li><code>tryTake</code> and <code>refund</code> are <code>synchronized</code>. The refill, the check and the take then happen as one step for this bucket, and threads using other buckets never wait for it.</li>
<li>A thread can arrive with an older time than the last update: two threads read the clock, and the later one gets the lock first. The refill then adds nothing, rather than moving the time backwards.</li>
</ul>
<div class="trap mistake">A background thread that refills every bucket once a second. It wakes up to touch millions of idle buckets, competes with requests for their locks, and refills in jumps instead of smoothly. Working out the refill from the elapsed time, when a request arrives, needs no thread at all.</div>
""",
code=[('core', 'Bucket,Algorithm,TokenBucket', 'Bucket, Algorithm, TokenBucket')],
hot='Bucket,Algorithm,TokenBucket', pattern=[('Strategy', 'Bucket: one interface, any counting method'), ('Factory', 'Algorithm: TokenBucket::new creates a bucket')],
file=('core', T_BUCKET), practice=('Bucket, Algorithm and TokenBucket', 8)),

dict(id='b-rules', stage='Build', title='Rule, Scope, RuleBook and Plans: limits as configuration',
think="""
<p>A <code>Rule</code> is one limit, written as data. It has five parts:</p>
<ul>
<li>an <code>id</code>, such as <code>"search"</code>, which appears in refusals and on dashboards;</li>
<li><code>appliesTo</code>, a <code>Predicate&lt;Request&gt;</code>: a function that says whether the rule covers a request;</li>
<li>a <code>scope</code>, which says whose budget the request uses;</li>
<li>a <code>limit</code>, such as 2 a second;</li>
<li>an <code>algorithm</code>, which creates this rule's buckets.</li>
</ul>
<p>Because <code>appliesTo</code> is a function, any condition fits in one line: "the client is on the Free plan", "the endpoint is <code>/search</code>", or "every request". Adding a limit means adding a line of configuration, not writing a new class.</p>
<p><b><code>Scope</code></b> is an enum with three values, and each value computes a key from a request. <code>CLIENT</code> gives <code>"weather-widget"</code>, so all of the widget's calls share one budget. <code>CLIENT_ENDPOINT</code> gives <code>"weather-widget /search"</code>, so the widget's searches have a budget of their own. <code>GLOBAL</code> always gives <code>"*"</code>, so every request shares one budget. Limiting by IP address later would be one more value.</p>
<p><b><code>RuleBook</code></b> keeps the rules in the order it was given, and returns the ones that cover a request. The order matters: narrow rules come first and the global rule comes last. A client that sends too much is then stopped by its own rule, before its requests reach the global bucket that every request shares.</p>
<p><b><code>Plans</code></b> records which plan each client is on. A client that was never set up is on the Free plan, so no code has to handle a missing plan. Its map is a <code>ConcurrentHashMap</code>, because a client can change plan while its requests are being checked.</p>
""",
code=[('core', 'Plan,Plans,Scope,Rule,RuleBook', 'Plan, Plans, Scope, Rule, RuleBook')],
after="""<p>This is how the example's four rules are written, in <code>Main</code>:</p>
{{code:core:Main.exampleRules|the example's rules, in Main}}""",
hot='Plans,Scope,Rule,RuleBook', pattern=[('Strategy, as an enum', 'Scope: each value computes its own key')],
file=('core', T_RULES), practice=('Plans, Scope, Rule, RuleBook', 6)),
]
