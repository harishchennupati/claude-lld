STEPS = [
dict(id='f-concurrency', stage='Defend', title='Threads: where a race could break a limit, and what stops it',
think="""
<p>There are three places in this code where two threads running at the same moment could let through more requests than a limit allows. Each one is closed by a single line, and the race in <code>Main</code> fails on every run if that line is removed.</p>
<table>
<tr><th>where</th><th>what could go wrong</th><th>what stops it</th><th>without it, the race</th></tr>
<tr><td>inside a bucket</td><td>Two threads both read "1 token left", and both take it.</td><td><code>synchronized</code> on <code>tryTake</code> makes the refill, the check and the take one step.</td><td>{{mutant:nolock}}</td></tr>
<tr><td>in the store</td><td>Two threads find no bucket for a new client, and each creates a full one.</td><td><code>computeIfAbsent</code> makes the lookup and the insert one step.</td><td>{{mutant:getput}}</td></tr>
<tr><td>across rules</td><td>The client's rule takes a token, and then the global rule refuses the request.</td><td>The refund gives the token back.</td><td>{{mutant:norefund}}</td></tr>
</table>
{{svg:race_n}}
<p><b>Why it cannot deadlock.</b> A deadlock needs a thread that holds one lock while it waits for another. Here a bucket holds its lock only inside its own method, and the service never holds a lock while it calls a bucket.</p>
<p><b>Why <code>tokens</code> is not <code>volatile</code>.</b> Every read and write of it happens inside the bucket's lock. Java guarantees that a thread taking a lock sees everything written by the last thread that held the same lock, so <code>volatile</code> would add nothing.</p>
<p><b>How fast it is.</b> On an Apple M4 Pro with Java 17, one check takes about 66 nanoseconds with one rule, and 95 with two. Fourteen threads checking fourteen different clients make 47 million checks a second, because no two of them share a lock. Adding the global rule drops that to 7.3 million a second, because now every request takes the one global bucket's lock. Say this before the interviewer asks. It is still far more than any real API needs. If they push, split the global limit into 8 buckets of an eighth each, which is close to exact but not exact, or lease tokens in batches, as the scale-out steps do.</p>
<p><b>If they ask for a version without locks,</b> keep both numbers in one immutable object and replace it with <code>compareAndSet</code>. That call replaces the object only if it is still the one this thread read. If another thread changed it in between, the call fails, and the loop reads the new object and tries again. This version passes the same race.</p>
""",
code=[('extra', 'CasTokenBucket', 'CasTokenBucket: the bucket without locks, if they ask')],
hot='TokenBucket,LocalBucketStore,RateLimiterService', file=('core', None), practice=('the lock-free CasTokenBucket', 8)),

dict(id='f-principles', stage='Defend', title='Design principles and patterns in this code',
think="""
<p>Interviewers often ask which principles a design follows. The useful answer names the class where each one shows.</p>
<table>
<tr><th>principle</th><th>where it shows in this code</th></tr>
<tr><td>Single responsibility</td><td>Each class has one job. The bucket counts, the store finds buckets, the rule book knows the rules, the service coordinates, and the filter speaks HTTP.</td></tr>
<tr><td>Open/closed</td><td>Every follow-up and every scale-out step was added as new classes or new methods. The core of <code>check</code> never changed.</td></tr>
<tr><td>Liskov substitution</td><td>Any <code>Bucket</code> can stand in for another: token, log, Redis, fallback or leased. The same is true of every <code>BucketStore</code>, and no caller checks which one it has.</td></tr>
<tr><td>Interface segregation</td><td>Every interface has one or two methods: <code>RateLimiter</code>, <code>Bucket</code>, <code>BucketStore</code>, <code>Algorithm</code>, <code>Clock</code> and <code>DecisionListener</code>.</td></tr>
<tr><td>Dependency inversion</td><td>The service depends on those interfaces, and the real classes are passed in. That is how a test passes a <code>ManualClock</code>, and how production passes a Redis store.</td></tr>
<tr><td>Tell, don't ask</td><td>The service tells a bucket to <code>tryTake</code>. It never reads the tokens and decides for the bucket.</td></tr>
<tr><td>Composition over inheritance</td><td>No class extends another. Behaviour is combined by wrapping: a fallback bucket wraps a Redis bucket, and a leasing store wraps another store.</td></tr>
<tr><td>Immutability</td><td><code>Request</code>, <code>Limit</code>, <code>Decision</code> and <code>Rule</code> are records, and the rule book is replaced whole, never edited.</td></tr>
<tr><td>Keep it simple</td><td>No Singleton, no timer thread, no factory class, no <code>Client</code> class, and no interface where nothing will be swapped.</td></tr>
</table>
<table>
<tr><th>pattern</th><th>where</th><th>why it is here</th></tr>
<tr><td>Strategy</td><td><code>Bucket</code> (how to count) and <code>Scope</code> (whose budget)</td><td>These are the two things that vary from rule to rule.</td></tr>
<tr><td>Factory</td><td><code>Algorithm</code>, as in <code>TokenBucket::new</code></td><td>A rule can create its buckets without the store naming a class.</td></tr>
<tr><td>Observer</td><td><code>DecisionListener</code></td><td>Dashboards hear about decisions without the limiter knowing about them.</td></tr>
<tr><td>Decorator</td><td><code>ShadowLimiter</code>, <code>FallbackBucket</code>, <code>LeasingStore</code></td><td>Each adds behaviour around an existing object without changing it.</td></tr>
<tr><td>Proxy</td><td><code>RedisTokenBucket</code></td><td>It looks like a local bucket, but its numbers live in Redis.</td></tr>
<tr><td>Adapter</td><td><code>ApiFilter</code></td><td>It turns a <code>Decision</code> into HTTP, and only at the edge.</td></tr>
<tr><td>Singleton, not used</td><td></td><td>The one limiter a process needs is created in <code>main</code>, and tests need fresh ones.</td></tr>
</table>
""",
hot='', file=('core', None)),

dict(id='f-questions', stage='Defend', title='Questions interviewers ask, with short answers',
think="""
<table class="poke">
<tr><td>Why are the limits data and not classes?</td><td>Limits change every few weeks, as product and operations teams ask. A line of configuration with a predicate covers each change without a new release.</td></tr>
<tr><td>Why are narrow rules checked first?</td><td>A client that sends too much is stopped by its own rule, and never takes the global lock that every request shares.</td></tr>
<tr><td>Why does <code>Bucket</code> need a refund?</td><td>A request refused by the third rule must give back what the first two rules took, or a refused request would use up budget.</td></tr>
<tr><td>Could two rules deadlock?</td><td>No. A bucket holds its lock only inside its own method, and never while another lock is held.</td></tr>
<tr><td>Why is the rule's id part of the store's key?</td><td>Two rules can count the same client, for example one per second and one per day. Each needs its own bucket.</td></tr>
<tr><td>Why aren't the tokens <code>volatile</code>?</td><td>They are only read and written inside the bucket's lock, and the lock already makes the writes visible.</td></tr>
<tr><td>Why is the token count a <code>double</code>?</td><td>A refill earns fractions of a token every millisecond. An <code>int</code> would round them away.</td></tr>
<tr><td>What if a request costs more than the limit?</td><td>It can never pass. Refuse it without <code>Retry-After</code>, so the client does not retry forever.</td></tr>
<tr><td>How would you limit by IP address too?</td><td>Add one value to <code>Scope</code>, and a rule that uses it.</td></tr>
<tr><td>How do big customers avoid waiting behind others?</td><td>Give the Pro plan its own rules and buckets, and a separate global limit for Pro traffic.</td></tr>
<tr><td>How would you count hits in the last 5 minutes? (LeetCode 362)</td><td>Keep 300 slots, one per second, and reuse each slot when its second comes round again. The code is below.</td></tr>
<tr><td>How do you test a refill without sleeping?</td><td>Use a <code>ManualClock</code>, and call <code>advance(200)</code>.</td></tr>
<tr><td>What if the clock jumps backwards?</td><td><code>nanoTime</code> never goes backwards, and a reading older than the last one earns nothing.</td></tr>
</table>
{{named:extra:hits|HitCounter: 300 reused slots}}
""",
hot='', file=('core', None)),
]
