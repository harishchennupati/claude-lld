STEPS = [
dict(id='e1', stage='Extend', title='Follow-up 1: “Logins: at most 5 in any 60 seconds, exactly”',
think="""
<p class="ask">“Our login endpoint allows 5 attempts a minute for each user. Security says there must never be more than 5 attempts in any 60 seconds. Does your limiter guarantee that?”</p>
<p class="lands">Where it goes: a new kind of <b>Bucket</b>, and one new rule that uses it. Nothing else changes.</p>
<p>No, it does not. A token bucket that allows 5 a minute earns a new token every 12 seconds. A user who spends all 5 at once gets another token at 12, 24, 36 and 48 seconds, so 9 attempts can pass in the first minute.</p>
<p>The exact answer is a <b>sliding window log</b>. It keeps the time of every attempt, and allows a new attempt only if fewer than 5 happened in the last 60 seconds. It is a new <code>Bucket</code> implementation, and the login rule chooses it with <code>SlidingWindowLog::new</code>. All the other rules keep the token bucket.</p>
{{svg:fu1_n}}
<p><b>How it works.</b> The times are kept oldest first, in an <code>ArrayDeque</code>. A call first removes the times that have left the window. If the times that remain, plus the cost, fit within the limit, it records the current time once per unit and allows the request. If not, the wait is how long until enough of the oldest times leave the window. A refund removes the newest times, which are the ones this request added.</p>
""",
code=[('e1', 'diff', '')], out=('e1', 'e1'),
after="""<div class="hole limit">Memory grows with the limit, because the log keeps one time per unit: about 2.7 KB per client at 100 a minute. That is fine for 5 logins a minute, but far too much for an API limit of 1,000 a minute.</div>""",
new='SlidingWindowLog', hot='Bucket,Algorithm', file=('e1', None), practice=('SlidingWindowLog', 8)),

dict(id='e2', stage='Extend', title='Follow-up 2: “Raise the Free plan from 5 to 10 a second, without a restart”',
think="""
<p class="ask">“We are raising the Free plan to 10 requests a second. The operations team will change the limit in the admin screen, with no restart. When do Free clients start getting 10?”</p>
<p class="lands">Where it goes: <b>RateLimiterService</b> gets a way to replace its rule book, and <b>LocalBucketStore</b> adds the limit to its key.</p>
<p>Two small changes make a new limit apply from the very next request.</p>
<p><b>Replace the rule book in one step.</b> The service's rule book becomes a <code>volatile</code> field, with a <code>replaceRules</code> method. The whole book is replaced by a single write, so a request sees either all of the old rules or all of the new ones, never a mix. <code>volatile</code> makes sure every thread sees the new book on its next check.</p>
<p><b>Don't reuse a bucket made for the old limit.</b> The widget's existing <code>free-plan</code> bucket was created with a capacity of 5. The store's key now includes the limit, for example <code>free-plan|Limit[permits=10, windowMillis=1000]|weather-widget</code>. The new limit therefore finds no bucket, and a new one is created with a capacity of 10. The old buckets are simply no longer used, and follow-up 5 removes them.</p>
<p>A client moving from Free to Pro needs neither change. Rules are matched on every request, so its next request is covered by <code>pro-plan</code>.</p>
""",
code=[('e2', 'diff', '')], out=('e2', 'e2'),
after="""<div class="hole limit">A new bucket starts full, so at the moment of the change a client can send a full new burst. For a raise, that is fine. For a cut, copy across how much of the old budget was already used.</div>""",
hot='RateLimiterService,LocalBucketStore,RuleBook', file=('e2', None), practice=('replaceRules, and the limit in the key', 5)),

dict(id='e3', stage='Extend', title='Follow-up 3: “A batch job would rather wait than be refused”',
think="""
<p class="ask">“A nightly job calls us 10,000 times. When it hits a limit, it should wait for its turn instead of failing. Where would you not offer this?”</p>
<p class="lands">Where it goes: a new class that uses <b>RateLimiter</b>. Nothing else changes.</p>
<p>Every refusal already says how long to wait, so waiting is a loop: check; if refused, sleep for the retry time; check again. A deadline stops it from waiting forever, and a request that can never fit gives up at once. The loop uses only the <code>RateLimiter</code> interface, so it respects every rule the service applies, and it will keep working when the buckets move to Redis.</p>
<p>I would not offer this on the request path of a public API. Each waiting caller holds a server thread, and a few thousand of them would use up the server. Keep it for background jobs, cap how long they may wait, and cap how many may wait at once with a <code>Semaphore</code>.</p>
""",
code=[('e3', 'diff', '')], out=('e3', 'e3'),
after="""<div class="hole limit">Waiting callers are not served in order: two that wake up together compete for the same token. If the order matters, give each client a queue, which is how a leaky bucket works.</div>""",
new='Waiting', hot='RateLimiter', file=('e3', None), practice=('Waiting.acquire', 5)),

dict(id='e4', stage='Extend', title='Follow-up 4: “Try a stricter limit without refusing anyone”',
think="""
<p class="ask">“We want to cut the Free plan to 3 a second, but first we want to know whom it would hurt. Don't refuse anyone yet.”</p>
<p class="lands">Where it goes: a wrapper around <b>RateLimiter</b>. The API is given the wrapper instead, and nothing else changes.</p>
<p><code>ShadowLimiter</code> holds two limiters: the live one, and a candidate built with the new rules. For each request it asks the live limiter and returns its answer, so nobody is refused because of the experiment. When the live limiter allows a request, it also asks the candidate, and counts the requests that the candidate would have refused. Those are exactly the requests the new limit would hurt. After a week of these numbers, the operations team can switch to the new rule, using follow-up 2.</p>
<p>This is the <b>Decorator</b> pattern: <code>ShadowLimiter</code> is itself a <code>RateLimiter</code>, so it can be put in front of the real one without changing it or the API.</p>
""",
code=[('e4', 'diff', '')], out=('e4', 'e4'),
after="""<div class="hole limit">The candidate keeps its own buckets, so the limiter uses twice the memory while the experiment runs. Its counts are exact only when the candidate has a single rule. It is an experiment for a week, not a permanent layer.</div>""",
new='ShadowLimiter', hot='RateLimiter', pattern=[('Decorator', 'ShadowLimiter wraps any RateLimiter')], file=('e4', None), practice=('ShadowLimiter', 5)),

dict(id='e5', stage='Extend', title='Follow-up 5: “Ten million API keys, most used once a day”',
think="""
<p class="ask">“We have ten million API keys, and most of them call us once a day. How much memory does the limiter use? Fix it.”</p>
<p class="lands">Where it goes: <b>Bucket</b> gets a new method, <code>isIdle</code>, which changes an interface, so say so; and <b>LocalBucketStore</b> gets <code>evictIdle</code>.</p>
<p>The store's map only ever grows. Measured, each bucket costs about 140 bytes, so ten million keys use about 1.4 GB.</p>
<p>The fix rests on one fact: <b>a token bucket that has not been used for a whole window is full again</b>, exactly like a new bucket. Removing it loses nothing, because the next request would create an identical one. So each bucket answers <code>isIdle(now)</code>, and a timer calls <code>evictIdle</code> once a minute, away from the request path, to remove the idle ones.</p>
<p>The removal uses <code>remove(key, value)</code>, which removes the entry only if the map still holds that same bucket. If another thread has just replaced it, the new bucket stays.</p>
""",
code=[('e5', 'diff', '')], out=('e5', 'e5'),
after="""<div class="hole limit">A request that fetched a bucket just before the sweep removed it will spend from the removed bucket, so that client can get one extra request. To make it exact, mark the bucket as retired inside its lock, and have the request look it up again.</div>""",
hot='Bucket,TokenBucket,SlidingWindowLog,LocalBucketStore', sub={'Bucket': 'tryTake · refund · isIdle'},
file=('e5', None), practice=('isIdle, and evictIdle', 6)),
]
