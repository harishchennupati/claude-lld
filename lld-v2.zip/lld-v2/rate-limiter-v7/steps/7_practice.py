STEPS = [
dict(id='practice', stage='Practice', wide=True, title='Practise it, from a blank file and in your IDE',
think="""
<p><b>Open the real project in your IDE.</b> Each project has one class per file, in the package <code>ratelimiter</code>, with a <code>pom.xml</code>. In IntelliJ, choose <i>File → Open</i>, pick the folder, and run <code>Main</code>. From a terminal, run <code>./run.sh</code>. Put breakpoints in <code>RateLimiterService.check</code> and <code>TokenBucket.tryTake</code>, and step through the widget's requests.</p>
<ul>
<li><b>The core</b>, which is what you type in the interview: <code>~/Downloads/lld-v2/code/rate-limiter-v7/core</code> (23 files)</li>
<li><b>Everything, after every follow-up and scale-out step:</b> <code>~/Downloads/lld-v2/code/rate-limiter-v7/final</code> (35 files)</li>
</ul>
<p><b>Then practise from an empty folder.</b> In <b>Practice</b> mode (top right), every step hides its code until you reveal it, gives you a timer, and lets you mark whether you got it or missed something.</p>
<ol>
<li><b>The skeleton</b> <span class="timer" data-min="12"><span class="tv">12:00</span><button type="button">start</button></span><br>Every type, field and method signature from the class diagram in step 3, with method bodies that just throw. It must compile. This is the design, and most of the grade.</li>
<li><b>The logic</b> <span class="timer" data-min="12"><span class="tv">12:00</span><button type="button">start</button></span><br><code>TokenBucket</code>'s <code>tryTake</code>, <code>refund</code> and <code>refill</code>, <code>LocalBucketStore.bucket</code>, and <code>RateLimiterService.check</code> with the refund.</li>
<li><b>The whole core</b> <span class="timer" data-min="60"><span class="tv">60:00</span><button type="button">start</button></span><br>From a blank file to a <code>main</code> that tells the widget's story and prints 30000 and 20000. Then compare your code with the core project, and write down three things you missed.</li>
<li><b>The follow-ups and the scale-out steps</b>, 10 minutes each, each one on top of the last. Before you type, say which class the change goes to, and whether it is a new class or a change to an existing one.</li>
</ol>
<p class="marks"><label><input type="checkbox" data-k="rate-limiter.read"> read</label><label><input type="checkbox" data-k="rate-limiter.coded"> coded from a blank file</label></p>
<div class="misc"><textarea data-k="rate-limiter.miss" placeholder="Things I missed: three specific things the reference code does that yours did not. Saved in this browser."></textarea></div>
<details class="demo"><summary>The whole core as one file</summary>
{{whole:core|Main.java · the core}}
</details>
"""),
]
