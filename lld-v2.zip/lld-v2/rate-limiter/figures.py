"""The figures of the rate limiter page. Each function returns one <svg>."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'tools'))
from lldkit import Svg, C, uml  # type: ignore  # noqa: E402


# ----------------------------------------------------------------------------- 01 Acme's bucket
def fig_acme():
    s = Svg(960, 300)
    x0, x1, t1 = 90, 900, 1400.0
    y0, per = 236, 36                                   # y of 0 tokens, px per token
    X = lambda t: x0 + (x1 - x0) * t / t1
    Y = lambda k: y0 - per * k
    for k in range(6):
        s.line([(x0, Y(k)), (x1, Y(k))], stroke=C['line'] if k else C['mut'], sw=0.8 if k else 1.2,
               dash='2 4' if k else None)
        s.text(x0 - 10, Y(k) + 4, str(k), size=10, fill=C['mut'], anchor='end')
    s.text(x0 - 10, Y(5) - 16, 'tokens', size=10, fill=C['mut'], anchor='end')
    for t in (0, 200, 400, 600, 800, 1000, 1200, 1400):
        s.line([(X(t), y0), (X(t), y0 + 5)], stroke=C['mut'], sw=1)
        s.text(X(t), y0 + 19, f'{t:,} ms', size=10, fill=C['mut'], anchor='middle')
    s.line([(X(0), Y(5)), (X(0), Y(0)), (X(200), Y(1)), (X(200), Y(0)),
            (X(1200), Y(5)), (X(1400), Y(5))], stroke=C['acc'], sw=2.4)
    s.circle(X(0), Y(5), 4, C['acc'])
    # requests at t=0, listed to the right of the drop
    for i in range(7):
        ok = i < 5
        cy = Y(5) + 2 + i * 14
        s.circle(X(0) + 14, cy - 4, 4.3, C['green'] if ok else C['red'])
        s.text(X(0) + 24, cy, f'#{i+1} ' + ('allowed' if ok else 'refused, retry in 200 ms'),
               size=10, fill=C['green'] if ok else C['red'])
    lx, ly = X(200) + 104, Y(3.4)
    s.circle(lx, ly - 4, 4.3, C['green'])
    s.text(lx + 10, ly, '#8 allowed: 200 ms earned 1 token', size=10, fill=C['green'])
    s.circle(lx, ly + 10, 4.3, C['red'])
    s.text(lx + 10, ly + 14, '#9 refused, retry in 200 ms', size=10, fill=C['red'])
    s.line([(lx - 7, ly + 6), (X(200) + 3, Y(1) - 3)], stroke=C['dim'], sw=1, dash='2 2')
    s.text(X(820), Y(1.35), 'earns 1 token every 200 ms', size=10.5, fill=C['acc'], anchor='start')
    s.text(X(820), Y(1.35) + 14, '5 a second, a little every millisecond', size=10, fill=C['mut'], anchor='start')
    s.text(X(1300), Y(5) - 12, 'full: stops at 5', size=10.5, fill=C['acc'], anchor='middle')
    s.text(X(1300), Y(5) + 20, 'and after 5 quiet', size=10, fill=C['mut'], anchor='middle')
    s.text(X(1300), Y(5) + 33, 'seconds it is still 5', size=10, fill=C['mut'], anchor='middle')
    s.text(480, 290, 'green: allowed, the API serves it.   red: refused, the API answers 429 with Retry-After.',
           size=10, fill=C['mut'], anchor='middle')
    return s.render("Acme's bucket: capacity 5, earns 5 a second")


# ----------------------------------------------------------------------------- 03 the minute's edge
def fig_edge():
    s = Svg(960, 390)
    x0, x1 = 60, 900
    X = lambda sec: x0 + (x1 - x0) * sec / 120.0          # 12:00:00 .. 12:02:00
    def lane(y, title, sub):
        s.text(x0, y - 100, title, size=12, weight='600')
        s.text(x0, y - 84, sub, size=10.5, fill=C['mut'])
        s.line([(x0, y), (x1, y)], stroke=C['mut'], sw=1.2)
        for sec, lab in ((0, '12:00:00'), (60, '12:01:00'), (120, '12:02:00')):
            s.line([(X(sec), y), (X(sec), y + 5)], stroke=C['mut'], sw=1)
            s.text(X(sec), y + 18, lab, size=10, fill=C['mut'], anchor='middle')
    y = 160
    lane(y, 'First idea: a counter per client, reset at the start of every minute',
         'the fixed window: it keeps one count, and the minute the count belongs to')
    s.rect(X(0), y - 68, X(60) - X(0) - 3, 66, fill=C['sur2'], stroke=C['line'], rx=4, dash='4 3')
    s.rect(X(60) + 3, y - 68, X(120) - X(60) - 3, 66, fill=C['sur2'], stroke=C['line'], rx=4, dash='4 3')
    s.text(X(0) + 10, y - 52, 'minute 1: counts up to 100', size=10, fill=C['mut'])
    s.text(X(120) - 10, y - 52, 'minute 2: counts from 0 again', size=10, fill=C['mut'], anchor='end')
    s.rect(X(60) - 16, y - 46, 12, 46, fill=C['green'], stroke='none', rx=2)
    s.rect(X(60) + 4, y - 46, 12, 46, fill=C['green'], stroke='none', rx=2)
    s.text(X(60) - 24, y - 28, '100 at 12:00:59.9', size=10, fill=C['green'], anchor='end')
    s.text(X(60) - 24, y - 15, 'all allowed', size=10, fill=C['green'], anchor='end')
    s.text(X(60) + 24, y - 28, '100 at 12:01:00.1', size=10, fill=C['green'])
    s.text(X(60) + 24, y - 15, 'all allowed: a new minute', size=10, fill=C['green'])
    s.text(X(60), y + 40, '200 requests in 0.2 seconds: twice the limit, in a fifth of a second',
           size=11, fill=C['red'], anchor='middle', weight='600')
    y = 352
    lane(y, 'What we do instead: a token bucket of 100 that earns 100 a minute, one every 0.6 s',
         'the same traffic')
    s.rect(X(60) - 16, y - 46, 12, 46, fill=C['green'], stroke='none', rx=2)
    s.rect(X(60) + 4, y - 46, 12, 46, fill=C['red'], stroke='none', rx=2)
    s.text(X(60) - 24, y - 28, '100 at 12:00:59.9', size=10, fill=C['green'], anchor='end')
    s.text(X(60) - 24, y - 15, 'all allowed: the bucket is now 0', size=10, fill=C['green'], anchor='end')
    s.text(X(60) + 24, y - 28, '100 at 12:01:00.1', size=10, fill=C['red'])
    s.text(X(60) + 24, y - 15, 'all refused: 0.2 s earned a third of a token', size=10, fill=C['red'])
    return s.render('The minute edge: fixed window against token bucket')


# ----------------------------------------------------------------------------- 05 the class diagram
def fig_classes(hi=()):
    s = Svg(960, 560)
    H = lambda n: n in hi
    caller = (20, 18, 250)
    s.rect(*caller, 52, fill=C['bg'], stroke=C['mut'], dash='3 3')
    s.text(caller[0] + 125, caller[1] + 21, 'the API filter (Main, here)', size=11.5, weight='600', anchor='middle')
    s.text(caller[0] + 125, caller[1] + 38, 'calls allow() before any work', size=10, fill=C['mut'], anchor='middle')

    rl = uml(s, 355, 18, 250, 'RateLimiter', methods=['allow(clientId): Decision'], kind='interface', hi=H('RateLimiter'))
    lrl = uml(s, 300, 138, 360, 'LocalRateLimiter',
              fields=['buckets: ConcurrentHashMap<String, Bucket>', 'rules: RuleBook',
                      'newBucket: BucketFactory', 'clock: Clock'],
              methods=['allow(clientId): Decision'], hi=H('LocalRateLimiter'))
    rb = uml(s, 20, 150, 230, 'RuleBook', fields=['defaultRule: Rule', 'overrides: Map<String, Rule>'],
             methods=['ruleFor(clientId): Rule', 'set(clientId, rule)'], hi=H('RuleBook'))
    rule = uml(s, 20, 330, 230, 'Rule', fields=['limit: int', 'windowMillis: long'],
               methods=['perSecond(n) / perMinute(n)'], kind='record', hi=H('Rule'))
    dec = uml(s, 20, 460, 230, 'Decision', fields=['allowed: boolean', 'retryAfterMillis: long'],
              kind='record', hi=H('Decision'))
    clk = uml(s, 715, 138, 225, 'Clock', methods=['millis(): long'], kind='interface', hi=H('Clock'))
    sc = uml(s, 715, 232, 108, 'SystemClock', hi=H('Clock'))
    mc = uml(s, 832, 232, 108, 'ManualClock', hi=H('Clock'))
    bf = uml(s, 715, 330, 225, 'BucketFactory', methods=['create(rule, now): Bucket'], kind='interface',
             hi=H('BucketFactory'))
    bk = uml(s, 330, 330, 300, 'Bucket', methods=['tryTake(now): Decision'], kind='interface', hi=H('Bucket'))
    tb = uml(s, 330, 432, 300, 'TokenBucket',
             fields=['capacity: int', 'windowMillis: long', 'tokens: double', 'lastRefillMillis: long'],
             methods=['synchronized tryTake(now): Decision'], hi=H('TokenBucket'))

    # caller -> interface
    s.line([(270, 44), (353, 44)], end='arr')
    s.text(311, 38, 'calls', size=9.5, fill=C['dim'], anchor='middle')
    # LocalRateLimiter implements RateLimiter
    s.line([(480, 138), (480, 72)], end='tri')
    # owns buckets: diamond at LocalRateLimiter bottom
    s.line([(480, lrl[1] + lrl[3]), (480, 328)], start='dia', end='arr')
    s.text(488, 300, 'one per client', size=9.5, fill=C['dim'])
    # handed in: rules, factory, clock (dashed green)
    s.line([(300, 200), (252, 200)], stroke=C['green'], dash='5 3', end='arr-green')
    s.line([(660, 176), (713, 176)], stroke=C['green'], dash='5 3', end='arr-green')
    s.line([(660, 240), (690, 240), (690, 356), (713, 356)], stroke=C['green'], dash='5 3', end='arr-green')
    s.text(686, 290, 'handed in', size=9.5, fill=C['green'], anchor='end')
    # clocks implement Clock
    s.line([(769, 232), (769, 192)], end='tri')
    s.line([(886, 232), (886, 192)], end='tri')
    # factory creates buckets
    s.line([(715, 368), (632, 368)], stroke=C['acc'], dash='2 3', end='arr-acc')
    s.text(673, 385, 'makes', size=9.5, fill=C['acc'], anchor='middle')
    s.text(828, 420, 'TokenBucket::new is one', size=9.5, fill=C['dim'], anchor='middle')
    # TokenBucket implements Bucket
    s.line([(480, 432), (480, 384)], end='tri')
    # RuleBook holds Rules
    s.line([(135, rb[1] + rb[3]), (135, 328)], end='arr')
    s.text(143, 318, 'holds', size=9.5, fill=C['dim'])
    # Bucket returns Decision
    s.line([(330, 357), (290, 357), (290, 500), (252, 500)], end='arr')
    s.text(296, 476, 'returns', size=9.5, fill=C['dim'])
    # legend
    lx, ly = 668, 470
    s.text(lx, ly, 'how to read it', size=10, fill=C['mut'], weight='600')
    s.line([(lx, ly + 14), (lx + 34, ly + 14)], end='tri'); s.text(lx + 42, ly + 18, 'implements', size=9.5, fill=C['mut'])
    s.line([(lx, ly + 30), (lx + 34, ly + 30)], start='dia'); s.text(lx + 42, ly + 34, 'owns: makes and keeps them', size=9.5, fill=C['mut'])
    s.line([(lx, ly + 46), (lx + 34, ly + 46)], stroke=C['green'], dash='5 3', end='arr-green'); s.text(lx + 42, ly + 50, 'handed in through the constructor', size=9.5, fill=C['mut'])
    s.line([(lx, ly + 62), (lx + 34, ly + 62)], end='arr'); s.text(lx + 42, ly + 66, 'uses, holds or returns', size=9.5, fill=C['mut'])
    s.text(lx, ly + 84, 'blue dashed box: interface   teal box: record', size=9.5, fill=C['mut'])
    return s.render('The rate limiter: every class, and how they connect')


# ----------------------------------------------------------------------------- 08 the race
def fig_race():
    s = Svg(960, 330)
    def col(x, title, sub, rows, verdict, vcol):
        s.text(x, 26, title, size=12, weight='600')
        s.text(x, 42, sub, size=10.5, fill=C['mut'])
        s.text(x + 60, 70, 'thread 1', size=10.5, fill=C['blue'], anchor='middle', weight='600')
        s.text(x + 220, 70, "acme's bucket", size=10.5, fill=C['acc'], anchor='middle', weight='600')
        s.text(x + 380, 70, 'thread 2', size=10.5, fill=C['peach'], anchor='middle', weight='600')
        for xx in (x + 60, x + 220, x + 380):
            s.line([(xx, 78), (xx, 262)], stroke=C['line'], sw=1, dash='2 4')
        for i, (who, txt, state, colr) in enumerate(rows):
            yy = 100 + i * 34
            if state is not None:
                s.rect(x + 175, yy - 13, 90, 20, fill=C['bg'], stroke=C['acc'], rx=4)
                s.text(x + 220, yy + 1, state, size=10, fill=C['acc'], anchor='middle')
            if who == 1:
                s.text(x + 60, yy + 1, txt, size=10, fill=colr or C['blue'], anchor='middle')
            elif who == 2:
                s.text(x + 380, yy + 1, txt, size=10, fill=colr or C['peach'], anchor='middle')
        s.rect(x, 276, 440, 34, fill=C['bg'], stroke=vcol, rx=6)
        s.text(x + 220, 297, verdict, size=11, fill=vcol, anchor='middle', weight='600')
    col(20, 'No lock', 'read, decide, write: three steps anyone can split',
        [(1, 'reads 1 token', 'tokens = 1', None),
         (2, 'reads 1 token', 'tokens = 1', None),
         (1, 'writes 0, allowed', 'tokens = 0', C['green']),
         (2, 'writes 0, allowed', 'tokens = 0', C['green']),
         (0, '', None, None)],
        'two requests pass on one token', C['red'])
    col(500, 'synchronized tryTake: a lock on this bucket', 'refill, check, spend: one step',
        [(1, 'locks; reads 1', 'tokens = 1', None),
         (2, 'waits for the lock', None, C['dim']),
         (1, 'writes 0, allowed', 'tokens = 0', C['green']),
         (2, 'locks; reads 0', 'tokens = 0', None),
         (2, 'refused, 200 ms', None, C['red'])],
        'one passes, one is told when to retry', C['green'])
    return s.render('Two threads, one token left')


# ----------------------------------------------------------------------------- 10 the ladder
def fig_ladder():
    s = Svg(960, 330)
    steps = [
        ('1', 'Exact, for logins', 'SlidingWindowLog', 'new Bucket, 1 line'),
        ('2', 'Plan changes live', 'changeRule()', 'new method'),
        ('3', 'Cap the whole API', 'BothBuckets', '+ refund() on Bucket'),
        ('4', 'Wait, not fail', 'Waiting', 'new class on top'),
        ('5', '10 million keys', 'evictIdle()', '+ isIdle() on Bucket'),
        ('6', 'Twelve servers', 'RedisRateLimiter', 'new RateLimiter'),
    ]
    base_y, w, h = 292, 150, 64
    s.rect(20, base_y, 920, 26, fill=C['bg'], stroke=C['acc'], rx=5)
    s.text(480, base_y + 17, 'the core: Rule · Decision · Clock · Bucket · TokenBucket · RuleBook · LocalRateLimiter',
           size=10.5, fill=C['acc'], anchor='middle')
    for i, (n, ask, what, kind) in enumerate(steps):
        x = 20 + i * 154
        y = base_y - 12 - h - i * 34
        s.rect(x, y, w, h, fill=C['sur'], stroke=C['line'], rx=6)
        s.circle(x + 16, y + 17, 10, C['acc'])
        s.text(x + 16, y + 21, n, size=11, fill=C['bg'], anchor='middle', weight='700')
        s.text(x + 32, y + 21, ask, size=10, fill=C['txt'], weight='600')
        s.text(x + 10, y + 40, what, size=10, fill=C['yellow'])
        s.text(x + 10, y + 55, kind, size=9.5, fill=C['mut'])
        s.line([(x + w / 2, y + h), (x + w / 2, base_y - 2)], stroke=C['line'], sw=1, dash='2 3')
    s.text(20, 22, 'Each step keeps everything below it: step 4 waits on the two limits of step 3,',
           size=10.5, fill=C['mut'])
    s.text(20, 37, 'and step 6 swaps the store under steps 3 and 4 without changing them.', size=10.5, fill=C['mut'])
    return s.render('The six follow-ups, each on top of the last')


# ----------------------------------------------------------------------------- fu1
def fig_fu1():
    s = Svg(960, 215)
    s.add('<g transform="translate(0,-30)">')
    x0, x1 = 170, 930
    X = lambda sec: x0 + (x1 - x0) * sec / 62.0
    def lane(y, name, allowed_at, total):
        s.text(20, y + 4, name, size=11.5, weight='600')
        s.text(20, y + 19, f'{total} pass in the first minute', size=10, fill=C['mut'])
        s.line([(x0, y), (x1, y)], stroke=C['line'], sw=1)
        for k in range(5):
            s.circle(X(0) + 0, y - 8 - k * 7 + 14, 3.2, C['green'])
        for sec in range(1, 60):
            ok = sec in allowed_at
            s.circle(X(sec), y, 4.2 if ok else 2.3, C['green'] if ok else C['red'])
    lane(80, 'TokenBucket', {12, 24, 36, 48}, 9)
    lane(160, 'SlidingWindowLog', set(), 5)
    for sec in (0, 12, 24, 36, 48, 60):
        s.line([(X(sec), 196), (X(sec), 201)], stroke=C['mut'], sw=1)
        s.text(X(sec), 214, f'{sec} s', size=10, fill=C['mut'], anchor='middle')
    s.text(X(12), 62, 'a token every 12 s', size=10, fill=C['green'], anchor='middle')
    s.text(X(30), 142, 'refused until the first of the 5 is 60 s old', size=10, fill=C['red'], anchor='middle')
    s.text(20, 238, 'Rule: 5 a minute. A burst of 5 at 0 s, then one attempt a second. Green: allowed; red: refused.',
           size=10, fill=C['mut'])
    s.add('</g>')
    return s.render('5 a minute: token bucket against the log')


# ----------------------------------------------------------------------------- fu3
def fig_fu3():
    s = Svg(960, 250)
    s.rect(20, 90, 150, 50, fill=C['bg'], stroke=C['mut'], dash='3 3')
    s.text(95, 112, 'a request', size=11, anchor='middle', weight='600')
    s.text(95, 128, 'from client B', size=10, fill=C['mut'], anchor='middle')
    s.rect(250, 70, 230, 90, fill=C['sur'], stroke=C['acc'])
    s.text(365, 94, "B's own bucket", size=11.5, anchor='middle', weight='600')
    s.text(365, 112, '10 a second', size=10, fill=C['mut'], anchor='middle')
    s.text(365, 128, 'one per client', size=10, fill=C['mut'], anchor='middle')
    s.text(365, 146, '1st: stops a noisy client early', size=9.5, fill=C['dim'], anchor='middle')
    s.rect(560, 70, 230, 90, fill=C['sur'], stroke=C['yellow'])
    s.text(675, 94, 'the shared bucket', size=11.5, anchor='middle', weight='600')
    s.text(675, 112, '15 a second, the whole API', size=10, fill=C['mut'], anchor='middle')
    s.text(675, 128, 'one for everyone', size=10, fill=C['mut'], anchor='middle')
    s.text(675, 146, '2nd: only for requests that passed', size=9.5, fill=C['dim'], anchor='middle')
    s.line([(170, 115), (248, 115)], end='arr')
    s.line([(480, 105), (558, 105)], stroke=C['green'], end='arr-green')
    s.text(519, 98, 'took 1', size=9.5, fill=C['green'], anchor='middle')
    s.line([(790, 105), (868, 105)], stroke=C['green'], end='arr-green')
    s.text(900, 102, 'allowed', size=10.5, fill=C['green'], anchor='middle', weight='600')
    s.text(900, 116, 'both took 1', size=9.5, fill=C['mut'], anchor='middle')
    # refused by own
    s.line([(365, 160), (365, 205)], stroke=C['red'], end='arr-red')
    s.text(365, 222, 'refused by its own limit:', size=10, fill=C['red'], anchor='middle')
    s.text(365, 236, 'the shared bucket is never touched', size=10, fill=C['red'], anchor='middle')
    # refused by shared, refund
    s.line([(675, 160), (675, 205)], stroke=C['red'], end='arr-red')
    s.text(675, 222, 'refused by the shared limit:', size=10, fill=C['red'], anchor='middle')
    s.text(675, 236, 'refund(): B gets its token back', size=10, fill=C['red'], anchor='middle')
    s.line([(675, 184), (430, 184), (430, 163)], stroke=C['peach'], dash='4 3', end='arr')
    s.text(552, 198, 'give back', size=9.5, fill=C['peach'], anchor='middle')
    s.text(20, 30, 'BothBuckets.tryTake: all or nothing. A request counts against a limit only if it was allowed.',
           size=10.5, fill=C['mut'])
    return s.render('Two limits, one request')


# ----------------------------------------------------------------------------- fu6
def fig_fu6():
    s = Svg(960, 280)
    s.text(20, 24, 'Before: each server keeps its own map, so acme gets 100 a minute on EACH of 12 servers: up to 1,200.',
           size=10.5, fill=C['red'])
    s.text(20, 40, 'After: every server runs the same script on one Redis; Redis runs one script at a time.',
           size=10.5, fill=C['green'])
    names = ['server 1', 'server 2', 'server 3', '...', 'server 12']
    for i, n in enumerate(names):
        y = 64 + i * 40
        if n == '...':
            s.text(120, y + 22, '...', size=14, fill=C['mut'], anchor='middle')
            continue
        s.rect(30, y, 190, 30, fill=C['sur'], stroke=C['line'])
        s.text(125, y + 19, n + ': RedisRateLimiter', size=9.5, anchor='middle')
        s.line([(220, y + 15), (470, 150 + (i - 2) * 6)], stroke=C['blue'], sw=1.2, end='arr-blue')
    s.rect(474, 88, 250, 124, fill=C['sur'], stroke=C['acc'], sw=1.8)
    s.text(599, 112, 'Redis', size=12.5, anchor='middle', weight='600')
    s.text(599, 132, 'rate:acme  {tokens, last}', size=10, fill=C['yellow'], anchor='middle')
    s.text(599, 152, 'the Lua script: refill, check, take', size=10, fill=C['mut'], anchor='middle')
    s.text(599, 168, 'one script at a time, like the lock', size=10, fill=C['mut'], anchor='middle')
    s.text(599, 184, "Redis's clock (TIME), not a server's", size=10, fill=C['mut'], anchor='middle')
    s.text(599, 200, 'PEXPIRE: idle keys delete themselves', size=10, fill=C['mut'], anchor='middle')
    s.text(750, 110, 'cost: one network round trip', size=10.5, fill=C['txt'])
    s.text(750, 126, 'per request, about 0.5 ms', size=10.5, fill=C['txt'])
    s.text(750, 158, 'Redis down:', size=10.5, fill=C['txt'], weight='600')
    s.text(750, 174, 'fail open: allow (public API)', size=10, fill=C['green'])
    s.text(750, 190, 'fail closed: refuse (logins)', size=10, fill=C['red'])
    s.text(20, 268, 'The callers do not change: they still call allow(clientId) on a RateLimiter.',
           size=10.5, fill=C['mut'])
    return s.render('Twelve servers, one budget')


# ============================================================================= v2: design + narrow figures
def fig_seams():
    """Design: one orchestrator, four seams. Arrows point from a class to what it depends on."""
    s = Svg(960, 400)
    s.text(20, 24, 'Every arrow points from a class to what it depends on. All of them end on an interface or a record:',
           size=10.5, fill=C['mut'])
    s.text(20, 39, 'so each of the four things that change sits behind a seam, and swapping it opens no other class.',
           size=10.5, fill=C['mut'])
    # the caller
    s.rect(20, 70, 190, 46, fill=C['bg'], stroke=C['mut'], dash='3 3')
    s.text(115, 90, 'the API filter', size=11.5, anchor='middle', weight='600')
    s.text(115, 106, 'knows only RateLimiter', size=9.5, fill=C['mut'], anchor='middle')
    # interface RateLimiter
    s.rect(300, 70, 250, 46, fill=C['sur'], stroke=C['blue'], dash='5 3')
    s.text(425, 88, 'RateLimiter', size=12, anchor='middle', weight='600')
    s.text(425, 105, 'seam 4: where budgets live', size=9.5, fill=C['blue'], anchor='middle')
    s.line([(210, 93), (298, 93)], end='arr')
    # orchestrator
    s.rect(300, 170, 250, 58, fill=C['sur'], stroke=C['acc'], sw=2)
    s.text(425, 192, 'LocalRateLimiter', size=12.5, anchor='middle', weight='600')
    s.text(425, 209, 'the orchestrator: finds a client\'s', size=9.5, fill=C['mut'], anchor='middle')
    s.text(425, 221, 'bucket, then asks it', size=9.5, fill=C['mut'], anchor='middle')
    s.line([(425, 170), (425, 118)], end='tri')
    s.text(433, 150, 'implements', size=9.5, fill=C['dim'])
    # seams
    def seam(x, y, w, title, sub, impl, col=C['blue']):
        s.rect(x, y, w, 46, fill=C['sur'], stroke=col, dash='5 3')
        s.text(x + w / 2, y + 19, title, size=11.5, anchor='middle', weight='600')
        s.text(x + w / 2, y + 35, sub, size=9.5, fill=col, anchor='middle')
        s.text(x + w / 2, y + 62, impl, size=9.5, fill=C['mut'], anchor='middle')
    seam(20, 290, 190, 'BucketFactory → Bucket', 'seam 1: the algorithm', 'TokenBucket, SlidingWindowLog, ...')
    seam(250, 290, 150, 'RuleBook', 'seam 2: the limits', 'a default + overrides', col=C['teal'])
    seam(440, 290, 150, 'Clock', 'seam 3: time', 'SystemClock, ManualClock')
    s.rect(630, 290, 150, 46, fill=C['sur'], stroke=C['teal'])
    s.text(705, 309, 'Rule, Decision', size=11.5, anchor='middle', weight='600')
    s.text(705, 325, 'records: plain values', size=9.5, fill=C['teal'], anchor='middle')
    s.text(705, 352, 'never change once made', size=9.5, fill=C['mut'], anchor='middle')
    for x2 in (115, 325, 515, 705):
        s.line([(425, 228), (425, 258), (x2, 258), (x2, 288)], stroke=C['green'], dash='5 3', end='arr-green')
    s.text(438, 250, 'handed in through the constructor', size=9.5, fill=C['green'])
    # right-side notes
    s.text(800, 80, 'what changes, and where', size=10.5, weight='600')
    notes = [('a new algorithm', 'a new Bucket class'), ('a new plan', 'one RuleBook call'),
             ('a test', 'a ManualClock'), ('twelve servers', 'a new RateLimiter')]
    for i, (a, b) in enumerate(notes):
        s.text(800, 102 + i * 34, a, size=10, fill=C['txt'])
        s.text(812, 117 + i * 34, '→ ' + b, size=9.5, fill=C['mut'])
    return s.render('One orchestrator, four seams')


def fig_race_n():
    s = Svg(600, 430)
    def block(y0, title, rows, verdict, vcol):
        s.text(10, y0, title, size=12, weight='600')
        cols = (80, 300, 520)
        for x, lab, colr in ((80, 'thread 1', C['blue']), (300, "acme's bucket", C['acc']), (520, 'thread 2', C['peach'])):
            s.text(x, y0 + 24, lab, size=11, fill=colr, anchor='middle', weight='600')
            s.line([(x, y0 + 32), (x, y0 + 32 + len(rows) * 26)], stroke=C['line'], sw=1, dash='2 4')
        for i, (who, txt, state, colr) in enumerate(rows):
            yy = y0 + 50 + i * 26
            if state:
                s.rect(250, yy - 14, 100, 20, fill=C['bg'], stroke=C['acc'], rx=4)
                s.text(300, yy, state, size=10.5, fill=C['acc'], anchor='middle')
            if who:
                s.text(cols[0] if who == 1 else cols[2], yy, txt, size=10.5,
                       fill=colr or (C['blue'] if who == 1 else C['peach']), anchor='middle')
        yv = y0 + 42 + len(rows) * 26
        s.rect(10, yv, 580, 28, fill=C['bg'], stroke=vcol, rx=6)
        s.text(300, yv + 19, verdict, size=11.5, fill=vcol, anchor='middle', weight='600')
    block(18, 'No lock: read, decide, write are three steps anyone can split',
          [(1, 'reads 1 token', 'tokens = 1', None), (2, 'reads 1 token', 'tokens = 1', None),
           (1, 'writes 0, allowed', 'tokens = 0', C['green']), (2, 'writes 0, allowed', 'tokens = 0', C['green'])],
          'two requests pass on one token', C['red'])
    block(228, 'synchronized tryTake: refill, check and spend are one step',
          [(1, 'locks; reads 1', 'tokens = 1', None), (2, 'waits for the lock', None, C['dim']),
           (1, 'writes 0, allowed', 'tokens = 0', C['green']), (2, 'locks; reads 0', 'tokens = 0', None),
           (2, 'refused, retry 200 ms', None, C['red'])],
          'one passes, one is told when to retry', C['green'])
    return s.render('Two threads, one token left')


def fig_fu1_n():
    s = Svg(600, 232)
    x0, x1 = 20, 590
    X = lambda sec: x0 + (x1 - x0) * sec / 61.0
    def lane(y, name, allowed_at, total):
        s.text(x0, y - 30, f'{name}: {total} pass in the first minute', size=11.5, weight='600')
        s.line([(x0, y), (x1, y)], stroke=C['line'], sw=1)
        for k in range(5):
            s.circle(X(0) + 4, y + 10 - k * 7, 3.4, C['green'])
        for sec in range(1, 60):
            ok = sec in allowed_at
            s.circle(X(sec) + 4, y, 4.4 if ok else 2.3, C['green'] if ok else C['red'])
    lane(62, 'TokenBucket', {12, 24, 36, 48}, 9)
    lane(152, 'SlidingWindowLog', set(), 5)
    for sec in (0, 12, 24, 36, 48, 60):
        s.line([(X(sec) + 4, 176), (X(sec) + 4, 181)], stroke=C['mut'], sw=1)
        s.text(X(sec) + 4, 194, f'{sec} s', size=10, fill=C['mut'], anchor='middle')
    s.text(x0, 222, 'A burst of 5 at 0 s, then one attempt a second. Green allowed, red refused.', size=10, fill=C['mut'])
    return s.render('5 a minute: token bucket against the log')


def fig_fu3_n():
    s = Svg(600, 300)
    s.rect(180, 10, 240, 40, fill=C['bg'], stroke=C['mut'], dash='3 3')
    s.text(300, 35, 'a request from client B', size=11, anchor='middle', weight='600')
    s.rect(130, 80, 340, 50, fill=C['sur'], stroke=C['acc'])
    s.text(300, 101, "1. B's own bucket: 10 a second", size=11.5, anchor='middle', weight='600')
    s.text(300, 119, 'one per client; stops a noisy client first', size=10, fill=C['mut'], anchor='middle')
    s.rect(130, 170, 340, 50, fill=C['sur'], stroke=C['yellow'])
    s.text(300, 191, '2. the shared bucket: 15 a second', size=11.5, anchor='middle', weight='600')
    s.text(300, 209, 'one for everyone; asked only if 1 said yes', size=10, fill=C['mut'], anchor='middle')
    s.line([(300, 50), (300, 78)], end='arr')
    s.line([(300, 130), (300, 168)], stroke=C['green'], end='arr-green')
    s.text(308, 153, 'took 1', size=10, fill=C['green'])
    s.line([(300, 220), (300, 258)], stroke=C['green'], end='arr-green')
    s.text(300, 276, 'allowed: both took 1', size=11, fill=C['green'], anchor='middle', weight='600')
    s.line([(470, 105), (500, 105)], stroke=C['red'], end='arr-red')
    s.text(506, 101, 'refused;', size=10.5, fill=C['red'])
    s.text(506, 116, 'shared untouched', size=9.5, fill=C['red'])
    s.line([(470, 195), (500, 195)], stroke=C['red'], end='arr-red')
    s.text(506, 191, 'refused;', size=10.5, fill=C['red'])
    s.text(506, 206, 'refund to 1', size=9.5, fill=C['red'])
    s.line([(130, 195), (90, 195), (90, 105), (128, 105)], stroke=C['peach'], dash='4 3', end='arr')
    s.text(84, 150, 'refund()', size=10, fill=C['peach'], anchor='end')
    return s.render('Two limits, one request')


def fig_fu6_n():
    s = Svg(600, 268)
    for i, n in enumerate(['server 1', 'server 2', 'server 3', '...', 'server 12']):
        y = 20 + i * 42
        if n == '...':
            s.text(95, y + 20, '...', size=14, fill=C['mut'], anchor='middle')
            continue
        s.rect(10, y, 170, 30, fill=C['sur'], stroke=C['line'])
        s.text(95, y + 19, n + ': RedisRateLimiter', size=9.5, anchor='middle')
        s.line([(180, y + 15), (318, 118 + (i - 2) * 5)], stroke=C['blue'], sw=1.2, end='arr-blue')
    s.rect(322, 50, 268, 150, fill=C['sur'], stroke=C['acc'], sw=1.8)
    s.text(456, 74, 'Redis', size=12.5, anchor='middle', weight='600')
    s.text(456, 94, 'rate:acme = {tokens, last}', size=10.5, fill=C['yellow'], anchor='middle')
    for k, t in enumerate(['one Lua script: refill, check, take',
                           'runs one script at a time: the lock',
                           "uses Redis's clock, not a server's",
                           'PEXPIRE: idle keys delete themselves']):
        s.text(456, 118 + k * 18, t, size=10, fill=C['mut'], anchor='middle')
    s.text(10, 244, 'Each allow() is now one network round trip to Redis, about 0.5 ms.', size=10.5, fill=C['txt'])
    s.text(10, 260, 'If Redis is down: fail open for a public API, closed for logins.', size=10.5, fill=C['txt'])
    return s.render('Twelve servers, one budget')


# ============================================================================= v4: the growing diagram (right panel)
MINI_NODES = [
    # id, x, y, w, h, kind, name, sub
    ('Main',             10,  10, 125, 40, 'class',  'Main',             'API filter · demo'),
    ('RateLimiter',     160,  10, 130, 40, 'iface',  'RateLimiter',      'allow(clientId)'),
    ('Waiting',         310,  10, 120, 40, 'class',  'Waiting',          'acquire(…, maxWait)'),
    ('RuleBook',         10,  95, 125, 40, 'class',  'RuleBook',         'default + overrides'),
    ('LocalRateLimiter',150,  92, 150, 46, 'class',  'LocalRateLimiter', 'map: client → Bucket'),
    ('RedisRateLimiter',310,  80, 120, 40, 'class',  'RedisRateLimiter', 'one Lua script'),
    ('Rule',             10, 170, 125, 36, 'record', 'Rule',             'limit, window'),
    ('Clock',           310, 150, 120, 36, 'iface',  'Clock',            'System · Manual'),
    ('BucketFactory',   310, 205, 120, 36, 'iface',  'BucketFactory',    'TokenBucket::new'),
    ('Bucket',          150, 245, 150, 42, 'iface',  'Bucket',           'tryTake(now)'),
    ('Decision',         10, 245, 125, 36, 'record', 'Decision',         'allowed, retryAfter'),
    ('TokenBucket',      10, 330, 125, 40, 'class',  'TokenBucket',      'tokens · lastRefill'),
    ('SlidingWindowLog',150, 330, 150, 40, 'class',  'SlidingWindowLog', 'a timestamp each'),
    ('BothBuckets',     310, 330, 120, 40, 'class',  'BothBuckets',      'own + shared'),
]
MINI_EDGES = [
    # a, b, kind, points
    ('Main', 'RateLimiter', 'uses', [(135, 30), (158, 30)]),
    ('Waiting', 'RateLimiter', 'uses', [(310, 30), (292, 30)]),
    ('LocalRateLimiter', 'RateLimiter', 'impl', [(225, 92), (225, 52)]),
    ('RedisRateLimiter', 'RateLimiter', 'impl', [(330, 80), (330, 66), (272, 66), (272, 52)]),
    ('LocalRateLimiter', 'RuleBook', 'handed', [(150, 115), (137, 115)]),
    ('LocalRateLimiter', 'Clock', 'handed', [(300, 130), (305, 130), (305, 168), (308, 168)]),
    ('LocalRateLimiter', 'BucketFactory', 'handed', [(290, 138), (290, 223), (308, 223)]),
    ('LocalRateLimiter', 'Bucket', 'owns', [(225, 147), (225, 243)]),
    ('RuleBook', 'Rule', 'uses', [(72, 135), (72, 168)]),
    ('BucketFactory', 'Bucket', 'makes', [(310, 241), (310, 262), (302, 262)]),
    ('Bucket', 'Decision', 'uses', [(150, 263), (137, 263)]),
    ('TokenBucket', 'Bucket', 'impl', [(72, 330), (72, 305), (190, 305), (190, 289)]),
    ('SlidingWindowLog', 'Bucket', 'impl', [(225, 330), (225, 289)]),
    ('BothBuckets', 'Bucket', 'impl', [(370, 330), (370, 305), (260, 305), (260, 289)]),
]


def fig_mini():
    s = Svg(440, 430)
    stroke = {'iface': C['blue'], 'record': C['teal'], 'class': C['line']}
    for a, b, kind, pts in MINI_EDGES:
        col = {'handed': C['green'], 'makes': C['acc']}.get(kind, C['mut'])
        dash = {'handed': '5 3', 'makes': '2 3'}.get(kind)
        end = {'impl': 'tri', 'handed': 'arr-green', 'makes': 'arr-acc'}.get(kind, 'arr')
        start = 'dia' if kind == 'owns' else None
        d = 'M' + ' L'.join(f'{x} {y}' for x, y in pts)
        extra = f' stroke-dasharray="{dash}"' if dash else ''
        extra += f' marker-end="url(#{end})"' if kind != 'owns' else ' marker-end="url(#arr)"'
        extra += f' marker-start="url(#{start})"' if start else ''
        s.add(f'<g class="ed" data-a="{a}" data-b="{b}"><path d="{d}" fill="none" stroke="{col}" stroke-width="1.4"{extra}/></g>')
    for nid, x, y, w, h, kind, name, sub in MINI_NODES:
        dash = ' stroke-dasharray="5 3"' if kind == 'iface' else ''
        tag = {'iface': '«interface» ', 'record': '«record» '}.get(kind, '')
        s.add(f'<g class="nd" data-n="{nid}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" fill="{C["sur"]}" '
              f'stroke="{stroke[kind]}" stroke-width="1.5"{dash}/>'
              f'<text x="{x + w / 2}" y="{y + 16}" font-size="11.5" font-weight="600" fill="{C["txt"]}" text-anchor="middle">{name}</text>'
              f'<text class="sub" data-n="{nid}" x="{x + w / 2}" y="{y + 31}" font-size="9.5" fill="{C["mut"]}" text-anchor="middle">{sub}</text></g>')
    s.text(10, 395, 'dashed blue: interface · teal: record · green dashed: handed in', size=9.5, fill=C['dim'])
    s.text(10, 411, '◆ owns, one per client · ▷ implements · green: new in this step', size=9.5, fill=C['dim'])
    return s.render('The design, growing step by step')
