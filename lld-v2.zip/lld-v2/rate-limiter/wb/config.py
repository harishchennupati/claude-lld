# Broken copies of a snapshot, compiled and run several times; the page shows every run.
# name: (snapshot, [(find, replace)], runs)
MUTANTS = {
    'nolock': ('core', [('public synchronized Decision tryTake', 'public Decision tryTake')], 10),
    'getput': ('core', [(
        """        Bucket bucket = buckets.computeIfAbsent(clientId,
                id -> newBucket.create(rules.ruleFor(id), now));""",
        """        Bucket bucket = buckets.get(clientId);
        if (bucket == null) {
            bucket = newBucket.create(rules.ruleFor(clientId), now);
            buckets.put(clientId, bucket);
        }""")], 10),
    'nocap': ('core', [(
        'tokens = Math.min(capacity, tokens + (double) elapsed * capacity / windowMillis);',
        'tokens = tokens + (double) elapsed * capacity / windowMillis;')], 1),
}
