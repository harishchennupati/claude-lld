STEPS = [
dict(id='values', stage='Build', title='Rule and Decision: the two values everything talks in',
think="""
<p>I start with the words the rest of the code uses. A <code>Rule</code> is a limit per window. A <code>Decision</code> is allowed, plus a retry time. Both are records: their fields are set once and never change, so any thread can share them without a lock.</p>
<p><code>Rule</code> checks itself when it is made, so a limit of 0 fails at startup, not on the first request. And I return a <code>Decision</code>, not a <code>boolean</code>. A refused client that isn't told when to retry retries at once, and makes the overload worse.</p>
""",
code=[('core', 'Rule,Decision', 'Rule and Decision')],
say="Two immutable records: a Rule, and a Decision that carries the retry time.",
hot='Rule,Decision', file=('core', 'Rule,Decision'), practice=('Rule and Decision', 3)),

dict(id='clock', stage='Build', title='Clock: time is handed in, never read inside',
think="""
<p>Every rule here is about elapsed time, so no class reads the clock itself. It is handed one. <code>SystemClock</code> uses <code>nanoTime</code>, which only moves forward. The wall clock can jump back when the machine corrects itself, and a bucket would then see time run backwards.</p>
<p><code>ManualClock</code> is for tests: <code>advance(200)</code> is 200 ms that pass at once. So no test ever sleeps, and every run gives the same answer.</p>
""",
code=[('core', 'Clock,SystemClock,ManualClock', 'Clock and its two implementations')],
say="Time is an interface: nanoTime in production, a manual clock in tests.",
hot='Clock', file=('core', 'Rule,Decision,Clock,SystemClock,ManualClock'), practice=('Clock, SystemClock, ManualClock', 3)),

dict(id='bucket', stage='Build', title='Bucket: the algorithm goes behind an interface',
think="""
<p>Now the seam the interviewer will test. A <code>Bucket</code> is one client's budget, whatever the algorithm, with one method: <code>tryTake(now)</code>. The limiter will never name an algorithm. It is handed a <code>BucketFactory</code>, and <code>TokenBucket::new</code> is one, because the constructor has the same shape. Swapping the algorithm is then one new class and one changed line.</p>
<p>I keep the interface to what every algorithm must do. Every extra method, a <code>remaining()</code> "for later", is one more method every future algorithm must write.</p>
""",
code=[('core', 'Bucket,BucketFactory', 'Bucket and BucketFactory')],
say="Each algorithm is a Bucket, made by a factory the limiter is handed, so a new algorithm is one class and one line.",
hot='Bucket,BucketFactory', pattern=[('Strategy', 'Bucket: one interface, any algorithm'), ('Factory', 'BucketFactory, written as TokenBucket::new')],
file=('core', 'Rule,Decision,Clock,SystemClock,ManualClock,Bucket,BucketFactory'), practice=('Bucket and BucketFactory', 2)),

dict(id='tokenbucket', stage='Build', title='TokenBucket: refill on demand, spend one, or say when',
think="""
<p>The only real logic. Four numbers: the capacity, the window, the tokens left, and when they were last counted. The tokens are a <code>double</code>, because fractions build up between requests. There is no timer thread: each call first adds what the elapsed time has earned. With Acme's numbers, a capacity of 5 over 1,000 ms:</p>
<ul>
<li><b>earned</b> = elapsed × capacity ÷ window. After 200 ms Acme earns 1 token.</li>
<li><b>never above capacity.</b> After 5 quiet seconds Acme has 5, not 25.</li>
<li><b>wait</b> = (1 − tokens) × window ÷ capacity, rounded up. With 0 tokens, 200 ms.</li>
</ul>
<p><code>tryTake</code> is <code>synchronized</code>, so refill, check and spend are one step, for this bucket only. A clock reading older than the last one earns nothing, instead of a negative amount.</p>
""",
code=[('core', 'TokenBucket', 'TokenBucket')],
say="The bucket refills from elapsed time when asked, spends one token, and when it is empty says how long until the next.",
after="""<div class="trap">A timer thread that tops up every bucket every second. It does work for every idle client, and adds tokens in lumps. Working out the elapsed time when a request arrives gives the same number, and costs nothing between requests.</div>""",
hot='TokenBucket', file=('core', 'Rule,Decision,Clock,SystemClock,ManualClock,Bucket,BucketFactory,TokenBucket'),
practice=('TokenBucket: the four fields, tryTake and refill', 6)),

dict(id='rulebook', stage='Build', title='RuleBook: a default, and overrides',
think="""
<p>Which limit is a client on? A default for everyone, and an override for paid clients. The overrides map is a <code>ConcurrentHashMap</code>, because a plan can change while requests are reading it.</p>
<p>The rule book knows nothing about buckets, and buckets know nothing about it. The limiter asks it once, when it makes a client's bucket.</p>
""",
code=[('core', 'RuleBook', 'RuleBook')],
say="Rules live in a rule book: a default, and overrides by client.",
hot='RuleBook', file=('core', 'Rule,Decision,Clock,SystemClock,ManualClock,Bucket,BucketFactory,TokenBucket,RuleBook'),
practice=('RuleBook', 2)),

dict(id='limiter', stage='Build', title='LocalRateLimiter: find the client\'s bucket, then ask it',
think="""
<p>The API talks to <code>RateLimiter</code>, a one-method interface, so a Redis version can replace this one later without a caller changing. <code>LocalRateLimiter</code> owns a map from client to bucket, and is handed the rule book, the factory and the clock.</p>
<p><code>allow()</code> reads the clock once. Then <code>computeIfAbsent</code> finds or makes the bucket in one step, so two threads can never make two buckets for one new client. Then it asks the bucket. There is no lock here, on purpose: the bucket locks itself, so two clients never wait for each other.</p>
""",
code=[('core', 'RateLimiter,LocalRateLimiter', 'RateLimiter and LocalRateLimiter')],
say="The limiter reads the clock once, finds or makes the client's bucket with computeIfAbsent, and lets the bucket decide.",
after="""<div class="hole">The rule is read only when a client's bucket is made. Raise Acme's limit while the service runs, and Acme keeps its old bucket until a restart. That is follow-up 2.</div>""",
hot='RateLimiter,LocalRateLimiter', pattern=[('Dependency injection', 'the limiter is handed its rules, factory and clock')],
file=('core', 'Rule,Decision,Clock,SystemClock,ManualClock,Bucket,BucketFactory,TokenBucket,RuleBook,RateLimiter,LocalRateLimiter'),
practice=('RateLimiter and LocalRateLimiter', 5)),

dict(id='main', stage='Build', title='Main: prove it, including the race',
think="""
<p>I prove it runs. First, Acme's story from step 1: 7 at once and 5 pass; 200 ms later, one more; after 5 quiet seconds, only 5 again. Then the race: 100 threads start together on a latch, over 100 new clients with 500 each, on a frozen clock. Exactly 50,000 may pass.</p>
<p>Then I break it on purpose. Remove <code>synchronized</code> and {{mutant:nolock}}. Use a <code>get</code> then a <code>put</code> instead of <code>computeIfAbsent</code> and {{mutant:getput}}. If I can't show the race, the lock is a claim, not a fact.</p>
""",
code=[('core', 'Main', 'Main')],
out=('core', None),
say="And I prove the lock with a 100-thread race that must let exactly 50,000 through.",
hot='Main', file=('core', None), practice=('Main: Acme\'s story and the race', 8)),
]
