STEPS = [
dict(id='practice', stage='Practice', wide=True, title='Practise it from a blank file',
think="""
<p><b>Open the real project in your IDE.</b> Each is one class per file, in package <code>ratelimiter</code>, with a <code>pom.xml</code>. In IntelliJ: <i>File → Open</i>, pick the folder, and run <code>Main</code>. From a terminal: <code>./run.sh</code>.</p>
<ul>
<li><b>The core:</b> <code>~/Downloads/lld-v2/code/rate-limiter-v4/core</code> (12 files)</li>
<li><b>After all six follow-ups:</b> <code>~/Downloads/lld-v2/code/rate-limiter-v4/final</code> (20 files)</li>
</ul>
<p>Then close everything and open an empty <code>Main.java</code>. Four drills, in this order. In <b>Practice</b> mode (top right) every step hides its code until you reveal it, has its own timer, and lets you mark it <span class="ok">got it</span> or <span class="no">missed</span>. The marks show in the step list on the left.</p>
<ol>
<li><b>The skeleton</b> <span class="timer" data-min="10"><span class="tv">10:00</span><button type="button">start</button></span><br>Every type, field and method signature, with the bodies throwing <code>UnsupportedOperationException</code>. It must compile. This is the design; most of the grade is here.</li>
<li><b>The logic</b> <span class="timer" data-min="10"><span class="tv">10:00</span><button type="button">start</button></span><br><code>TokenBucket.tryTake</code>, <code>refill</code> and <code>LocalRateLimiter.allow</code>, from memory. Check the three formulas with Acme's numbers.</li>
<li><b>The whole core</b> <span class="timer" data-min="45"><span class="tv">45:00</span><button type="button">start</button></span><br>From blank to a <code>main</code> that prints Acme's story and <code>50000</code>. Then compare with the file below, and write down three things you missed.</li>
<li><b>The follow-ups</b>, 10 minutes each, each on top of the last. Before typing, say the box it lands on and the kind of change.</li>
</ol>
<p class="marks"><label><input type="checkbox" data-k="rate-limiter.read"> read</label><label><input type="checkbox" data-k="rate-limiter.coded"> coded from a blank file</label></p>
<div class="misc"><textarea data-k="rate-limiter.miss" placeholder="Miss log: three specific things the reference did that you did not. Saved in this browser."></textarea></div>
<details class="demo"><summary>The whole core, one file: Main.java</summary>
{{whole:core|Main.java · the core, about 150 lines}}
</details>
<details class="demo"><summary>The whole file after all six follow-ups</summary>
{{whole:fu6|Main.java · core + six follow-ups}}
</details>
""",
say="Skeleton, logic, whole core, then the follow-ups: say the box and the kind of change before you type."),
]
