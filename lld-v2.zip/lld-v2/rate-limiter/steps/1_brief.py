STEPS = [
dict(id='problem', stage='Brief', wide=True, title='The problem, in plain words',
think="""
<p><b>What it is.</b> A rate limiter sits in front of an API. Every request carries the caller's API key, and before any work is done the limiter answers at once: <span class="ok">allowed</span>, or <span class="no">refused, retry in 200 ms</span>. The API turns a refusal into HTTP 429 with a <code>Retry-After</code> header. Each client has a limit, such as 100 a minute, and paid plans get more. Many threads ask about the same client at the same moment.</p>
<p><b>What you must get right. This is what they grade.</b> Never more than the limit, however many threads ask at once. Bursts up to the limit are fine. The algorithm will change mid-round, so it cannot be baked into the limiter. A refusal says when to retry. And you prove all of it with a test, not a sentence.</p>
<p><b>Ask these first. If they say "you decide", assume the answer shown.</b></p>
<table>
<tr><th>ask</th><th>assume</th><th>it decides</th></tr>
<tr><td>One server, or many sharing one limit?</td><td>one process, in memory</td><td>a map in this process, behind an interface</td></tr>
<tr><td>What is a client? How many?</td><td>an API key; about 10,000</td><td>the key is a <code>String</code></td></tr>
<tr><td>Same limit for everyone?</td><td>a default, plus overrides</td><td>a <code>RuleBook</code></td></tr>
<tr><td>Bursts allowed, or evenly spaced?</td><td>bursts up to the limit</td><td>a token bucket</td></tr>
<tr><td>Exact over every 60 seconds?</td><td>close is fine</td><td>the token bucket, not a log</td></tr>
<tr><td>Refused: fail, or wait?</td><td>fail fast, say when to retry</td><td>a <code>Decision</code>, not a boolean</td></tr>
</table>
<p><b>Functional:</b> <code>allow(clientId)</code> answers allowed, or refused with a retry time. Each client has a rule: a default, with overrides. A burst up to the limit passes; after that, the limit's average rate.
<br><b>Non-functional:</b> never over the limit, whatever the thread count. O(1) per request, and one client never slows another. Tests control time, and never sleep.</p>
<p><b>A worked example you can replay in your head.</b> Acme is on 5 a second. Its bucket holds 5 tokens and earns them back at one every 200 ms.</p>
{{svg:acme}}
<p><b>What is really being tested.</b> Three things only. Can you put the algorithm behind an interface? Can you put the lock in the right place, and prove it? And when they add a requirement, do you add a class, or rewrite?</p>
""",
say="One process, in memory, keyed by API key. A token bucket per client, bursts up to the limit. A refusal carries a retry time, and I'll inject time so I can test it. Out of scope for now: many servers, waiting, forgetting idle clients."),

dict(id='algorithm', stage='Brief', wide=True, title='Pick the algorithm: a counter per minute lets through twice the limit',
think="""
<p><b>The first idea</b> is a counter per client that resets every minute. At 12:00:59.9 Acme sends 100, and all pass. The counter resets at 12:01:00. At 12:01:00.1 Acme sends 100 more, and all pass: 200 in 0.2 seconds, twice the limit.</p>
{{svg:edge}}
<p><b>The fix</b> is a token bucket. It holds 100 tokens and earns 100 a minute, a little every millisecond, and each request spends one. At 12:01:00.1 it has earned a third of a token, so the second 100 are refused, and told to retry in 400 ms.</p>
<table>
<tr><th>algorithm</th><th>keeps per client</th><th>goes wrong</th><th>use it when</th></tr>
<tr><td>fixed window</td><td>a count, and its minute</td><td>2× the limit at the edge</td><td>edges don't matter: a daily quota</td></tr>
<tr><td>sliding window log</td><td>a timestamp per request</td><td>memory: about 2.7 KB a client at 100 a minute</td><td>small exact limits: 5 logins a minute</td></tr>
<tr><td>sliding window counter</td><td>this and last minute's count</td><td>an estimate</td><td>O(1) and close is enough</td></tr>
<tr><td><b>token bucket</b></td><td>tokens, and when counted</td><td>a quiet client may burst its capacity</td><td><b>an API: O(1), bursts, an easy retry time</b></td></tr>
</table>
<p>I pick the token bucket, and name the log for small exact limits: that becomes follow-up 1.</p>
""",
say="A fixed window lets twice the limit through at the edge. I'll use a token bucket, and the exact log only for small limits."),

dict(id='classes', stage='Brief', wide=True, title='From the requirements to the classes',
think="""
<p>Five questions take me from the spec to the classes. Each answer is specific to this problem.</p>
<table>
<tr><th>I ask</th><th>here</th><th>so I get</th></tr>
<tr><td>Which nouns hold changing state?</td><td>a client's budget; the plans</td><td><code>Bucket</code>, one per client; <code>RuleBook</code></td></tr>
<tr><td>Which are plain values?</td><td>a limit; an answer</td><td><code>Rule</code> and <code>Decision</code>, as records</td></tr>
<tr><td>What will they change mid-round?</td><td>the algorithm, the limits, time, and later where budgets live</td><td>interfaces handed in: <code>BucketFactory → Bucket</code>, <code>RuleBook</code>, <code>Clock</code>, <code>RateLimiter</code></td></tr>
<tr><td>What do many threads change at once?</td><td>one client's tokens</td><td>the lock goes on the bucket; <code>computeIfAbsent</code> makes one bucket per client</td></tr>
<tr><td>Who runs the flow?</td><td>the thing the API calls</td><td><code>LocalRateLimiter</code>: find the bucket, ask it</td></tr>
</table>
<div class="trap">Two maps in the limiter: tokens by client, and last refill by client. Every request writes both in two steps, so a thread can see one updated and not the other. Each new algorithm adds more maps. One object per client that keeps its own numbers fixes both, and gives the lock an obvious home.</div>
<p>Two nouns stay out. A client is just a <code>String</code>. A request is the call itself. Neither has any state the limiter keeps.</p>
""",
say="A bucket per client behind an interface, a rule book, an injected clock, and one orchestrator that finds the bucket and asks it."),

dict(id='design', stage='Brief', wide=True, title='The whole design, up front: the picture before you type',
think="""
{{svg:classes}}
<p><b>Three layers.</b> <b>1 · Values:</b> <code>Rule</code> and <code>Decision</code>, which never change. <b>2 · The algorithm seam:</b> <code>Bucket</code>, one per client, with <code>TokenBucket</code> behind it, made by a <code>BucketFactory</code>. <b>3 · The orchestrator:</b> <code>LocalRateLimiter</code> behind <code>RateLimiter</code>, handed a rule book, a factory and a clock.</p>
<p><b>One call through the boxes.</b> <code>allow("acme")</code> reads the clock once. <code>computeIfAbsent</code> then finds Acme's bucket; the first time, it asks the rule book and calls <code>TokenBucket::new</code>. <code>tryTake(now)</code> locks Acme's bucket, refills it, then spends a token or works out the wait. The <code>Decision</code> goes back, and the API serves the request or answers 429.</p>
<p><b>Where state lives.</b> Only buckets change on every request, each with its own lock. The map changes only when a client is new. <code>Rule</code> and <code>Decision</code> never change.</p>
<p><b>Why this shape, one line each.</b> The lock sits in the bucket, because that is where the numbers are. The algorithm sits behind an interface, because it is what they will change. The limiter sits behind an interface, because "one process" is the assumption most likely to change. No Singleton, no timer thread, no factory class: <code>TokenBucket::new</code> already is one.</p>
<p>Hold this picture. The next steps build it in typing order, and the diagram on the right fills in box by box.</p>
""",
say="Three layers: values, a bucket per client behind an interface, and one orchestrator that is handed its rules, algorithm and clock."),
]
