STEPS = [
dict(id='fu1', stage='Extend', title='Follow-up 1 · "Logins: at most 5 in any minute, exactly"',
think="""
<p class="ask">“Our login endpoint allows 5 attempts a minute per user. Security says never more than 5 in any 60 seconds. Does your limiter do that?”</p>
<p class="lands">Lands on <b>Bucket</b>: a new class, and one changed line where the limiter is built.</p>
<p>No, and I say it first. A token bucket of 5 a minute earns a token every 12 seconds. So a user who spends 5 at once gets one more at 12, 24, 36 and 48 seconds: 9 in the first minute. Security's rule needs the time of every attempt, so that I can count exactly those in the last 60 seconds. That is a sliding window log. At 5 a minute it holds at most 5 timestamps per user.</p>
{{svg:fu1_n}}
""",
code=[('fu1', 'diff', '')], out=('fu1', 'fu1'),
say="The algorithm is a Bucket, so the exact log is one new class and one changed line.",
after="""<div class="hole">Memory grows with the limit: about 2.7 KB a client at 100 a minute. That is fine for logins, and wrong for a public API at 1,000 a minute, where the sliding window counter is the O(1) choice.</div>""",
new='SlidingWindowLog', hot='Bucket', file=('fu1', None), practice=('SlidingWindowLog', 8)),

dict(id='fu2', stage='Extend', title='Follow-up 2 · "Acme upgrades to 50 a second, live"',
think="""
<p class="ask">“Acme just paid for 50 a second. Ops change it in the admin screen, with no restart. When does Acme get 50?”</p>
<p class="lands">Lands on <b>LocalRateLimiter</b>: one new method.</p>
<p>With the core code, never, until a restart. <code>RuleBook.set</code> changes the book, but Acme's bucket was built with a capacity of 5 and keeps it: the hole from step 10. The fix is to set the rule, then drop the bucket, so the next request makes a new one from the new rule. The order matters. Drop first, and a request that lands in between rebuilds from the old rule.</p>
""",
code=[('fu2', 'diff', '')], out=('fu2', 'fu2'),
say="A rule is read when a bucket is made, so a plan change sets the rule, then drops the bucket, in that order.",
after="""<div class="hole">The new bucket starts full, so Acme may send a full new burst right after the change. For an upgrade, that is what they paid for. For a downgrade, carry over the share already used.</div>""",
hot='LocalRateLimiter,RuleBook', sub={'LocalRateLimiter': 'map · changeRule()'}, file=('fu2', None), practice=('changeRule', 4)),

dict(id='fu3', stage='Extend', title='Follow-up 3 · "Also cap the whole API at 1,000 a second"',
think="""
<p class="ask">“Each client keeps its own limit, but the servers take only 1,000 a second in total. A request must pass both, and a request refused by one must not use up the other.”</p>
<p class="lands">Lands on <b>Bucket</b>: a method added to the interface, then a new class. Say before typing that this one changes an interface.</p>
<p>The whole-API limit is one more token bucket, shared by every client. A request takes from its own bucket first, then from the shared one. If the shared one refuses, it gives its own token back: a <b>refund</b>. It goes to its own bucket first so that a noisy client is stopped there, and never touches the shared bucket, whose lock everyone uses. <code>BothBuckets</code> holds two buckets and is itself a <code>Bucket</code>, so the limiter never learns there are two limits.</p>
{{svg:fu3_n}}
""",
code=[('fu3a', 'diff', ''), ('fu3b', 'diff', '')], out=('fu3b', 'fu3'),
say="Two limits make a composite bucket: own first, then shared, with a refund when the shared one refuses.",
after="""<div class="hole">Between taking a token and refunding it, the client's bucket shows one fewer, for nanoseconds. It never lets through more than either limit; rarely, it refuses one it could have allowed.</div>""",
new='BothBuckets', hot='Bucket,TokenBucket,SlidingWindowLog', sub={'Bucket': 'tryTake · refund'},
pattern=[('Composite', 'BothBuckets: two buckets that look like one')], file=('fu3b', None), practice=('refund, and BothBuckets', 10)),

dict(id='fu4', stage='Extend', title='Follow-up 4 · "The batch job would rather wait than be refused"',
think="""
<p class="ask">“A nightly batch job calls the API 10,000 times. When it hits its limit it should wait its turn, not fail. Where would you not offer this?”</p>
<p class="lands">Lands on <b>RateLimiter</b>: a new class that uses it. Nothing else changes.</p>
<p>Every refusal already says when to retry, so waiting is a loop: ask; if refused, sleep for the retry time; ask again, with a deadline. It uses only the <code>RateLimiter</code> interface, so it waits on follow-up 3's two limits, and later on Redis, unchanged. I would not offer it on a public API's request path, where each waiter holds a server thread. Cap the wait, and cap how many may wait with a <code>Semaphore</code>.</p>
""",
code=[('fu4', 'diff', '')], out=('fu4', 'fu4'),
say="Waiting is a loop around allow() that sleeps for the retry time, with a deadline, for background callers only.",
after="""<div class="hole">Waiters are not served in order: two that wake together race for one token. If order matters, use a queue per client, which is the leaky bucket.</div>""",
new='Waiting', hot='RateLimiter', file=('fu4', None), practice=('Waiting.acquire', 5)),

dict(id='fu5', stage='Extend', title='Follow-up 5 · "Ten million API keys, most used once"',
think="""
<p class="ask">“We have ten million API keys, and most call once a day. How much memory does your limiter use? Fix it.”</p>
<p class="lands">Lands on <b>Bucket</b> (add <code>isIdle</code>) and <b>LocalRateLimiter</b> (add <code>evictIdle</code>).</p>
<p>The map never shrinks. A client costs about 140 bytes, measured, so ten million is about 1.4 GB. The key fact: <b>a token bucket unused for a whole window is full again</b>, exactly like a new one, so forgetting it loses nothing. Each bucket answers <code>isIdle(now)</code>. A timer removes idle ones once a minute with <code>remove(key, value)</code>, so it never removes a bucket that follow-up 2 has just replaced.</p>
""",
code=[('fu5', 'diff', '')], out=('fu5', 'fu5'),
say="An idle bucket is full, so forgetting it loses nothing; a timer removes buckets idle for a window, with remove(key, value).",
after="""<div class="hole">A request that fetched a bucket just before it was removed spends from the removed one, so that client can get one extra request. The exact fix: mark the bucket retired inside its lock, and look it up again.</div>""",
hot='Bucket,TokenBucket,SlidingWindowLog,BothBuckets,LocalRateLimiter',
sub={'Bucket': 'tryTake · refund · isIdle', 'LocalRateLimiter': 'changeRule · evictIdle'}, file=('fu5', None),
practice=('isIdle, and evictIdle', 8)),

dict(id='fu6', stage='Extend', title='Follow-up 6 · "We run twelve servers"',
think="""
<p class="ask">“We run twelve copies of the service behind a load balancer. Acme pays for 100 a minute. What does it actually get?”</p>
<p class="lands">Lands on <b>RateLimiter</b>: a new implementation. Callers, and follow-ups 3 and 4, do not change.</p>
<p>Up to 1,200: each server has its own map. Dividing the limit by 12 breaks when traffic is uneven. Pinning each client to one server breaks when servers come and go. The answer is to keep every bucket in Redis, and run refill, check and spend as one Lua script. Redis runs one script at a time, so the script is the fleet's <code>synchronized</code>. It uses Redis's clock (<code>TIME</code>), and idle keys delete themselves (<code>PEXPIRE</code>), for the same reason as follow-up 5. If Redis is down, fail open for an API and closed for logins.</p>
<p>The seam is the whole <code>RateLimiter</code>, not a store with get and put: a get, then a put, across servers is the same race as step 12.</p>
{{svg:fu6_n}}
""",
code=[('fu6', 'diff', '')], out=('fu6', 'fu6'),
say="Twelve servers share one bucket per client in Redis: one Lua script on Redis's clock, idle keys expire, and callers don't change.",
after="""<div class="hole">Every request now pays a round trip to Redis, about 0.5 ms. If that is too slow, each server takes tokens from Redis in batches of 10 and spends them locally. <span class="mut">The Lua was run under Lua 5.1, the version inside Redis, against a stand-in for TIME, HMGET, HSET and PEXPIRE, and it gave the Java bucket's answers.</span></div>""",
new='RedisRateLimiter', hot='RateLimiter', file=('fu6', None), practice=('RedisRateLimiter and its script', 10)),
]
