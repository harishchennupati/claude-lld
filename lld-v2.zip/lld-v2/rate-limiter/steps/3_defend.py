STEPS = [
dict(id='concurrency', stage='Defend', title='Concurrency: two gaps, one lock per client, and the upgrade you name',
think="""
<p><b>The race lives in two gaps.</b> Inside a bucket, two threads both read "1 token" and both spend it. In the map, two threads both find no bucket for a new client, and both make one. <code>synchronized tryTake</code> closes the first gap; <code>computeIfAbsent</code> closes the second.</p>
{{svg:race_n}}
<p><b>Why here, and not elsewhere.</b> A <code>synchronized allow()</code> is correct, but it is one lock for the whole API, so every client waits for every other. An <code>AtomicLong</code> is not enough, because two numbers must change together: the tokens, and when they were counted.</p>
<p><b>Say this unprompted:</b> "One lock per client is honestly enough." One <code>allow()</code> takes about 7 ns. Fourteen threads hammering one client still get 23 million decisions a second through its lock, and 330 million across fourteen clients, because no two clients share a lock. That was measured on an Apple M4 Pro with JDK 17. If they push for lock-free, keep both numbers in one immutable <code>State</code> and swap it with <code>compareAndSet</code>. A thread that loses the swap retries.</p>
""",
code=[('extra', 'CasTokenBucket', 'the lock-free version, if they ask: CasTokenBucket')],
say="The race is in two gaps: the bucket's read-then-write, closed by synchronized, and the map's check-then-put, closed by computeIfAbsent. One lock per client is enough; compare-and-set is the upgrade.",
hot='TokenBucket,LocalRateLimiter', file=('core', None), practice=('the lock-free CasTokenBucket', 8)),

dict(id='pokes', stage='Defend', title='The pokes: two-breath answers',
think="""
<table class="poke">
<tr><td>Why is the lock in the bucket?</td><td>The numbers that must change together live there. A lock on the limiter makes every client wait for every other.</td></tr>
<tr><td>Why <code>computeIfAbsent</code>?</td><td>With a get, then a put, two threads make two buckets for one new client, and each spends from its own full bucket.</td></tr>
<tr><td>Why aren't the tokens volatile?</td><td>Every read and write is inside the bucket's lock, and the lock also publishes the writes to the next thread.</td></tr>
<tr><td>The clock jumps back?</td><td><code>nanoTime</code> never goes back, and an older reading earns nothing.</td></tr>
<tr><td>Test a refill without sleeping?</td><td>Hand in a <code>ManualClock</code> and call <code>advance(200)</code>.</td></tr>
<tr><td>Why an interface with one implementation?</td><td>"One process" is the assumption most likely to change. Follow-up 6 replaces it, and no caller changes.</td></tr>
<tr><td>Enum with a switch, or an interface?</td><td>An interface: each algorithm is a class with its own state. An enum is fine for picking a factory from config.</td></tr>
<tr><td>Limits per endpoint?</td><td>Make the key the client plus the endpoint, such as <code>acme:/search</code>. The limiter only ever sees a string.</td></tr>
<tr><td>A stricter limit, without hurting anyone?</td><td>Shadow mode: a decorator that counts what it would refuse, and lets everything through. Code below.</td></tr>
<tr><td>Hits in the last 5 minutes (LeetCode 362)?</td><td>300 slots, one per second, reused. Code below.</td></tr>
<tr><td>A double for tokens: any risk?</td><td>It is exact up to about 9 × 10<sup>15</sup>, and the fractions only set a rounded-up wait.</td></tr>
<tr><td>Where is the Singleton?</td><td>Nowhere. One limiter per process is wiring, and a static one would make tests share buckets.</td></tr>
</table>
<p><b>SOLID, in one breath each.</b> <b>S</b>: the bucket does arithmetic, the limiter finds buckets, the rule book knows plans. <b>O</b>: follow-ups 1, 3, 4 and 6 are new classes. <b>L</b>: <code>SlidingWindowLog</code> replaces <code>TokenBucket</code>, and nobody notices. <b>I</b>: every interface has one to three methods. <b>D</b>: the limiter is handed its rules, factory and clock.</p>
{{named:extra:shadow|ShadowLimiter: a decorator over any RateLimiter}}
{{named:extra:hits|HitCounter: 300 reused slots}}
""",
say="Every poke gets a class, a number or a line of code, never an adjective.",
hot='', pattern=[('Decorator', 'ShadowLimiter, wrapping any RateLimiter')], file=('core', None)),
]
