"""Build an LLD page with a code dock.   python3 tools/lld.py rate-limiter

Inputs (in <name>/):
  wb/Main.java   master source. Lines outside markers are the core. A block
                     //@ from fu3a [proof|design] [name=x]
                     ...
                     //@ end
                 is visible from snapshot fu3a onward. Snapshots, in order: SNAPS below.
  page.html      the reading content, with placeholders and dock sections (see README in BLUEPRINT).
  figures.py     fig_<x>() -> <svg>
Output: <name>.html (self-contained).

Every snapshot is compiled with -Xlint:all -Werror and run; its output is what the page shows.
"""
import difflib, html, importlib.util, json, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from lldkit import hl  # noqa: E402

SNAPS = ['core', 'fu1', 'fu2', 'fu3a', 'fu3b', 'fu4', 'fu5', 'fu6', 'extra']
MARK = re.compile(r'^\s*//@\s+from\s+(\S+)((?:\s+\S+)*)\s*$')
END = re.compile(r'^\s*//@\s+end\s*$')


# ----------------------------------------------------------------------------- snapshots
def parse_master(path):
    """Returns [(text, step_index, flag, name, until_index)] for every non-marker line.
    A block '//@ from a until b' is visible from snapshot a up to, not including, snapshot b."""
    rows, stack = [], []
    for ln in open(path, encoding='utf-8').read().split('\n'):
        m = MARK.match(ln)
        if m:
            attrs = m.group(2).split()
            flag = next((a for a in attrs if a in ('proof', 'design')), None)
            name = next((a[5:] for a in attrs if a.startswith('name=')), None)
            until = len(SNAPS)
            if 'until' in attrs:
                until = SNAPS.index(attrs[attrs.index('until') + 1])
            stack.append((SNAPS.index(m.group(1)), flag, name, until))
            continue
        if END.match(ln):
            stack.pop()
            continue
        step = max([x[0] for x in stack], default=0)
        until = min([x[3] for x in stack], default=len(SNAPS))
        flag = next((x[1] for x in reversed(stack) if x[1]), 'design')
        name = next((x[2] for x in reversed(stack) if x[2]), None)
        rows.append((ln, step, flag, name, until))
    return rows


def snapshot(rows, snap, with_step=False):
    k = SNAPS.index(snap)
    out = [(t, f, n, s) for t, s, f, n, u in rows if s <= k < u]
    # collapse runs of blank lines left behind by hidden blocks
    res = []
    for t, f, n, s in out:
        if not t.strip() and res and not res[-1][0].strip():
            continue
        res.append((t, f, n, s))
    return res if with_step else [(t, f, n) for t, f, n, _ in res]


def added_lines(rows, snap):
    """Indices of the non-blank lines that first appear in this snapshot: exact, from the markers."""
    k = SNAPS.index(snap)
    return {i for i, (t, f, n, s) in enumerate(snapshot(rows, snap, True)) if s == k and t.strip()}


def compile_run(text, runs=1):
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, 'Main.java')
        open(p, 'w').write(text)
        c = subprocess.run(['javac', '-Xlint:all', '-Werror', '-d', d, p], capture_output=True, text=True)
        if c.returncode:
            raise SystemExit('javac failed:\n' + c.stderr + '\n' + text[:400])
        outs = []
        for _ in range(runs):
            r = subprocess.run(['java', '-cp', d, 'Main'], capture_output=True, text=True, timeout=120)
            outs.append((r.returncode, (r.stdout + r.stderr).rstrip('\n')))
        return outs


# ----------------------------------------------------------------------------- outline parser
TYPE_RE = re.compile(r'^(?:public\s+|final\s+|abstract\s+)*(class|interface|record|enum)\s+(\w+)')


def outline(lines):
    """Top-level types and their members, from consistently formatted Java (4-space indent)."""
    types, i, n = [], 0, len(lines)
    while i < n:
        m = TYPE_RE.match(lines[i])
        if not m:
            i += 1
            continue
        start = i
        while start > 0 and lines[start - 1].startswith('//'):
            start -= 1
        if lines[i].rstrip().endswith('}') and lines[i].count('{') == lines[i].count('}'):
            end = i                                   # one-line type, e.g. record X(...) { }
        else:
            end = next(j for j in range(i + 1, n) if lines[j] == '}')
        t = dict(name=m.group(2), kind=m.group(1), start=start, decl=i, end=end, members=[])
        j = i + 1
        pending = None                                # first comment/annotation line above a member
        while j < end:
            ln = lines[j]
            if not ln.strip():
                pending = None
                j += 1
                continue
            ind = len(ln) - len(ln.lstrip())
            body = ln.strip()
            if ind == 4 and (body.startswith('//') or re.fullmatch(r'@\w+(\(.*\))?', body)):
                if pending is None:
                    pending = j
                j += 1
                continue
            if ind != 4:
                j += 1
                continue
            # a member starts here; find where its declaration ends
            k = j
            if '"""' in body and body.count('"""') == 1:          # text-block field
                k = next(x for x in range(j + 1, end) if '"""' in lines[x])
                mem = dict(kind='field', open=None, close=k)
            else:
                while not re.search(r'[;{}]\s*(//.*)?$', lines[k].rstrip()) and k + 1 < end:
                    k += 1
                last = re.sub(r'//.*$', '', lines[k]).rstrip()
                if last.endswith('{'):
                    close = next(x for x in range(k + 1, end) if lines[x] == '    }')
                    mem = dict(kind='method', open=k, close=close)
                elif '{' in last and last.endswith('}'):
                    mem = dict(kind='method1', open=k, close=k)
                elif last.endswith(';') and '(' in body and re.search(r'\)\s*(throws [\w, ]+)?;', last) \
                        and t['kind'] == 'interface':
                    mem = dict(kind='abstract', open=None, close=k)
                else:
                    mem = dict(kind='field', open=None, close=k)
            head = re.sub(r'//.*$', '', ' '.join(lines[x].strip() for x in range(j, (mem['open'] or mem['close']) + 1)))
            if mem['kind'] == 'field':
                nm = re.search(r'(\w+)\s*(=|;)', head)
                name = nm.group(1) if nm else 'field'
            else:
                nm = re.search(r'(\w+)\s*\(', head) or re.search(r'(\w+)\s*\{', head)
                name = nm.group(1) if nm else 'member'
            mem.update(name=name, start=pending if pending is not None else j, decl=j, end=mem['close'])
            t['members'].append(mem)
            pending = None
            j = mem['close'] + 1
        types.append(t)
        i = end + 1
    return types


def design_variant(text):
    """The line as shown in design view: a body becomes { … }."""
    code, cm = text, ''
    mm = re.search(r'\s+//.*$', text)
    if mm:
        code, cm = text[:mm.start()], text[mm.start():]
    s = code.rstrip()
    if s.endswith('{'):
        return s + ' … }' + cm
    if '{' in s and s.endswith('}'):
        if not s[s.index('{') + 1:-1].strip():
            return text                               # an empty body stays { }
        return s[:s.index('{') + 1] + ' … }' + cm
    if '"""' in s:
        return s[:s.index('"""')] + '""" … """;' + cm
    return text


def hl_lines(lines):
    """Highlight line by line, carrying text-block state across lines."""
    out, in_tb = [], False
    for ln in lines:
        if in_tb:
            if '"""' in ln:
                k = ln.index('"""') + 3
                out.append(f'<span class="s">{html.escape(ln[:k])}</span>' + hl(ln[k:]))
                in_tb = False
            else:
                out.append(f'<span class="s">{html.escape(ln)}</span>')
            continue
        if ln.count('"""') == 1:
            k = ln.index('"""')
            out.append(hl(ln[:k]) + f'<span class="s">{html.escape(ln[k:])}</span>')
            in_tb = True
            continue
        out.append(hl(ln))
    return out


# ----------------------------------------------------------------------------- page
def main(name):
    root = os.path.dirname(HERE)
    d = os.path.join(root, name)
    rows = parse_master(os.path.join(d, 'wb', 'Main.java'))
    cfg_path = os.path.join(d, 'wb', 'config.py')
    cfg = {}
    if os.path.exists(cfg_path):
        exec(open(cfg_path).read(), cfg)

    snaps, outputs = {}, {}
    for s in SNAPS:
        lines = snapshot(rows, s)
        text = '\n'.join(t for t, _, _ in lines) + '\n'
        (code, out), = compile_run(text)
        if code:
            raise SystemExit(f'snapshot {s} failed:\n{out}')
        snaps[s], outputs[s] = lines, out
        print(f'  {s:6} {len(lines):4} lines, runs ok')

    # mutants: broken copies of a snapshot, run several times
    mutants = {}
    for mname, (base, subs, runs) in cfg.get('MUTANTS', {}).items():
        text = '\n'.join(t for t, _, _ in snaps[base]) + '\n'
        for a, b in subs:
            if a not in text:
                raise SystemExit(f'mutant {mname}: pattern not found: {a}')
            text = text.replace(a, b, 1)
        res = compile_run(text, runs)
        mutants[mname] = res
        print(f'  mutant {mname}: {sum(1 for c, _ in res if c)} of {runs} runs failed')

    # dock data: one entry per snapshot
    table, index = [], {}
    def lid(h):
        if h not in index:
            index[h] = len(table)
            table.append(h)
        return index[h]
    dock = {}
    prev = None
    prev_types = None

    def footprint(typs, added, before):
        if before is None:
            return []
        res = []
        for t in typs:
            k = sum(1 for x in added if t['start'] <= x <= t['end'])
            if k:
                res.append(dict(n=t['name'], add=k, new=t['name'] not in before))
        return res
    for s in SNAPS:
        texts = [t for t, _, _ in snaps[s]]
        hs = hl_lines(texts)
        typs = outline(texts)
        design_line = {}
        for t in typs:
            for m in t['members']:
                if m['kind'] in ('method', 'method1'):
                    design_line[m['open']] = hl_lines([design_variant(texts[m['open']])])[0]
                elif m['kind'] == 'field' and m['close'] != m['decl']:
                    design_line[m['decl']] = hl_lines([design_variant(texts[m['decl']])])[0]
        added = sorted(added_lines(rows, s)) if prev is not None else []
        dock[s] = dict(
            L=[lid(h) for h in hs],
            D={str(k): lid(v) for k, v in design_line.items()},
            P=[i for i, (_, f, _) in enumerate(snaps[s]) if f == 'proof'],
            T=[dict(n=t['name'], k=t['kind'], s=t['start'], d=t['decl'], e=t['end'],
                    m=[dict(n=m['name'], k=m['kind'], s=m['start'], d=m['decl'], o=m['open'], e=m['end'])
                       for m in t['members']])
               for t in typs],
            A=added,
            F=footprint(typs, added, prev_types))
        prev_types = {t['name'] for t in typs}
        prev = s

    # figures
    spec = importlib.util.spec_from_file_location('figures', os.path.join(d, 'figures.py'))
    assert spec is not None and spec.loader is not None
    figs = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(figs)

    pdir = os.path.join(d, 'page')                    # the page, written as numbered parts
    page = ''.join(open(os.path.join(pdir, f), encoding='utf-8').read()
                   for f in sorted(os.listdir(pdir)) if f.endswith('.html'))

    def find_member(s, spec_):
        """'Type' or 'Type.member' or 'Type.fields' -> (first, last) line index in snapshot s."""
        typs = outline([t for t, _, _ in snaps[s]])
        tn, _, mn = spec_.partition('.')
        t = next((t for t in typs if t['name'] == tn), None)
        if t is None:
            raise SystemExit(f'{s}: no type {tn}')
        if not mn:
            return t['start'], t['end']
        if mn == 'fields':
            ms = [m for m in t['members'] if m['kind'] == 'field']
        else:
            ms = [m for m in t['members'] if m['name'] == mn]
        if not ms:
            raise SystemExit(f'{s}: no member {spec_}')
        return min(m['start'] for m in ms), max(m['end'] for m in ms)

    def code_of(s, specs, label=''):
        texts = [t for t, _, _ in snaps[s]]
        spans = sorted(find_member(s, x.strip()) for x in specs.split(','))
        parts = []
        for a, b in spans:
            parts.append('\n'.join(texts[a:b + 1]))
        body = '\n    …\n'.join(p for p in parts)
        ind = min((len(l) - len(l.lstrip()) for l in body.split('\n') if l.strip()), default=0)
        body = '\n'.join(l[ind:] for l in body.split('\n'))
        return code_block(body, label)

    def code_block(body, label, cls=''):
        lines = body.split('\n')
        h = '\n'.join(hl_lines(lines))
        return (f'<div class="cb {cls}"><div class="cbh"><span class="cbl">{html.escape(label)}</span>'
                f'<button class="cp" type="button">copy</button></div><pre><code>{h}</code></pre></div>')

    def out_block(text, label):
        return (f'<div class="cb out"><div class="cbh"><span class="cbl">{html.escape(label)}</span></div>'
                f'<pre><code>{html.escape(text)}</code></pre></div>')

    def sub(m):
        kind, arg = m.group(1), m.group(2)
        a = arg.split('|')
        if kind == 'svg':
            return getattr(figs, 'fig_' + a[0])()
        if kind == 'snippet':            # {{snippet:core:TokenBucket.tryTake,TokenBucket.refill|label}}
            s, specs = a[0].split(':', 1)
            return code_of(s, specs, a[1] if len(a) > 1 else '')
        if kind == 'named':              # {{named:extra:cas|label}} a //@ name= block
            s, nm = a[0].split(':')
            body = '\n'.join(t for t, _, n in snaps[s] if n == nm).strip('\n')
            return code_block(body, a[1] if len(a) > 1 else '')
        if kind == 'whole':
            return code_block('\n'.join(t for t, _, _ in snaps[a[0]]).strip('\n'), a[1] if len(a) > 1 else 'Main.java')
        if kind == 'out':                # {{out:core}} or {{out:fu3b:fu3}}
            parts = a[0].split(':')
            text = outputs[parts[0]]
            if len(parts) > 1:
                text = '\n'.join(l for l in text.split('\n') if l.startswith(parts[1] + ' '))
            return out_block(text, 'output · java Main' + (' · ' + a[1] if len(a) > 1 else ''))
        if kind == 'mutant':             # {{mutant:nolock}}
            res = mutants[a[0]]
            lines = []
            whys = []
            for code, out in res:
                seen = [l for l in out.split('\n') if l.startswith(('race', 't=5200'))]
                what = re.sub(r'\s+', ' ', seen[-1].split(':')[-1]).strip() if seen else ''
                why = re.search(r'broken: (.*)$', out, flags=re.M)
                if why:
                    whys.append(why.group(1))
                lines.append(('FAIL  ' if code else 'pass  ') + what)
            if whys and len(set(whys)) == 1:
                lines.append(f'→ every failing run broke the check: "{whys[0]}"')
            return out_block('\n'.join(lines), f'{len(res)} run{"s" if len(res) > 1 else ""} of the broken copy')
        raise SystemExit('unknown placeholder ' + m.group(0))

    page = re.sub(r'\{\{(svg|snippet|named|whole|out|mutant):([^}]*)\}\}', sub, page)

    # data-find="text" inside a dock section -> data-lines="a-b" (1-based) in that section's snapshot
    def resolve_finds(html_):
        out, pos = [], 0
        for sec in re.finditer(r'<section[^>]*data-snap="(\w+)"[^>]*>.*?</section>', html_, flags=re.S):
            out.append(html_[pos:sec.start()])
            s = sec.group(1)
            texts = [t for t, _, _ in snaps[s]]

            def rep(mm):
                needle = html.unescape(mm.group(1))
                hits = [i for i, t in enumerate(texts) if needle in t]
                if not hits:
                    raise SystemExit(f'{s}: data-find not found: {needle}')
                n = int(mm.group(2) or 1)
                return f'data-lines="{hits[0] + 1}-{hits[0] + n}"'
            out.append(re.sub(r'data-find="([^"]+)"(?:\s+data-n="(\d+)")?', rep, sec.group(0)))
            pos = sec.end()
        out.append(html_[pos:])
        return ''.join(out)
    page = resolve_finds(page)
    left = re.findall(r'\{\{[^}]*\}\}|data-find=', page)
    if left:
        raise SystemExit('unresolved: ' + ', '.join(left[:5]))

    data = json.dumps(dict(lines=table, snaps=dock), separators=(',', ':'))
    page = page.replace('/*DOCK_DATA*/', 'const DOCK=' + data + ';')
    target = os.path.join(root, name + '.html')
    open(target, 'w', encoding='utf-8').write(page)
    print('wrote', target, f'{len(page):,} bytes')
    check(page)
    return outputs


def check(page):
    """What a script can check: links, 'move N' references, sentence length, words outside folds."""
    ids = set(re.findall(r'id="([^"]+)"', page))
    bad = sorted(set(re.findall(r'href="#([^"]+)"', page)) - ids)
    body = page.split('<main>', 1)[1]
    body = re.sub(r'<script.*?</script>|<svg.*?</svg>|<div class="cb[^"]*".*?</pre></div>|<aside.*?</aside>', '', body, flags=re.S)
    text = lambda x: ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', x)).split())
    moves = re.findall(r'\b(?:move|card)\s+\d+', text(body), flags=re.I)
    long = []
    for tag, b in re.findall(r'<(p|li|td|h2|h3)[^>]*>(.*?)</\1>', body, flags=re.S):
        for sent in re.split(r'(?<=[.!?;])\s+(?=[A-Z"\u201c(])', text(b)):
            if len(sent.split()) > 35:
                long.append(sent)
    nofold = re.sub(r'<details.*?</details>|<div class="narrow">.*?</div>\s*</section>', '</section>', body, flags=re.S)
    print(f'check: {len(text(nofold).split()):,} words outside folds; broken links {bad or "none"}; '
          f'"move N" {moves or "none"}; sentences over 35 words: {len(long)}')
    for x in long:
        print('   long:', x[:150])


if __name__ == '__main__':
    main(sys.argv[1])
