// Scroll to sections like a reader would, and screenshot the viewport at each.
// node shoot-at.mjs <url> <outPrefix> <width> <height> <id1,id2,...> [offsetPx]
import { spawn } from 'node:child_process';
import { writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const [url, prefix, W, H, ids, OFF = '60'] = process.argv.slice(2);
const CH = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const port = 9800 + Math.floor(Math.random() * 150);
const prof = mkdtempSync(join(tmpdir(), 'chprof-'));
const chrome = spawn(CH, ['--headless=new', '--disable-gpu', '--hide-scrollbars', `--remote-debugging-port=${port}`,
  `--user-data-dir=${prof}`, `--window-size=${W},${H}`, 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let ws;
let opened;
for (let i = 0; i < 50; i++) {
  try {
    const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const page = list.find(t => t.type === 'page');
    if (page) { ws = new WebSocket(page.webSocketDebuggerUrl); opened = new Promise(r => ws.addEventListener('open', r)); break; }
  } catch (e) {}
  await sleep(200);
}
await opened;
let id = 0; const pending = new Map();
ws.addEventListener('message', ev => { const m = JSON.parse(ev.data); if (m.method === 'Runtime.exceptionThrown') console.log('PAGE EXCEPTION', JSON.stringify(m.params.exceptionDetails).slice(0, 400)); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } });
const send = (method, params = {}) => Promise.race([new Promise(r => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); }), sleep(20000).then(() => { throw new Error('timeout ' + method); })]);
console.log('connected'); await send('Page.enable'); await send('Runtime.enable');
await send('Emulation.setDeviceMetricsOverride', { width: +W, height: +H, deviceScaleFactor: 1, mobile: false });
await send('Page.navigate', { url });
await sleep(1500);
const errs = await send('Runtime.evaluate', { expression: 'typeof DOCK', returnByValue: true });
console.log('DOCK:', errs.result.result.value);
let k = 0;
for (const sel of ids.split(',')) {
  if (sel.startsWith('!')) {                    // run some JS on the page (e.g. switch a mode), no screenshot
    await send('Runtime.evaluate', { expression: sel.slice(1) });
    await sleep(600);
    continue;
  }
  if (sel.startsWith('~')) {                    // hover an element (scrolled into view), then shoot
    const r = await send('Runtime.evaluate', { returnByValue: true, expression: `(function(){const e=document.querySelector(${JSON.stringify(sel.slice(1))}); if(!e) return null; e.scrollIntoView({block:'center', behavior:'instant'}); return 1;})()` });
    await sleep(500);
    const r2 = await send('Runtime.evaluate', { returnByValue: true, expression: `(function(){const b=document.querySelector(${JSON.stringify(sel.slice(1))}).getBoundingClientRect(); return [b.left+60, b.top+b.height/2];})()` });
    const xy = r.result.result.value ? r2.result.result.value : null;
    if (xy) { await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: xy[0], y: xy[1] }); await sleep(400); }
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    writeFileSync(`${prefix}_${String(k).padStart(2, '0')}_hover.png`, Buffer.from(shot.result.data, 'base64'));
    console.log(sel, xy ? 'ok' : 'missing'); k++; continue;
  }
  if (sel.startsWith('@')) {                    // scroll an element into view inside the page, then shoot
    await send('Runtime.evaluate', { expression: `(function(){const e=document.querySelector(${JSON.stringify(sel.slice(1))}); if(e) e.scrollIntoView({block:'start'});})()` });
    await sleep(700);
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    writeFileSync(`${prefix}_${String(k).padStart(2, '0')}_at.png`, Buffer.from(shot.result.data, 'base64'));
    console.log(sel, 'ok'); k++; continue;
  }
  if (sel.startsWith('#')) {                    // a step of a step-by-step page: load it by its hash
    await send('Page.navigate', { url: url.split('#')[0] + sel });
    await sleep(1100);
    const shot = await send('Page.captureScreenshot', { format: 'png' });
    writeFileSync(`${prefix}_${String(k).padStart(2, '0')}_${sel.slice(1)}.png`, Buffer.from(shot.result.data, 'base64'));
    console.log(sel, 'ok'); k++; continue;
  }
  const expr = `(function(){const e=document.getElementById(${JSON.stringify(sel)}); if(!e) return 'missing';
    window.scrollTo(0, e.getBoundingClientRect().top + window.scrollY - ${+OFF}); window.dispatchEvent(new Event('scroll')); return 'ok';})()`;
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
  await sleep(900);
  const shot = await send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(`${prefix}_${String(k).padStart(2, '0')}_${sel}.png`, Buffer.from(shot.result.data, 'base64'));
  console.log(sel, r.result.result.value);
  k++;
}
ws.close(); chrome.kill(); process.exit(0);
