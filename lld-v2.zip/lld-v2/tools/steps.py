"""Build a step-by-step LLD workbench.   python3 tools/steps.py rate-limiter

Code comes from <name>/wb/Main.java (the master, with //@ from <snap> blocks), compiled and run per snapshot.
Steps come from <name>/steps/*.py, each defining STEPS = [dict(...), ...], joined in file-name order.
The app shell is tools/steps_shell/*.html. Output: <name>-steps.html.

A step:
  id, stage ('Brief' | 'Build' | 'Defend' | 'Extend' | 'Practice'), title, wide (no right panel)
  think    HTML, first person. May hold {{svg:x}}, {{out:snap[:prefix]}}, {{mutant:name}}, {{named:snap:x|label}}
  code     [(snap, 'Type,Type.member', label)] or [(snap, 'diff', '')] for a follow-up's new code
  out      (snap, prefix or None)       the real output shown under the code
  say      one sentence
  after    HTML after the code (the one hole, pushes)
  hot/new  diagram nodes lit (hot) or new in this step (new); sub = {node: new sub-label}
  pattern  [(name, where)] named when earned
  file     (snap, 'Type,Type' or None)  the "file so far" tab
  practice (task, minutes)
"""
import html, importlib.util, json, os, re, sys, glob

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lld  # noqa: E402

CORE_TYPES_OF_NODE = {'Clock': ['Clock', 'SystemClock', 'ManualClock'], 'RedisRateLimiter': ['Redis', 'RedisRateLimiter']}


def main(name):
    root = os.path.dirname(HERE)
    d = os.path.join(root, name)
    cfg = {}
    if os.path.exists(os.path.join(d, 'wb', 'config.py')):
        exec(open(os.path.join(d, 'wb', 'config.py')).read(), cfg)
    lld.SNAPS = cfg.get('SNAPS', lld.SNAPS)        # a problem may name its own snapshots
    rows = lld.parse_master(os.path.join(d, 'wb', 'Main.java'))

    snaps, outs, texts, typs, added = {}, {}, {}, {}, {}
    prev = None
    for s in lld.SNAPS:
        lines = lld.snapshot(rows, s)
        text = '\n'.join(t for t, _, _ in lines) + '\n'
        (code, out), = lld.compile_run(text)
        if code:
            raise SystemExit(f'{s} failed:\n{out}')
        snaps[s], outs[s] = lines, out
        texts[s] = [t for t, _, _ in lines]
        typs[s] = lld.outline(texts[s])
        added[s] = lld.added_lines(rows, s) if prev else set()
        prev = s
        print(f'  {s:6} {len(lines):4} lines, compiled and ran')

    mutants = {}
    for mname, (base, subs, runs) in cfg.get('MUTANTS', {}).items():
        text = '\n'.join(texts[base]) + '\n'
        for x, y in subs:
            assert x in text, f'mutant {mname}: {x}'
            text = text.replace(x, y, 1)
        mutants[mname] = lld.compile_run(text, runs)
        print(f'  mutant {mname}: {sum(1 for c, _ in mutants[mname] if c)} of {runs} runs failed')

    spec = importlib.util.spec_from_file_location('figures', os.path.join(d, 'figures.py'))
    assert spec is not None and spec.loader is not None
    figs = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(figs)

    steps = []
    for f in sorted(glob.glob(os.path.join(d, 'steps', '*.py'))):
        g = {}
        exec(open(f, encoding='utf-8').read(), g)
        steps += g['STEPS']

    # ---------------------------------------------------------------- helpers
    def block(code, label, cls='code', callouts=None):
        """A code block. callouts = {line index: number} puts a numbered badge on those lines."""
        lines = code.split('\n')
        hs = lld.hl_lines(lines)
        callouts = callouts or {}
        rows = ''.join(f'<span class="cl"{f" data-co=\"{callouts[i]}\"" if i in callouts else ""}>{h or " "}</span>'
                       for i, h in enumerate(hs))
        walked = ' walked' if callouts else ''
        return (f'<div class="cb {cls}{walked}" data-n="{len(lines)}"><div class="cbh"><span class="cbl">{html.escape(label)}</span>'
                f'<button class="cp" type="button">copy</button></div><pre><code>{rows}</code></pre></div>')

    def outblock(text, label='output · java Main'):
        return (f'<div class="cb out"><div class="cbh"><span class="cbl">{html.escape(label)}</span></div>'
                f'<pre><code>{html.escape(text)}</code></pre></div>')

    def dedent(lines):
        ind = min((len(l) - len(l.lstrip()) for l in lines if l.strip()), default=0)
        return [l[ind:] for l in lines]

    def span_of(s, spec_):
        tn, _, mn = spec_.partition('.')
        t = next((t for t in typs[s] if t['name'] == tn), None)
        if not t:
            raise SystemExit(f'{s}: no type {tn}')
        if not mn:
            return [(t['start'], t['end'])]
        ms = [m for m in t['members'] if (m['kind'] == 'field' if mn == 'fields' else m['name'] == mn)]
        if not ms:
            raise SystemExit(f'{s}: no member {spec_}')
        return [(m['start'], m['end']) for m in ms]

    def code_for(s, specs):
        spans = []
        for x in specs.split(','):
            spans += span_of(s, x.strip())
        spans.sort()
        parts = [dedent(texts[s][a:b + 1]) for a, b in spans]
        out = []
        for i, p in enumerate(parts):
            if i:
                out.append('')
            out += p
        return '\n'.join(out), {i for a, b in spans for i in range(a, b + 1)}

    proof = {s: {i for i, (_, f, _) in enumerate(snaps[s]) if f == 'proof'} for s in lld.SNAPS}

    def diff_blocks(s):
        """A follow-up's new code, as pieces: a new class whole, or the new members of a changed class."""
        pieces, lines_hl, demo = [], set(), []
        prev_names = {x['name'] for x in typs[lld.SNAPS[lld.SNAPS.index(s) - 1]]}
        for t in typs[s]:
            new = [i for i in added[s] if t['start'] <= i <= t['end']]
            if not new:
                continue
            if t['name'] == 'Main':
                ms = [m for m in t['members'] if any(m['start'] <= i <= m['end'] for i in new) and m['name'] != 'main']
                code = '\n\n'.join('\n'.join(dedent(texts[s][m['start']:m['end'] + 1])) for m in ms)
                design = any(i not in proof[s] for m in ms for i in range(m['start'], m['end'] + 1) if i in added[s])
                demo.append((code, 'Main', 'code demo', 'open' if design else 'closed'))
                continue
            if t['name'] not in prev_names:
                pieces.append(('\n'.join(texts[s][t['start']:t['end'] + 1]), f'new {t["kind"]} · {t["name"]}', 'code', None))
                lines_hl |= set(range(t['start'], t['end'] + 1))
            else:
                ms = [m for m in t['members'] if any(m['start'] <= i <= m['end'] for i in new)]
                code = '\n\n'.join('\n'.join(dedent(texts[s][m['start']:m['end'] + 1])) for m in ms)
                pieces.append((code, f'in {t["name"]}: add', 'code', None))
                lines_hl |= set(new)
        return pieces + demo, lines_hl

    def fill(h):
        def sub(m):
            kind, arg = m.group(1), m.group(2)
            a = arg.split('|')
            if kind == 'svg':
                return f'<figure>{getattr(figs, "fig_" + a[0])()}</figure>'
            if kind == 'out':
                s, _, pre = a[0].partition(':')
                t = outs[s]
                if pre:
                    t = '\n'.join(l for l in t.split('\n') if l.startswith(pre + ' '))
                return outblock(t)
            if kind == 'code':
                s, specs = a[0].split(':', 1)
                code, ls = code_for(s, specs)
                inline_hl.update(ls)
                return block(code, a[1] if len(a) > 1 else specs.replace(',', ', '))
            if kind == 'whole':
                return block('\n'.join(texts[a[0]]).strip('\n'), a[1] if len(a) > 1 else 'Main.java')
            if kind == 'named':
                s, nm = a[0].split(':')
                return block('\n'.join(t for t, _, n in snaps[s] if n == nm).strip('\n'), a[1] if len(a) > 1 else nm)
            if kind == 'mutant':
                res = mutants[a[0]]
                fails = sum(1 for c, _ in res if c)
                groups = {}                                  # broken check -> the counts it let through
                for c, o in res:
                    w = re.search(r'broken: (.*)$', o, flags=re.M)
                    why = w.group(1) if w else 'passed'
                    last = [l for l in o.split('\n') if l.strip() and not l.startswith(('Exception', '\tat', 'Caused'))]
                    num = None
                    if last and last[-1].startswith(('race', 'after')):
                        num = int(re.sub(r'\D', '', last[-1].split(':')[-1]))
                    groups.setdefault(why, []).append(num)
                parts = []
                for why, nums in sorted(groups.items(), key=lambda kv: -len(kv[1])):
                    ns = sorted(n for n in nums if n is not None)
                    rng = ''
                    if ns:
                        rng = f', letting {ns[0]:,}' + (f' to {ns[-1]:,}' if ns[-1] != ns[0] else '') + ' through'
                    parts.append(f'{len(nums)} fail “{why}”{rng}')
                txt = f'{fails} of {len(res)} runs fail: ' + '; '.join(parts) if len(groups) > 1 else \
                      f'{fails} of {len(res)} runs fail “{next(iter(groups))}”' + (
                          f', letting {min(n for n in groups[next(iter(groups))] if n is not None):,} to '
                          f'{max(n for n in groups[next(iter(groups))] if n is not None):,} through'
                          if any(n is not None for n in groups[next(iter(groups))]) else '')
                return f'<span class="mut-sum">{txt}</span>'
            raise SystemExit('bad placeholder ' + m.group(0))
        return re.sub(r'\{\{(svg|out|named|mutant|whole|code):([^}]*)\}\}', sub, h)

    # ---------------------------------------------------------------- steps -> data
    table, index = [], {}

    def lid(h):
        if h not in index:
            index[h] = len(table)
            table.append(h)
        return index[h]
    hl_cache = {s: lld.hl_lines(texts[s]) for s in lld.SNAPS}

    data, built, patterns = [], set(), []
    inline_hl = set()                                 # lines shown by {{code:...}} inside the prose
    for st in steps:
        inline_hl.clear()
        body = [f'<div class="think">{fill(st["think"])}</div>']
        hl_lines = set()
        pieces = []                                   # (code, label, cls, demo: None | 'open' | 'closed')
        for snap, specs, label in st.get('code', []):
            if specs == 'diff':
                ps, ls = diff_blocks(snap)
                pieces += ps
            else:
                code, ls = code_for(snap, specs)
                pieces.append((code, label or specs.replace(',', ', '), 'code', None))
            hl_lines |= ls
        # the walkthrough: each (text, explanation) pins a number on the first line, at or after the
        # last one, that contains the text; searching runs through the pieces in order
        callouts = [dict() for _ in pieces]
        walk_items, cur_p, cur_l = [], 0, 0
        for n, (find, expl) in enumerate(st.get('walk', []), 1):
            hit = None
            for pi in range(cur_p, len(pieces)):
                lines = pieces[pi][0].split('\n')
                for li in range(cur_l if pi == cur_p else 0, len(lines)):
                    if find in lines[li]:
                        hit = (pi, li)
                        break
                if hit:
                    break
            if not hit:
                raise SystemExit(f'{st["id"]}: walkthrough text not found in the code: {find}')
            callouts[hit[0]][hit[1]] = n
            cur_p, cur_l = hit
            walk_items.append((n, expl))
        for (code, label, cls, demo), co in zip(pieces, callouts):
            b = block(code, label, cls, co)
            if demo:
                b = (f'<details class="demo"{" open" if demo == "open" else ""}><summary>the demo that proves it (in Main)</summary>'
                     + b + '</details>')
            body.append(b)
        if walk_items:
            body.append('<div class="walk"><p class="wlab">Walk through it</p><ol>' +
                        ''.join(f'<li data-co="{n}"><span class="wn">{n}</span><span>{fill(e)}</span></li>' for n, e in walk_items)
                        + '</ol></div>')
        if st.get('out'):
            s, pre = st['out']
            t = outs[s] if not pre else '\n'.join(l for l in outs[s].split('\n') if l.startswith(pre + ' '))
            body.append(outblock(t))
        if st.get('say'):
            body.append(f'<p class="say">{st["say"]}</p>')
        if st.get('after'):
            body.append(fill(st['after']))
        for n in (st.get('hot', '') + ',' + st.get('new', '')).split(','):
            if n.strip():
                built.add(n.strip())
        for p in st.get('pattern', []):                 # the same pattern again: add where, keep one line
            same = next((i for i, q in enumerate(patterns) if q[0] == p[0]), None)
            if same is None:
                patterns.append(p)
            else:
                patterns[same] = (p[0], patterns[same][1] + '; ' + p[1])
        hl_lines |= inline_hl
        file_ = None
        if st.get('file'):
            s, tl = st['file']
            keep = None
            if tl:
                keep = set()
                for tn in tl.split(','):
                    t = next(t for t in typs[s] if t['name'] == tn.strip())
                    keep |= set(range(t['start'], t['end'] + 1))
                    if t['end'] + 1 < len(texts[s]) and not texts[s][t['end'] + 1].strip():
                        keep.add(t['end'] + 1)          # the blank line after a class
            rows_ = []
            for i, t in enumerate(texts[s]):
                if keep is not None and i not in keep and not (i < 4 and t.startswith('import')):
                    continue
                rows_.append([lid(hl_cache[s][i]), 1 if i in hl_lines else 0])
            file_ = rows_
        data.append(dict(id=st['id'], stage=st['stage'], title=st['title'], wide=st.get('wide', False),
                         body='\n'.join(body), hot=st.get('hot', ''), new=st.get('new', ''), sub=st.get('sub', {}),
                         built=sorted(built), patterns=list(patterns), file=file_,
                         practice=st.get('practice')))

    shell = ''.join(open(f, encoding='utf-8').read() for f in sorted(glob.glob(os.path.join(HERE, 'steps_shell', '*.html'))))
    page = shell.replace('<!--MINI-->', figs.fig_mini()).replace('/*DATA*/', 'const WB=' + json.dumps(
        dict(title=cfg.get('TITLE', 'Rate limiter'), steps=data, lines=table), separators=(',', ':')) + ';')
    target = os.path.join(root, name + '-steps.html')
    open(target, 'w', encoding='utf-8').write(page)
    words = sum(len(re.sub(r'<[^>]+>', ' ', re.sub(r'<div class="cb.*?</pre></div>|<svg.*?</svg>', '', x['body'], flags=re.S)).split()) for x in data)
    print('wrote', target, f'{len(page):,} bytes;', len(data), 'steps;', f'{words:,} words of prose')


if __name__ == '__main__':
    main(sys.argv[1])
