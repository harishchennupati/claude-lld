"""Export a snapshot of a workbench's master source as an IDE project.

    python3 tools/export.py <problem-dir> <snapshot> <out-dir> [package]

Writes <out-dir>/src/main/java/<package>/<Type>.java, one top-level type per file, plus
pom.xml (IntelliJ: File > Open > this folder), run.sh and README.md, then compiles and runs it.
"""
import os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lld  # noqa: E402

IMPORTS = [
    ('java.util.*', r'\b(List|Map|Set|ArrayList|ArrayDeque|Deque|HashMap|TreeMap|Collections|Objects|Optional|Iterator)\b'),
    ('java.util.concurrent.*', r'\b(ConcurrentHashMap|CopyOnWriteArrayList|Executors?|ExecutorService|CountDownLatch|Future|TimeUnit|Semaphore)\b'),
    ('java.util.concurrent.atomic.*', r'\b(Atomic\w+|LongAdder)\b'),
    ('java.util.function.*', r'\b(Predicate|Function|Supplier|Consumer|BiFunction)\b'),
]

POM = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>lld</groupId>
  <artifactId>{artifact}</artifactId>
  <version>1.0</version>
  <properties>
    <maven.compiler.release>17</maven.compiler.release>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
  </properties>
  <build>
    <plugins>
      <plugin>
        <groupId>org.codehaus.mojo</groupId>
        <artifactId>exec-maven-plugin</artifactId>
        <version>3.1.0</version>
        <configuration><mainClass>{pkg}.Main</mainClass></configuration>
      </plugin>
    </plugins>
  </build>
</project>
"""

README = """# {title}

Generated from `{master}`, snapshot `{snap}`: the same code the workbench page shows, compiled and run.

- **IntelliJ:** File > Open > this folder (it reads `pom.xml`), then run `{pkg}.Main`.
- **Terminal:** `./run.sh`, or `mvn -q compile exec:java`.
- One top-level type per file, in package `{pkg}`. `Main` holds the demo and the checks; a broken
  promise throws `AssertionError`.

Files: {files}
"""


def export(problem, snap, out, pkg='ratelimiter'):
    root = os.path.dirname(HERE)
    d = os.path.join(root, problem)
    cfg = {}
    if os.path.exists(os.path.join(d, 'wb', 'config.py')):
        exec(open(os.path.join(d, 'wb', 'config.py')).read(), cfg)
    lld.SNAPS = cfg.get('SNAPS', lld.SNAPS)
    rows = lld.parse_master(os.path.join(d, 'wb', 'Main.java'))
    texts = [t for t, _, _ in lld.snapshot(rows, snap)]
    types = lld.outline(texts)
    if os.path.exists(out):
        shutil.rmtree(out)
    src = os.path.join(out, 'src', 'main', 'java', pkg)
    os.makedirs(src)
    names = []
    for t in types:
        body = '\n'.join(texts[t['start']:t['end'] + 1]).rstrip() + '\n'
        imps = [imp for imp, pat in IMPORTS if re.search(pat, body)]
        head = f'package {pkg};\n\n' + ''.join(f'import {i};\n' for i in imps) + ('\n' if imps else '')
        open(os.path.join(src, t['name'] + '.java'), 'w').write(head + body)
        names.append(t['name'] + '.java')
    title = cfg.get('TITLE', problem) + (' · core' if snap == 'core' else ' · after every follow-up')
    open(os.path.join(out, 'pom.xml'), 'w').write(POM.format(artifact=f'{problem}-{snap}', pkg=pkg))
    open(os.path.join(out, 'README.md'), 'w').write(README.format(title=title, master=f'{problem}/wb/Main.java',
                                                                   snap=snap, pkg=pkg, files=', '.join(names)))
    run = os.path.join(out, 'run.sh')
    open(run, 'w').write('#!/bin/sh\n# compile and run; needs Java 17+\ncd "$(dirname "$0")"\nrm -rf out && mkdir out\n'
                         'javac -d out $(find src -name "*.java") && java -cp out ' + pkg + '.Main\n')
    os.chmod(run, 0o755)
    # prove it: compile every file and run Main
    with tempfile.TemporaryDirectory() as tmp:
        files = [os.path.join(src, n) for n in names]
        c = subprocess.run(['javac', '-d', tmp] + files, capture_output=True, text=True)
        if c.returncode:
            raise SystemExit(f'{out}: javac failed\n{c.stderr}')
        r = subprocess.run(['java', '-cp', tmp, f'{pkg}.Main'], capture_output=True, text=True, timeout=180)
        if r.returncode:
            raise SystemExit(f'{out}: run failed\n{r.stdout[-800:]}\n{r.stderr[-800:]}')
    print(f'  {out}: {len(names)} files, compiled and ran; last line: {r.stdout.strip().splitlines()[-1]}')


if __name__ == '__main__':
    export(*sys.argv[1:])
