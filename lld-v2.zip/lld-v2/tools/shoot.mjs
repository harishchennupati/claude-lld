// Screenshot a page in segments through the Chrome DevTools Protocol (no puppeteer needed).
// node shoot.mjs <url> <outPrefix> [width] [segmentHeight] [startY] [endY]
import { spawn } from 'node:child_process';
import { writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const [url, prefix, W = '1512', SEG = '1400', START = '0', END = '0'] = process.argv.slice(2);
const width = +W, seg = +SEG;
const CH = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const port = 9300 + Math.floor(Math.random() * 500);
const prof = mkdtempSync(join(tmpdir(), 'chprof-'));
const chrome = spawn(CH, ['--headless=new', '--disable-gpu', '--hide-scrollbars', `--remote-debugging-port=${port}`,
  `--user-data-dir=${prof}`, `--window-size=${width},1000`, 'about:blank'], { stdio: 'ignore' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let ws;
for (let i = 0; i < 50; i++) {
  try {
    const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
    const page = list.find(t => t.type === 'page');
    if (page) { ws = new WebSocket(page.webSocketDebuggerUrl); break; }
  } catch (e) {}
  await sleep(200);
}
await new Promise(r => ws.addEventListener('open', r));
let id = 0; const pending = new Map(); const events = [];
ws.addEventListener('message', ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); } else events.push(m);
});
const send = (method, params = {}) => new Promise(r => { const i = ++id; pending.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send('Page.enable');
await send('Emulation.setDeviceMetricsOverride', { width, height: 1000, deviceScaleFactor: 1, mobile: false });
await send('Page.navigate', { url });
await sleep(1500);
const { result } = await send('Page.getLayoutMetrics');
const H = Math.ceil(result.cssContentSize ? result.cssContentSize.height : result.contentSize.height);
const end = +END > 0 ? Math.min(+END, H) : H;
let k = 0;
for (let y = +START; y < end; y += seg) {
  const h = Math.min(seg, end - y);
  const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true,
    clip: { x: 0, y, width, height: h, scale: 1 } });
  writeFileSync(`${prefix}_${String(k).padStart(2, '0')}.png`, Buffer.from(shot.result.data, 'base64'));
  k++;
}
console.log(JSON.stringify({ height: H, segments: k }));
ws.close(); chrome.kill();
process.exit(0);
