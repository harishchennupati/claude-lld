"""Small helpers shared by every LLD page build: code regions, Java highlighting, SVG drawing."""
import html, re, subprocess, os

# ----------------------------------------------------------------------------- code regions
MARK_OPEN = re.compile(r'^\s*//#region\s+(\S+)\s*$')
MARK_CLOSE = re.compile(r'^\s*//#endregion\s*$')


def read(path):
    with open(path, encoding='utf-8') as f:
        return f.read()


def region(path, name, keep=()):
    """Lines of region `name`. Nested regions are dropped unless listed in `keep`.
    Marker lines never appear in the output."""
    lines = read(path).split('\n')
    out, depth_stack, inside = [], [], False
    for ln in lines:
        mo, mc = MARK_OPEN.match(ln), MARK_CLOSE.match(ln)
        if mo:
            nm = mo.group(1)
            if not inside and nm == name:
                inside = True
                depth_stack = [('target', True)]
                continue
            if inside:
                parent_visible = all(v for _, v in depth_stack)
                depth_stack.append((nm, parent_visible and nm in keep))
            continue
        if mc:
            if inside:
                depth_stack.pop()
                if not depth_stack:
                    inside = False
            continue
        if inside and all(v for _, v in depth_stack):
            out.append(ln)
    if not out:
        raise ValueError(f'region {name} not found in {path}')
    # trim blank lines at both ends, and common indentation
    while out and not out[0].strip():
        out.pop(0)
    while out and not out[-1].strip():
        out.pop()
    ind = min(len(l) - len(l.lstrip()) for l in out if l.strip())
    return '\n'.join(l[ind:] for l in out)


def whole(path):
    """The whole file without region markers."""
    return '\n'.join(l for l in read(path).split('\n')
                     if not MARK_OPEN.match(l) and not MARK_CLOSE.match(l)).strip('\n')


def run_java(src_dir, main='Main'):
    import tempfile
    with tempfile.TemporaryDirectory() as out:          # no .class files left next to the sources
        subprocess.run(['javac', '-Xlint:all', '-Werror', '-d', out,
                        os.path.join(src_dir, main + '.java')], check=True)
        r = subprocess.run(['java', '-cp', out, main], check=True, capture_output=True, text=True)
    return r.stdout.rstrip('\n')


# ----------------------------------------------------------------------------- Java highlighting
KW = set('''abstract assert boolean break byte case catch char class const continue default do double
else enum extends final finally float for goto if implements import instanceof int interface long native
new package private protected public return short static strictfp super switch synchronized this throw
throws transient try void volatile while var record true false null'''.split())
TOKEN = re.compile(r'''
 (?P<tb>"""[\s\S]*?""")
|(?P<com>//[^\n]*|/\*[\s\S]*?\*/)
|(?P<str>"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')
|(?P<ann>@[A-Za-z_]\w*)
|(?P<num>\b\d[\d_]*(?:\.\d+)?[lLdDfF]?\b)
|(?P<id>[A-Za-z_]\w*)
''', re.X)


def hl(code):
    out, pos = [], 0
    for m in TOKEN.finditer(code):
        out.append(html.escape(code[pos:m.start()]))
        t, kind = m.group(0), m.lastgroup
        e = html.escape(t)
        if kind in ('tb', 'str'):
            out.append(f'<span class="s">{e}</span>')
        elif kind == 'com':
            out.append(f'<span class="c">{e}</span>')
        elif kind == 'ann':
            out.append(f'<span class="a">{e}</span>')
        elif kind == 'num':
            out.append(f'<span class="n">{e}</span>')
        elif t in KW:
            out.append(f'<span class="k">{e}</span>')
        elif t[0].isupper():
            out.append(f'<span class="t">{e}</span>')
        else:
            out.append(e)
        pos = m.end()
    out.append(html.escape(code[pos:]))
    return ''.join(out)


def code_block(code, label='', note='', copy=True, cls=''):
    lines = code.count('\n') + 1
    head = ''
    if label or copy:
        head = ('<div class="cbh"><span class="cbl">' + label + '</span>'
                + (f'<span class="cbn">{note}</span>' if note else '')
                + ('<button class="cp" type="button">copy</button>' if copy else '') + '</div>')
    return (f'<div class="cb {cls}" data-lines="{lines}">{head}<pre><code>{hl(code)}</code></pre></div>')


def out_block(text, label='output'):
    return (f'<div class="cb out"><div class="cbh"><span class="cbl">{label}</span></div>'
            f'<pre><code>{html.escape(text)}</code></pre></div>')


# ----------------------------------------------------------------------------- SVG drawing
C = dict(bg='#181825', sur='#313244', sur2='#232336', txt='#cdd6f4', mut='#a6adc8', dim='#7f849c',
         line='#45475a', acc='#cba6f7', green='#a6e3a1', red='#f38ba8', yellow='#f9e2af',
         blue='#89b4fa', peach='#fab387', teal='#94e2d5', sky='#89dceb')
FONT = 'IBM Plex Mono, ui-monospace, Menlo, monospace'


class Svg:
    def __init__(self, w, h):
        self.w, self.h, self.parts = w, h, []

    def add(self, s):
        self.parts.append(s)
        return self

    def text(self, x, y, s, size=11, fill=None, anchor='start', weight=None, italic=False, cls=None):
        fill = fill or C['txt']
        a = f' font-weight="{weight}"' if weight else ''
        a += ' font-style="italic"' if italic else ''
        a += f' class="{cls}"' if cls else ''
        return self.add(f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" '
                        f'text-anchor="{anchor}"{a}>{html.escape(s)}</text>')

    def rich(self, x, y, runs, size=11, anchor='start'):
        """runs: list of (text, fill, weight) drawn as tspans on one line."""
        sp = ''.join(f'<tspan fill="{f or C["txt"]}"' + (f' font-weight="{w}"' if w else '')
                     + f'>{html.escape(t)}</tspan>' for t, f, w in runs)
        return self.add(f'<text x="{x}" y="{y}" font-size="{size}" text-anchor="{anchor}">{sp}</text>')

    def rect(self, x, y, w, h, fill=None, stroke=None, rx=6, dash=None, sw=1.4, opacity=None):
        fill = fill or C['sur']
        stroke = stroke or C['line']
        d = f' stroke-dasharray="{dash}"' if dash else ''
        o = f' opacity="{opacity}"' if opacity else ''
        return self.add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" '
                        f'stroke="{stroke}" stroke-width="{sw}"{d}{o}/>')

    def line(self, pts, stroke=None, sw=1.5, dash=None, end=None, start=None):
        stroke = stroke or C['mut']
        d = 'M' + ' L'.join(f'{x} {y}' for x, y in pts)
        a = f' stroke-dasharray="{dash}"' if dash else ''
        a += f' marker-end="url(#{end})"' if end else ''
        a += f' marker-start="url(#{start})"' if start else ''
        return self.add(f'<path d="{d}" fill="none" stroke="{stroke}" stroke-width="{sw}"{a}/>')

    def circle(self, x, y, r, fill, stroke='none'):
        return self.add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}"/>')

    def render(self, title=''):
        defs = f'''<defs>
<marker id="arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="{C['mut']}"/></marker>
<marker id="arr-acc" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="{C['acc']}"/></marker>
<marker id="arr-green" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="{C['green']}"/></marker>
<marker id="arr-red" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="{C['red']}"/></marker>
<marker id="arr-blue" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="{C['blue']}"/></marker>
<marker id="tri" viewBox="0 0 12 12" refX="11" refY="6" markerWidth="11" markerHeight="11" orient="auto-start-reverse"><path d="M1 1L11 6L1 11z" fill="{C['bg']}" stroke="{C['mut']}" stroke-width="1.3"/></marker>
<marker id="dia" viewBox="0 0 14 10" refX="1" refY="5" markerWidth="13" markerHeight="9" orient="auto-start-reverse"><path d="M1 5L7 1L13 5L7 9z" fill="{C['mut']}"/></marker>
</defs>'''
        t = f'<title>{html.escape(title)}</title>' if title else ''
        return (f'<svg viewBox="0 0 {self.w} {self.h}" xmlns="http://www.w3.org/2000/svg" '
                f'font-family="{FONT}" role="img">{t}{defs}' + ''.join(self.parts) + '</svg>')


def uml(s, x, y, w, name, fields=(), methods=(), kind='class', note=None, hi=False):
    """A class box. kind: class | interface | record. Returns (x, y, w, h)."""
    head = 34 if kind != 'class' else 24
    lh = 15
    h = head + (len(fields) * lh + 10 if fields else 0) + (len(methods) * lh + 10 if methods else 0) + 2
    stroke = C['acc'] if hi else (C['blue'] if kind == 'interface' else (C['teal'] if kind == 'record' else C['line']))
    dash = '5 3' if kind == 'interface' else None
    s.rect(x, y, w, h, fill=C['sur'], stroke=stroke, dash=dash, sw=1.5)
    if kind != 'class':
        s.text(x + w / 2, y + 13, '«' + kind + '»', size=9.5, fill=C['mut'], anchor='middle')
        s.text(x + w / 2, y + 28, name, size=12.5, weight='600', anchor='middle')
    else:
        s.text(x + w / 2, y + 17, name, size=12.5, weight='600', anchor='middle')
    cy = y + head
    if fields:
        s.line([(x, cy), (x + w, cy)], stroke=C['line'], sw=1)
        for i, f in enumerate(fields):
            s.text(x + 9, cy + 14 + i * lh, f, size=10.5, fill=C['mut'])
        cy += len(fields) * lh + 10
    if methods:
        s.line([(x, cy), (x + w, cy)], stroke=C['line'], sw=1)
        for i, m in enumerate(methods):
            s.text(x + 9, cy + 14 + i * lh, m, size=10.5, fill=C['txt'])
        cy += len(methods) * lh + 10
    if note:
        s.text(x + w / 2, y + h + 13, note, size=9.5, fill=C['dim'], anchor='middle', italic=True)
    return (x, y, w, h)
